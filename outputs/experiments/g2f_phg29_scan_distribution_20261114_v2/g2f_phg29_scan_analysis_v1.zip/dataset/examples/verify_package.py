"""Verify every distributed file using only the Python standard library."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    checksums = {}
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        checksums[name] = digest
    assert set(checksums) == set(manifest["files"]) | {"manifest.json"}
    for name, expected in checksums.items():
        path = (root / name).resolve()
        assert root in path.parents, f"Unsafe file path: {name}"
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual == expected, f"SHA-256 mismatch: {name}"
        if name in manifest["files"]:
            entry = manifest["files"][name]
            assert actual == entry["sha256"], name
            assert path.stat().st_size == entry["size_bytes"], name
    print(f"PASS: {len(checksums)} files; all SHA-256 and sizes match.")


if __name__ == "__main__":
    main()
