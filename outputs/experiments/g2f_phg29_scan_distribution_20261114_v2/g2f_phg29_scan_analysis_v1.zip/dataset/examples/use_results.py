"""Read, filter, plot and join the package without a model engine."""

from __future__ import annotations

import argparse
import hashlib
import math
from pathlib import Path

import matplotlib
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--g2f-dir", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = args.output_dir or root / "example_outputs"
    output.mkdir(parents=True, exist_ok=True)
    df = pd.read_parquet(root / "data/results_complete.parquet")
    key = ["model", "environment_id", "planting_date"]
    assert len(df) == 37266 and not df.duplicated(key).any()
    valid = (
        df.status.eq("matured")
        & df.natural_maturity.eq(True)
        & df.forced_maturity.eq(False)
        & df.dry_yield_mg_ha.notna()
    )
    assert valid.sum() == 33125
    print("Valid yield records:", int(valid.sum()))
    print(df.groupby("model").status.value_counts().to_string())
    env = "DEH1_2016"
    fig, ax = plt.subplots(figsize=(10, 4))
    for model, group in df[df.environment_id.eq(env)].groupby("model"):
        group = group.sort_values("planting_date")
        # Retain missing dates as plot gaps rather than connecting across failures.
        ax.plot(pd.to_datetime(group.planting_date), group.dry_yield_mg_ha, label=model)
    ax.set(xlabel="Simulated planting date", ylabel="Dry yield (Mg/ha)", title=env)
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(output / "sowing_date_curve.png", dpi=150)
    plt.close(fig)

    units = pd.read_parquet(root / "data/management_units.parquet")
    observations = pd.read_parquet(root / "data/observations.parquet")
    plots = pd.read_parquet(root / "data/observation_plot_provenance.parquet")
    for item in observations.itertuples():
        column = {"pollen_dap": "pollen_dap_days", "silk_dap": "silk_dap_days"}.get(
            item.variable, item.variable
        )
        values = []
        for _, physical in plots[plots.unit_id.eq(item.unit_id)].groupby(
            "physical_plot_id"
        ):
            if not physical.eligible.all():
                continue
            candidates = physical[column].drop_duplicates()
            if len(candidates) == 1 and candidates.notna().all():
                values.append(float(candidates.iloc[0]))
        assert len(values) == item.n_records, item.observation_id
        mean = sum(values) / len(values) if values else math.nan
        variance = pd.Series(values, dtype=float).var(ddof=1)
        for actual, saved in [(mean, item.value), (variance, item.variance)]:
            assert (pd.isna(actual) and pd.isna(saved)) or math.isclose(
                actual, saved, abs_tol=1e-8, rel_tol=1e-8
            ), item.observation_id
    print("Reconstructed observation means/variances/counts:", len(observations))
    obs = observations.merge(
        units[["unit_id", "planting_date"]],
        on="unit_id",
        how="left",
        validate="many_to_one",
    ).rename(columns={"planting_date": "actual_planting_date"})
    mapping = pd.read_csv(root / "data/scenario_units.csv")
    frames = []
    for model, trait in [
        ("apsim", "pollen_dap"),
        ("aquacrop", "pollen_dap"),
        ("dssat", "silk_dap"),
    ]:
        g = obs[obs.variable.isin(["dry_yield_mg_ha", trait])].copy()
        g["model"] = model
        g = g.merge(
            mapping[["model", "environment_id", "unit_id", "representative"]],
            on=["model", "environment_id", "unit_id"],
            how="left",
            validate="many_to_one",
        )
        g["planting_date"] = pd.to_datetime(g.actual_planting_date).dt.strftime(
            "%Y-%m-%d"
        )
        right = df[
            key
            + [
                "dry_yield_mg_ha",
                trait,
                "status",
                "natural_maturity",
                "forced_maturity",
            ]
        ].rename(columns={"status": "simulation_status"})
        g = g.merge(right, on=key, how="left", validate="many_to_one", indicator=True)
        g["scenario_compatible"] = g.representative.notna()
        g["predicted_value"] = g.dry_yield_mg_ha.where(
            g.variable.eq("dry_yield_mg_ha"), g[trait]
        ).where(g.scenario_compatible)
        g["prediction_available"] = g.predicted_value.notna()
        g["absolute_error"] = (g.predicted_value - g.value).abs()
        frames.append(
            g[
                [
                    "model",
                    "environment_id",
                    "unit_id",
                    "observation_id",
                    "variable",
                    "planting_date",
                    "value",
                    "predicted_value",
                    "absolute_error",
                    "simulation_status",
                    "scenario_compatible",
                    "prediction_available",
                    "_merge",
                ]
            ]
        )
    joined = pd.concat(frames, ignore_index=True)
    assert not joined.duplicated(["model", "observation_id"]).any()
    joined.to_csv(output / "actual_observation_join.csv", index=False, encoding="utf-8")
    print(
        "Observation join:",
        len(joined),
        "rows;",
        int(joined.prediction_available.sum()),
        "available predictions",
    )

    if args.g2f_dir is not None:
        sources = pd.read_csv(root / "provenance/raw_g2f_files.csv")
        traits = sources[sources.source_filename.str.contains("Trait")]
        assert not traits.empty
        for item in traits.itertuples():
            path = args.g2f_dir / item.source_filename
            assert hashlib.sha256(path.read_bytes()).hexdigest() == item.sha256, path
        source = pd.read_csv(root / "data/observation_sources.csv").iloc[0]
        raw = pd.read_csv(args.g2f_dir / source.source_filename, low_memory=False)
        row = int(source.source_row_number) - 1
        assert 0 <= row < len(raw)
        print(
            "G2F source verified:",
            source.source_filename,
            "data row",
            row + 1,
            "; columns:",
            len(raw.iloc[row]),
        )
    print("Analysis outputs:", output)


if __name__ == "__main__":
    main()
