"""Lossless G2F cultivar tables, separate from legacy normalization.

``normalize_cultivar_plots`` returns one row per supplied row (never deduplicates).
``aggregate_cultivar_observations`` returns ``(units, observations)``: units are
cultivar x environment x management; observations are long-form trait means,
sample variances and distinct-plot counts. All tables retain ineligible records
with explicit ``eligible``, ``quality_flags`` and ``exclusion_reasons``.

IDs are deterministic content keys, not row positions. JSON columns preserve raw
plot/metadata evidence; reason/flag columns are sorted tuples of machine codes.
Harvest and final stand are observations, never maturity or sowing density.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping
from datetime import date, datetime
from typing import Any

import pandas as pd

TRAITS: dict[str, tuple[str, str, float, float, float]] = {
    # output: (raw column, unit, multiplier, inclusive minimum, inclusive maximum)
    "dry_yield_mg_ha": ("Yield_Mg_ha", "Mg/ha", 0.845, 0, math.inf),
    "pollen_dap_days": ("Pollen_DAP_days", "days", 1, 1, 200),
    "silk_dap_days": ("Silk_DAP_days", "days", 1, 1, 200),
    "plant_height_m": ("Plant_Height_cm", "m", 0.01, 0.01, 10),
    "ear_height_m": ("Ear_Height_cm", "m", 0.01, 0, 10),
    "stand_count_plants": ("Stand_Count_plants", "plants", 1, 0, math.inf),
}
_MANAGEMENT_FIELDS = (
    "verified_population_plants_m2",
    "verified_density_source",
    "fertilizer_events",
    "sowing_depth_m",
    "row_spacing_m",
)
_PLOT_COLUMNS = [
    "unit_id",
    "management_unit_id",
    "physical_plot_id",
    "environment_id",
    "cultivar_id",
    "hybrid",
    "hybrid_original",
    "parent1",
    "parent2",
    "identity_evidence",
    "identity_conflict",
    "year",
    "site_id",
    "experiment",
    "treatment",
    "planting_date",
    "harvest_date",
    "replicate",
    "block",
    "plot",
    "record_kind",
    "irrigation_status",
    "irrigation_events",
    *_MANAGEMENT_FIELDS,
    "management_provenance_json",
    "protocol_split",
    "source_split",
    "source_filename",
    "source_row_number",
    "source_index",
    "metadata_source_filename",
    "raw_row_json",
    "metadata_rows_json",
    "yield_mg_ha",
    "grain_moisture_pct",
    "plot_area_ha",
    *TRAITS,
    "trait_exclusion_reasons",
    "quality_flags",
    "exclusion_reasons",
    "eligible",
]
_UNIT_COLUMNS = [
    "unit_id",
    "management_unit_id",
    "management_context_id",
    "environment_id",
    "cultivar_id",
    "year",
    "site_id",
    "experiment",
    "treatment",
    "planting_date",
    "irrigation_status",
    "irrigation_events",
    *_MANAGEMENT_FIELDS,
    "management_provenance_json",
    "protocol_split",
    "source_split",
    "parent1",
    "parent2",
    "identity_conflict",
    "record_kind",
    "source_row_count",
    "distinct_plot_count",
    "source_rows_json",
    "hybrid_originals",
    "identity_evidence_json",
    "quality_flags",
    "exclusion_reasons",
    "eligible",
]
_OBS_COLUMNS = [
    "observation_id",
    "unit_id",
    "management_unit_id",
    "environment_id",
    "cultivar_id",
    "year",
    "site_id",
    "protocol_split",
    "trait",
    "value",
    "variance",
    "n_plots",
    "n_records",
    "unit",
    "record_kind",
    "source_row_count",
    "source_rows_json",
    "quality_flags",
    "exclusion_reasons",
    "eligible",
]


def _text(value: object) -> str:
    if value is None or (not isinstance(value, (list, dict, tuple)) and pd.isna(value)):
        return ""
    return " ".join(str(value).strip().split())


def _identifier(value: object) -> str:
    text = _text(value)
    if re.fullmatch(r"\d+(?:\.0+)?", text):
        return str(int(text.split(".")[0]))
    return text


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if value is None or pd.isna(value):
        return None
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if hasattr(value, "item"):
        return _jsonable(value.item())
    return value


def _json(value: object) -> str:
    return json.dumps(_jsonable(value), sort_keys=True, ensure_ascii=False)


def _key(prefix: str, *parts: object) -> str:
    return prefix + "_" + hashlib.sha256(_json(parts).encode()).hexdigest()[:24]


def _date(value: object) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    for fmt in ("%m/%d/%y", "%m/%d/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(_text(value), fmt).date()
        except ValueError:
            pass
    return None


def _number(value: object) -> float:
    try:
        number = float(value)
    except (ValueError, TypeError):
        return math.nan
    return number if math.isfinite(number) else math.nan


def _protocol(year: int | None) -> str:
    if year is not None and 2014 <= year <= 2022:
        return "train"
    return {2023: "independent", 2024: "optional_validation"}.get(
        year, "out_of_protocol"
    )


def _positive_comment(text: str, pattern: str) -> bool:
    """Keep clause-local negation from hiding a later positive issue."""
    for clause in re.split(r"[.;\n]|\bbut\b", text.lower()):
        for match in re.finditer(pattern, clause):
            before = clause[: match.start()]
            after = clause[match.end() :]
            if re.search(r"\b(?:no|not|without|never)\b.{0,30}$", before):
                continue
            if re.match(
                r"\s+(?:was |were )?(?:absent|not observed|not reported)", after
            ):
                continue
            return True
    return False


def _irrigation_comments(
    comments: str,
    experiment: str,
) -> tuple[bool, bool, set[str], set[str]]:
    """Resolve named trial scopes only from explicit experiment evidence.

    G2F_Main is matched to G2F_Main or the source's G2F_YYYY_YY[_tester] codes;
    HIP_Hybrid/Inbred require exact names. Unknown experiments are not silently
    assigned a scope. Partial-plot irrigation stays unresolved, not extrapolated.
    """
    irrigation_pattern = r"\birrigat(?:ed|ion|ing|e)\b"
    scope_pattern = r"\b(?:g2f[_ ]main|hip[_ ]hybrid|hip[_ ]inbred)\b"
    normalized_experiment = experiment.lower().replace(" ", "_")
    if re.fullmatch(r"g2f_\d{4}_\d{2}(?:_.+)?", normalized_experiment):
        normalized_experiment = "g2f_main"
    supported = {"g2f_main", "hip_hybrid", "hip_inbred"}
    flags: set[str] = set()
    reasons: set[str] = set()
    positive = confirmed_no = False
    for clause in re.split(r"[.;\n]", comments):
        if not re.search(irrigation_pattern, clause, re.IGNORECASE):
            continue
        prefix, separator, body = clause.partition(":")
        scopes = (
            {
                match.group().lower().replace(" ", "_")
                for match in re.finditer(scope_pattern, prefix, re.IGNORECASE)
            }
            if separator
            else set()
        )
        if scopes:
            if normalized_experiment not in supported:
                flags.add("irrigation_scope_unresolved")
                reasons.add("irrigation_scope_unresolved")
                continue
            if normalized_experiment not in scopes:
                flags.add("irrigation_comment_other_trial")
                continue
            flags.add("irrigation_comment_scope_matched")
            clause = body
        partial = bool(
            re.search(
                r"\bplots?\b.*\b\d+\s*[-–]\s*\d+|"
                r"\b(?:some|only|not all)\b.*\bplots?\b|"
                r"\birrigat\w*\b.*\bonly\b",
                clause,
                re.IGNORECASE,
            )
        )
        if partial or _positive_comment(clause, irrigation_pattern):
            positive = True
            if partial:
                reasons.add("partial_plot_irrigation_unresolved")
        elif re.search(
            r"\b(?:not|no|never)\s+irrigat|\birrigation\s+was\s+not",
            clause,
            re.IGNORECASE,
        ):
            confirmed_no = True
    return positive, confirmed_no, flags, reasons


def _events(value: object) -> tuple[list[dict[str, object]], bool]:
    if not _text(value):
        return [], True
    try:
        events = json.loads(value) if isinstance(value, str) else value
        if not isinstance(events, (list, tuple)):
            return [], False
        result = []
        for event in events:
            when = _date(event["date"])
            amount = _number(event["amount_mm"])
            if when is None or not math.isfinite(amount) or amount < 0:
                return [], False
            result.append({"date": when.isoformat(), "amount_mm": amount})
        return sorted(
            result, key=lambda event: (event["date"], event["amount_mm"])
        ), True
    except (ValueError, TypeError, KeyError):
        return [], False


def _fertilizer_events(value: object) -> tuple[list[dict[str, object]], bool]:
    """Canonical dated N amounts, retaining supplied form/placement/source fields."""
    if not _text(value):
        return [], True
    try:
        events = json.loads(value) if isinstance(value, str) else value
        if not isinstance(events, (list, tuple)):
            return [], False
        result = []
        for event in events:
            when = _date(event["date"])
            amount = _number(event["nitrogen_kg_ha"])
            if when is None or not math.isfinite(amount) or amount < 0:
                return [], False
            result.append({**event, "date": when.isoformat(), "nitrogen_kg_ha": amount})
        # Reordering a supplied schedule must not create another management.
        # Identical events are retained, not silently deduplicated applications.
        return sorted(
            result,
            key=lambda event: (event["date"], event["nitrogen_kg_ha"], _json(event)),
        ), True
    except (ValueError, TypeError, KeyError):
        return [], False


def normalize_cultivar_plots(
    raw: pd.DataFrame,
    metadata: pd.DataFrame | None = None,
    *,
    source_filename: str = "<dataframe>",
    source_split: str = "training",
    metadata_source_filename: str | None = None,
) -> pd.DataFrame:
    """Normalize training plots or 2024 Env/Hybrid/Yield labels, without I/O.

    Requires ``Env`` and ``Hybrid`` columns. Metadata joins by Env, then by
    Treatment/date/Experiment when both sources supply those disambiguators.
    Ambiguous metadata is preserved and excluded, never multiplied into plots.
    Treatment, irrigation, supplied fertilizer/geometry and verified sowing
    density are included in management keys. Final stand is never density.

    Output includes raw row and matched metadata JSON, 1-based data-row lineage,
    parents/original name, dates, physical plot keys, all ``TRAITS`` in named
    units, per-trait reason JSON, and structural eligibility. Invalid trait
    values become NaN but stay intact in raw JSON. Missing irrigation is assumed
    rainfed; positive comments override that assumption. Replicates are never
    inferred for labels or rows lacking Plot.

    Plots and aggregate units retain ``verified_population_plants_m2`` (plants/m2),
    ``verified_density_source`` (supplied text only), ``fertilizer_events`` (JSON
    array of ISO dates and nitrogen_kg_ha, retaining extra event fields),
    ``sowing_depth_m`` and ``row_spacing_m``. Missing numeric inputs remain NaN;
    no schedule/source is ``[]``/empty text, not an invented reference input.
    Invalid supplied inputs are structurally excluded, not silently defaulted.
    ``management_provenance_json`` maps each supplied canonical field to a list
    of selected-source records with field, raw_value, source_kind, filename,
    1-based source row and original index. Raw nonblank values override matched
    metadata; ambiguous metadata supplies no canonical inputs. Metadata filenames
    remain null when the caller did not supply one. Raw/metadata JSON additionally
    retain overridden values. Aggregation unions provenance across all plot rows.
    """
    missing = {"Env", "Hybrid"} - set(raw)
    if missing:
        raise ValueError(f"missing cultivar input columns: {sorted(missing)}")
    aliases = {"train": "training", "test": "testing"}
    source_split = aliases.get(source_split, source_split)
    if source_split not in {"training", "testing"}:
        raise ValueError("source_split must be training/train or testing/test")
    if metadata is not None and "Env" not in metadata:
        raise ValueError("metadata requires Env")
    by_env: dict[str, list[dict[str, object]]] = {}
    metadata_lineage: dict[str, list[dict[str, object]]] = {}
    if metadata is not None:
        for meta_position, (meta_index, entry) in enumerate(
            zip(metadata.index, metadata.to_dict("records")), 1
        ):
            by_env.setdefault(_text(entry["Env"]), []).append(entry)
            metadata_lineage.setdefault(_json(entry), []).append(
                {
                    "source_kind": "metadata",
                    "source_filename": metadata_source_filename,
                    "source_row_number": meta_position,
                    "source_index": str(meta_index),
                }
            )
    rows = []
    for position, (source_index, source) in enumerate(raw.iterrows(), 1):
        original = source.to_dict()
        environment = _text(original.get("Env"))
        candidates = by_env.get(environment, [])
        for column in ("Treatment", "Date_Planted", "Experiment"):
            value = original.get(column)
            if _text(value) and any(_text(m.get(column)) for m in candidates):
                if column == "Date_Planted":
                    candidates = [
                        m for m in candidates if _date(m.get(column)) == _date(value)
                    ]
                else:
                    candidates = [
                        m for m in candidates if _text(m.get(column)) == _text(value)
                    ]
        unique_metadata = {_json(m): m for m in candidates}
        meta = next(iter(unique_metadata.values())) if len(unique_metadata) == 1 else {}
        reasons: set[str] = set()
        flags: set[str] = set()
        if len(unique_metadata) > 1:
            reasons.add("metadata_ambiguous")
        if metadata is not None and not candidates:
            flags.add("metadata_missing")
            if by_env.get(environment):
                reasons.add("metadata_management_conflict")
        combined = dict(meta)
        combined.update({k: v for k, v in original.items() if _text(v)})
        provenance = {}
        for field in _MANAGEMENT_FIELDS:
            if not _text(combined.get(field)):
                continue
            origins = (
                [
                    {
                        "source_kind": "raw",
                        "source_filename": str(source_filename),
                        "source_row_number": position,
                        "source_index": str(source_index),
                    }
                ]
                if _text(original.get(field))
                else metadata_lineage[next(iter(unique_metadata))]
            )
            provenance[field] = [
                {**origin, "field": field, "raw_value": combined[field]}
                for origin in origins
            ]
        management_values: dict[str, object] = {}
        for field in (
            "verified_population_plants_m2",
            "sowing_depth_m",
            "row_spacing_m",
        ):
            number = _number(combined.get(field))
            if _text(combined.get(field)) and (
                not math.isfinite(number) or number <= 0
            ):
                reasons.add(f"{field}_invalid")
                number = math.nan
            management_values[field] = number
        fertilizer, fertilizer_valid = _fertilizer_events(
            combined.get("fertilizer_events")
        )
        if not fertilizer_valid:
            reasons.add("fertilizer_schedule_invalid")
        management_values.update(
            verified_density_source=_text(combined.get("verified_density_source")),
            fertilizer_events=_json(fertilizer),
            management_provenance_json=_json(provenance),
        )
        experiment = _text(combined.get("Experiment")) or _text(
            meta.get("Experiment_Code")
        )
        cultivar = _text(original.get("Hybrid"))
        parent1 = _text(original.get("Hybrid_Parent1"))
        parent2 = _text(original.get("Hybrid_Parent2"))
        evidence = "explicit_parents" if parent1 and parent2 else "hybrid_name_only"
        parts = cultivar.split("/")
        if not parent1 and not parent2 and len(parts) == 2 and all(parts):
            parent1, parent2 = map(_text, parts)
            evidence = "parsed_hybrid_name"
        parent_conflict = bool(
            evidence == "explicit_parents"
            and len(parts) == 2
            and tuple(map(_text, parts)) != (parent1, parent2)
        )
        planting = _date(combined.get("Date_Planted"))
        year_value = _number(combined.get("Year"))
        if math.isnan(year_value):
            match = re.search(r"_(\d{4})$", environment)
            year_value = float(match[1]) if match else math.nan
        year = (
            int(year_value)
            if math.isfinite(year_value) and year_value.is_integer()
            else None
        )
        for condition, reason in (
            (not environment, "environment_missing"),
            (not cultivar, "cultivar_missing"),
            (planting is None, "planting_date_missing_or_invalid"),
            (year is None, "year_missing_or_invalid"),
            (
                planting is not None and year is not None and planting.year != year,
                "planting_year_conflict",
            ),
            (parent_conflict, "identity_conflict"),
        ):
            if condition:
                reasons.add(reason)
        comments = " ; ".join(
            _text(value)
            for record in [*candidates, original]
            for column, value in record.items()
            if "comment" in column.lower() or "issue" in column.lower()
        )
        mixed = _positive_comment(
            comments,
            r"\bmixed\b.*\b(?:plots?|seeds?|treatments?)\b|"
            r"\b(?:plots?|seeds?|treatments?)\b.*\bmixed\b",
        )
        if mixed:
            reasons.add("mixed_treatments_or_plots")
        irrigation = _text(combined.get("Irrigated")).lower()
        treatment = _text(combined.get("Treatment")) or "unspecified"
        comment_irrigation, comment_rainfed, irrigation_flags, irrigation_reasons = (
            _irrigation_comments(comments, experiment)
        )
        flags.update(irrigation_flags)
        reasons.update(irrigation_reasons)
        irrigation_events, events_valid = _events(combined.get("irrigation_events"))
        if not events_valid:
            reasons.add("irrigation_schedule_invalid")
        if (
            irrigation in {"yes", "true", "1", "irrigated"}
            or comment_irrigation
            or _positive_comment(treatment, r"\birrigat(?:ed|ion)\b")
            or irrigation_events
        ):
            irrigation_status = "irrigated"
            if not irrigation_events:
                reasons.add("irrigation_schedule_missing")
        elif (
            irrigation in {"no", "false", "0", "rainfed", "dryland"} or comment_rainfed
        ):
            irrigation_status = "rainfed_confirmed"
        else:
            irrigation_status = "assumed_rainfed"
            flags.add("assumed_rainfed")
        if comment_irrigation:
            flags.add("irrigation_in_comments")
        management = _key(
            "management",
            environment,
            experiment,
            treatment,
            planting,
            irrigation_status,
            irrigation_events,
            fertilizer if _text(combined.get("fertilizer_events")) else None,
            management_values["sowing_depth_m"],
            management_values["row_spacing_m"],
            *(
                [management_values["verified_population_plants_m2"]]
                if _text(combined.get("verified_population_plants_m2"))
                else []
            ),
        )
        plot = _identifier(original.get("Plot"))
        label = not plot and year == 2024
        if not plot and not label:
            reasons.add("plot_identifier_missing")
        if label:
            flags.add("preaggregated_label")
        physical = (
            _key(
                "plot",
                management,
                _identifier(original.get("Replicate")),
                _identifier(original.get("Block")),
                plot,
            )
            if plot
            else None
        )
        trait_reasons: dict[str, str] = {}
        values = {}
        for trait, (column, _, factor, lower, upper) in TRAITS.items():
            number = _number(original.get(column)) * factor
            if not math.isfinite(number):
                trait_reasons[trait] = (
                    "missing_trait"
                    if not _text(original.get(column))
                    else "invalid_trait"
                )
            elif not lower <= number <= upper:
                trait_reasons[trait] = "trait_out_of_range"
                number = math.nan
            values[trait] = number
        rows.append(
            {
                "unit_id": _key("unit", management, cultivar),
                "management_unit_id": management,
                "physical_plot_id": physical,
                "environment_id": environment,
                "cultivar_id": cultivar,
                "hybrid": cultivar,
                "hybrid_original": _text(original.get("Hybrid_orig_name")) or cultivar,
                "parent1": parent1,
                "parent2": parent2,
                "identity_evidence": evidence,
                "identity_conflict": parent_conflict,
                "year": year,
                "site_id": _text(combined.get("Field_Location"))
                or re.sub(r"_\d{4}$", "", environment),
                "experiment": experiment,
                "treatment": treatment,
                "planting_date": planting,
                "harvest_date": _date(original.get("Date_Harvested")),
                "replicate": _identifier(original.get("Replicate")),
                "block": _identifier(original.get("Block")),
                "plot": plot,
                "record_kind": "environment_hybrid_label" if label else "plot",
                "irrigation_status": irrigation_status,
                "irrigation_events": _json(irrigation_events),
                **management_values,
                "protocol_split": _protocol(year),
                "source_split": source_split,
                "source_filename": str(source_filename),
                "source_row_number": position,
                "source_index": str(source_index),
                "metadata_source_filename": metadata_source_filename,
                "raw_row_json": _json(original),
                "metadata_rows_json": _json(candidates),
                "yield_mg_ha": _number(original.get("Yield_Mg_ha")),
                "grain_moisture_pct": _number(original.get("Grain_Moisture")),
                "plot_area_ha": _number(combined.get("Plot_Area_ha")),
                **values,
                "trait_exclusion_reasons": _json(trait_reasons),
                "quality_flags": tuple(sorted(flags)),
                "exclusion_reasons": tuple(sorted(reasons)),
                "eligible": not reasons,
            }
        )
    plots = pd.DataFrame(rows, columns=_PLOT_COLUMNS)
    return _mark_identity_conflicts(plots)


def _mark_identity_conflicts(plots: pd.DataFrame) -> pd.DataFrame:
    plots = plots.copy().reset_index(drop=True)
    if plots.empty:
        return plots
    # Identity evidence is categorical only: no phenotype values enter this map.
    # Scan narrow tuples once rather than materializing thousands of wide
    # cultivar/name dataframes (also called again after source-batch concat).
    conflicts: set[str] = set()
    parents: dict[str, set[tuple[str, str]]] = {}
    names: dict[str, set[str]] = {}
    for cultivar, parent1, parent2, conflict, original in plots[
        ["cultivar_id", "parent1", "parent2", "identity_conflict", "hybrid_original"]
    ].itertuples(index=False, name=None):
        if conflict:
            conflicts.add(cultivar)
        if parent1 and parent2:
            parents.setdefault(cultivar, set()).add((parent1, parent2))
        names.setdefault(original, set()).add(cultivar)
    conflicts.update(cultivar for cultivar, pairs in parents.items() if len(pairs) > 1)
    for cultivars in names.values():
        if len(cultivars) > 1:
            conflicts.update(cultivars)
    affected = plots.cultivar_id.isin(conflicts)
    plots.loc[affected, "identity_conflict"] = True
    plots.loc[affected, "eligible"] = False
    plots.loc[affected, "exclusion_reasons"] = plots.loc[
        affected, "exclusion_reasons"
    ].map(lambda reasons: tuple(sorted(set(reasons) | {"identity_conflict"})))
    return plots


def _plot_measurements(
    physical_groups: dict[str, list[Any]],
) -> tuple[dict[str, list[float]], dict[str, set[str]]]:
    """Reduce all traits over shared physical-plot groups, never trait-wise frames."""
    measurements: dict[str, list[float]] = {trait: [] for trait in TRAITS}
    flags: dict[str, set[str]] = {trait: set() for trait in TRAITS}
    for physical_id in sorted(physical_groups):
        rows = physical_groups[physical_id]
        if not all(row.eligible for row in rows):
            continue
        for trait in TRAITS:
            # Missing and present versions of one measurement disagree too.
            # Collapse missing sentinels just as Series.drop_duplicates does for
            # the normalized floating-point columns, without dropping other traits.
            values = {
                None if pd.isna(value := getattr(row, trait)) else value for row in rows
            }
            if len(values) > 1:
                flags[trait].add("conflicting_duplicate_plot")
            elif values and None not in values:
                measurements[trait].append(float(next(iter(values))))
    return measurements, flags


def aggregate_cultivar_observations(
    plots: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return all cultivar-management units and long-form trait observations.

    Plot IDs, not CSV rows or replicate numbers, define replication. Repeated
    identical measurements count once; contradictory measurements for one
    physical plot are excluded for that trait (never arbitrarily averaged).
    ``variance`` is the sample variance (ddof=1), not variance of the mean.
    A trait needs >=2 distinct valid plots. 2024 environment/hybrid labels are
    already aggregated yield only, with n_plots=0 and unknown variance.

    ``units.eligible`` is structural and never depends on phenotype values;
    ``observations.eligible`` additionally requires valid trait replication.
    Means and exclusions remain visible even for ineligible records.
    Units retain canonical verified density/source, fertilizer/geometry fields
    and the deduplicated union of every plot's management provenance. Multiple
    supplied density-source strings are sorted and joined with ``; ``. Sources
    do not split otherwise identical physical management inputs.

    Rows are grouped once per unit and physical plot, shared by every trait.
    No per-trait pandas groupby/dropna or per-unit wide-frame iteration is used.
    """
    missing = set(_PLOT_COLUMNS) - set(plots)
    if missing:
        raise ValueError(f"not normalized cultivar plots; missing: {sorted(missing)}")
    plots = _mark_identity_conflicts(plots)
    unit_rows, observation_rows = [], []
    # A single itertuples call constructs its row type once for the whole table.
    # Thousands of tiny dataframes/Series otherwise dominate this small-plot case.
    grouped: dict[str, list[Any]] = {}
    assigned: dict[str, set[str]] = {}
    for row in plots.itertuples(index=False, name="CultivarPlot"):
        if pd.notna(row.physical_plot_id):
            assigned.setdefault(row.physical_plot_id, set()).add(row.cultivar_id)
        if pd.notna(row.unit_id):
            grouped.setdefault(row.unit_id, []).append(row)
    conflicting_plots = {
        physical_id for physical_id, cultivars in assigned.items() if len(cultivars) > 1
    }
    for unit_id in sorted(grouped):
        rows = grouped[unit_id]
        first = rows[0]
        flags = {code for row in rows for code in row.quality_flags}
        reasons = {code for row in rows for code in row.exclusion_reasons}
        physical_groups: dict[str, list[Any]] = {}
        raw_trait_flags: dict[str, set[str]] = {trait: set() for trait in TRAITS}
        management_evidence: dict[str, dict[str, object]] = {}
        for row in rows:
            if pd.notna(row.physical_plot_id):
                physical_groups.setdefault(row.physical_plot_id, []).append(row)
            for trait, reason in json.loads(row.trait_exclusion_reasons).items():
                if trait in raw_trait_flags and reason:
                    raw_trait_flags[trait].add(reason)
            if row.management_provenance_json != "{}":
                for field, evidence in json.loads(
                    row.management_provenance_json
                ).items():
                    entries = management_evidence.setdefault(field, {})
                    for entry in evidence:
                        entries[_json(entry)] = entry
        count = len(physical_groups)
        label = first.record_kind == "environment_hybrid_label"
        if conflicting_plots.intersection(physical_groups):
            reasons.add("plot_identity_conflict")
        if count < 2 and not label:
            reasons.add("insufficient_distinct_plots")
        if len(rows) > count and not label:
            flags.add("duplicate_plot_rows")
        unit = {
            column: getattr(first, column)
            for column in (
                "unit_id",
                "management_unit_id",
                "environment_id",
                "cultivar_id",
                "year",
                "site_id",
                "experiment",
                "treatment",
                "planting_date",
                "irrigation_status",
                "irrigation_events",
                *_MANAGEMENT_FIELDS,
                "protocol_split",
                "source_split",
                "parent1",
                "parent2",
                "record_kind",
            )
        }
        unit.update(
            {
                # This cultivar-independent fingerprint must survive the main
                # workflow's per-cultivar simulation-management ID mapping.
                "management_context_id": first.management_unit_id,
                "verified_density_source": "; ".join(
                    sorted(
                        {
                            row.verified_density_source
                            for row in rows
                            if row.verified_density_source
                        }
                    )
                ),
                "management_provenance_json": _json(
                    {
                        field: [entries[key] for key in sorted(entries)]
                        for field, entries in sorted(management_evidence.items())
                    }
                ),
                "identity_conflict": any(row.identity_conflict for row in rows),
                "source_row_count": len(rows),
                "distinct_plot_count": count,
                "source_rows_json": _json(
                    sorted(
                        [
                            {
                                "source_filename": row.source_filename,
                                "source_row_number": row.source_row_number,
                            }
                            for row in rows
                        ],
                        key=lambda r: (r["source_filename"], r["source_row_number"]),
                    )
                ),
                "hybrid_originals": tuple(
                    sorted({row.hybrid_original for row in rows})
                ),
                "identity_evidence_json": _json(
                    sorted(
                        {
                            (row.parent1, row.parent2, row.identity_evidence)
                            for row in rows
                        }
                    )
                ),
                "quality_flags": tuple(sorted(flags)),
                "exclusion_reasons": tuple(sorted(reasons)),
                "eligible": not reasons,
            }
        )
        unit_rows.append(unit)
        plot_values, plot_flags = (
            _plot_measurements(physical_groups) if not label else ({}, {})
        )
        for trait, (_, measurement_unit, _, _, _) in TRAITS.items():
            trait_flags = flags | raw_trait_flags[trait]
            trait_reasons = set(reasons)
            measurements: list[float] = []
            if label:
                if trait == "dry_yield_mg_ha":
                    values = {
                        value for row in rows if pd.notna(value := getattr(row, trait))
                    }
                    if len(values) == 1:
                        measurements = [float(next(iter(values)))]
                    elif len(values) > 1:
                        trait_reasons.add("conflicting_label_values")
                else:
                    trait_reasons.add("label_trait_unavailable")
            else:
                measurements = plot_values[trait]
                trait_flags.update(plot_flags[trait])
                if len(measurements) < 2:
                    trait_reasons.add("insufficient_valid_distinct_plots")
            if not measurements:
                trait_reasons.add("no_valid_trait_values")
            n = len(measurements)
            mean = sum(measurements) / n if n else math.nan
            variance = (
                sum((value - mean) ** 2 for value in measurements) / (n - 1)
                if n > 1
                else math.nan
            )
            observation_rows.append(
                {
                    "observation_id": _key("observation", unit_id, trait),
                    **{
                        column: unit[column]
                        for column in (
                            "unit_id",
                            "management_unit_id",
                            "environment_id",
                            "cultivar_id",
                            "year",
                            "site_id",
                            "protocol_split",
                            "record_kind",
                            "source_row_count",
                            "source_rows_json",
                        )
                    },
                    "trait": trait,
                    "value": mean,
                    "variance": variance,
                    "n_plots": 0 if label else len(measurements),
                    "n_records": len(measurements),
                    "unit": measurement_unit,
                    "quality_flags": tuple(sorted(trait_flags)),
                    "exclusion_reasons": tuple(sorted(trait_reasons)),
                    "eligible": not trait_reasons,
                }
            )
    return (
        pd.DataFrame(unit_rows, columns=_UNIT_COLUMNS),
        pd.DataFrame(observation_rows, columns=_OBS_COLUMNS),
    )


_SELECTION_COLUMNS = [
    "cultivar_id",
    "parent1",
    "parent2",
    "identity_conflict",
    "n_train_environments",
    "n_train_years",
    "n_train_sites",
    "n_test_environments",
    "pollen_adjusted_days",
    "height_adjusted_m",
    "eligible",
    "exclusion_reasons",
    "selected",
    "selection_rank",
    "is_core",
    "selection_distance",
]


def _eligibility(frame: pd.DataFrame, column: str = "eligible") -> pd.Series:
    # Fail closed for missing/null flags; never treat the string "False" as true.
    result = frame["eligible"].eq(True).fillna(False)
    if "final_eligible" in frame:
        result &= frame["final_eligible"].eq(True).fillna(False)
    if column != "eligible":
        result &= frame[column].eq(True).fillna(False)
    return result


def select_cultivars(
    units: pd.DataFrame,
    observations: pd.DataFrame,
    *,
    count: int = 5,
    min_train_environments: int = 30,
    min_train_years: int = 5,
    min_train_sites: int = 5,
    min_test_environments: int = 3,
    eligibility_column: str = "eligible",
) -> pd.DataFrame:
    """Return a deterministic selection *catalog*, including excluded cultivars.

    Coverage uses distinct eligible dry-yield train environments in 2014--2022.
    The independent test coverage requirement counts 2023 *structural unit
    presence*, never test yield/phenology completeness or values. Optional 2024
    labels cannot satisfy any selection threshold or influence any feature.

    Integration must first update units' ``eligible``, add ``final_eligible``,
    or name a combined external input/weather/soil gate with
    ``eligibility_column``. All supplied gates are ANDed, including nullable
    gates (null means false). No provisional eligibility is cached. Observation
    eligibility is also required for train features/targets, never test coverage.

    Trait features are train-only pollen/height residuals after subtracting the
    within-management-environment cultivar mean, then averaging environments
    equally. Stable ``management_context_id`` preserves this grouping if main
    remaps simulation management IDs per cultivar. ``pollen_dap`` is accepted as
    an input alias for ``pollen_dap_days``. Eligible candidates' two features are
    standardized (population SD).
    Core maximizes train environment, year, then site coverage. Subsequent
    choices maximize minimum Euclidean distance in the two standardized features
    plus parental dissimilarity (1 - shared parents / larger parent-set size).
    Coverage and lexical cultivar ID break ties deterministically.

    Output is sorted by cultivar_id. ``selected`` and nullable, 1-based
    ``selection_rank`` identify up to count cultivars; ``is_core`` and
    ``selection_distance`` explain the greedy decisions. Selection never
    silently relaxes coverage or missing-trait thresholds.
    """
    required_units = {
        "unit_id",
        "cultivar_id",
        "environment_id",
        "management_unit_id",
        "year",
        "site_id",
        "parent1",
        "parent2",
        "identity_conflict",
        "eligible",
        eligibility_column,
    }
    required_obs = {"unit_id", "trait", "value", "eligible"}
    for frame, required, name in (
        (units, required_units, "units"),
        (observations, required_obs, "observations"),
    ):
        missing = required - set(frame)
        if missing:
            raise ValueError(f"{name} missing selection columns: {sorted(missing)}")
    for name, value in (
        ("count", count),
        ("min_train_environments", min_train_environments),
        ("min_train_years", min_train_years),
        ("min_train_sites", min_train_sites),
        ("min_test_environments", min_test_environments),
    ):
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise ValueError(f"{name} must be a nonnegative integer")
    if units.unit_id.duplicated().any():
        raise ValueError("units must have unique unit_id")
    if observations.duplicated(["unit_id", "trait"]).any():
        raise ValueError("observations must have unique (unit_id, trait)")
    if not observations.unit_id.isin(units.unit_id).all():
        raise ValueError("observations contain unknown unit_id")
    working = units.copy()
    working["year"] = pd.to_numeric(working["year"], errors="coerce")
    if "management_context_id" in working:
        working["_selection_management_context"] = working["management_context_id"]
    else:
        # Also support integration-created unit tables with retained management
        # fields, while never centering across distinct known treatments.
        context_fields = [
            c
            for c in (
                "environment_id",
                "experiment",
                "treatment",
                "planting_date",
                "irrigation_status",
                "irrigation_events",
            )
            if c in working
        ]
        working["_selection_management_context"] = (
            [
                _key("context", *(r[c] for c in context_fields))
                for r in working.to_dict("records")
            ]
            if len(context_fields) > 1
            else working["management_unit_id"]
        )
    training = working.year.between(2014, 2022)
    if "source_split" in working:
        training &= working.source_split.isin(["training", "train"])
    usable = _eligibility(working, eligibility_column)
    train_units = working.loc[training & usable].sort_values("unit_id")
    # Use unit metadata for splits/identity; never an observation's duplicated
    # metadata columns, nor any eval value even for computing a global mean.
    train_obs = observations.loc[
        observations.unit_id.isin(train_units.unit_id) & _eligibility(observations),
        ["unit_id", "trait", "value"],
    ].copy()
    train_obs["trait"] = train_obs["trait"].replace({"pollen_dap": "pollen_dap_days"})
    if train_obs.duplicated(["unit_id", "trait"]).any():
        raise ValueError("training observations contain duplicate canonical traits")
    train_obs["value"] = pd.to_numeric(train_obs.value, errors="coerce")
    train_obs = train_obs.loc[train_obs.value.map(math.isfinite)]
    joined = train_obs.merge(
        train_units[
            [
                "unit_id",
                "cultivar_id",
                "environment_id",
                "management_unit_id",
                "_selection_management_context",
                "year",
                "site_id",
            ]
        ],
        on="unit_id",
        validate="many_to_one",
    ).sort_values(["unit_id", "trait"])
    features: dict[str, pd.Series] = {}
    for trait in ("pollen_dap_days", "plant_height_m"):
        values = joined.loc[joined.trait.eq(trait)].copy()
        values["residual"] = values.value - values.groupby(
            ["environment_id", "_selection_management_context"],
            sort=True,
            dropna=False,
        ).value.transform("mean")
        # Multiple managements in an environment do not upweight that environment.
        environment_means = values.groupby(
            ["cultivar_id", "environment_id"], sort=True
        ).residual.mean()
        features[trait] = environment_means.groupby(level="cultivar_id").mean()
    records = []
    for cultivar, cultivar_units in working.groupby("cultivar_id", sort=True):
        parents = working.loc[training & working.cultivar_id.eq(cultivar)]
        pairs = sorted(
            {
                (_text(r.parent1), _text(r.parent2))
                for r in parents.itertuples()
                if _text(r.parent1) and _text(r.parent2)
            }
        )
        identity_conflict = bool(parents.identity_conflict.any() or len(pairs) > 1)
        train = joined.loc[
            joined.cultivar_id.eq(cultivar) & joined.trait.eq("dry_yield_mg_ha")
        ]
        test = cultivar_units.loc[
            cultivar_units.year.eq(2023)
            & _eligibility(cultivar_units, eligibility_column)
        ]
        n_env = train.environment_id.nunique()
        n_years = train.year.nunique()
        n_sites = train.site_id.nunique()
        n_test = test.environment_id.nunique()
        pollen = features["pollen_dap_days"].get(cultivar, math.nan)
        height = features["plant_height_m"].get(cultivar, math.nan)
        reasons = []
        for condition, reason in (
            (n_env < min_train_environments, "insufficient_train_environments"),
            (n_years < min_train_years, "insufficient_train_years"),
            (n_sites < min_train_sites, "insufficient_train_sites"),
            (n_test < min_test_environments, "insufficient_test_environments"),
            (not math.isfinite(pollen), "train_pollen_missing"),
            (not math.isfinite(height), "train_height_missing"),
            (not pairs, "train_parents_missing"),
            (identity_conflict, "identity_conflict"),
        ):
            if condition:
                reasons.append(reason)
        records.append(
            {
                "cultivar_id": cultivar,
                "parent1": pairs[0][0] if pairs else "",
                "parent2": pairs[0][1] if pairs else "",
                "identity_conflict": identity_conflict,
                "n_train_environments": n_env,
                "n_train_years": n_years,
                "n_train_sites": n_sites,
                "n_test_environments": n_test,
                "pollen_adjusted_days": pollen,
                "height_adjusted_m": height,
                "eligible": not reasons,
                "exclusion_reasons": tuple(sorted(reasons)),
                "selected": False,
                "selection_rank": None,
                "is_core": False,
                "selection_distance": math.nan,
            }
        )
    catalog = pd.DataFrame(records, columns=_SELECTION_COLUMNS)
    catalog["selection_rank"] = pd.array(catalog.selection_rank, dtype="Int64")
    candidates = catalog.loc[catalog.eligible.eq(True)].copy()
    if count == 0 or candidates.empty:
        return catalog
    feature_columns = ["pollen_adjusted_days", "height_adjusted_m"]
    feature_values = candidates[feature_columns]
    scales = feature_values.std(ddof=0).replace(0, 1)
    scaled = (feature_values - feature_values.mean()) / scales

    def coverage(index: int) -> tuple[int, int, int, str]:
        r = catalog.loc[index]
        return (
            -int(r.n_train_environments),
            -int(r.n_train_years),
            -int(r.n_train_sites),
            r.cultivar_id,
        )

    def distance(left: int, right: int) -> float:
        left_parents = {catalog.at[left, "parent1"], catalog.at[left, "parent2"]}
        right_parents = {catalog.at[right, "parent1"], catalog.at[right, "parent2"]}
        parent_distance = 1 - len(left_parents & right_parents) / max(
            len(left_parents), len(right_parents)
        )
        return math.sqrt(
            sum((scaled.loc[left] - scaled.loc[right]) ** 2) + parent_distance**2
        )

    core = min(candidates.index, key=coverage)
    selected = [core]
    catalog.at[core, "is_core"] = True
    catalog.at[core, "selection_distance"] = 0.0
    while len(selected) < min(count, len(candidates)):
        remaining = set(candidates.index) - set(selected)
        distances = {
            index: min(distance(index, other) for other in selected)
            for index in remaining
        }
        # Round only the tie key to suppress insignificant floating-point noise.
        choice = min(
            remaining,
            key=lambda index: (-round(distances[index], 12), *coverage(index)),
        )
        selected.append(choice)
        catalog.at[choice, "selection_distance"] = distances[choice]
    for rank, index in enumerate(selected, 1):
        catalog.at[index, "selected"] = True
        catalog.at[index, "selection_rank"] = rank
    return catalog
