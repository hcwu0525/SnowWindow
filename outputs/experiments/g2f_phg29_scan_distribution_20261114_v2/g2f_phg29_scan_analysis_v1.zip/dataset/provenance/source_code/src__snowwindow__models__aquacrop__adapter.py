"""Stable adapter for the pinned AquaCrop-OSPy implementation."""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import math
import os
import time
import traceback
import uuid
from collections.abc import Mapping
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from aquacrop import (
    AquaCropModel,
    Crop,
    InitialWaterContent,
    IrrigationManagement,
    Soil,
)
from aquacrop.entities.crops.crop_params import crop_params
from aquacrop.utils import get_filepath, prepare_weather

from snowwindow.domain import (
    CalibrationParameter,
    FoldStrategy,
    ModelCapabilities,
    RunStatus,
    ScanRequestStrategy,
    SimulationRequest,
    SimulationResult,
    WeatherStrategy,
)
from snowwindow.models.aquacrop.physics import reference_et

ADAPTER_NAME = "aquacrop"
MODEL_VERSION = "3.1.0"
DEFAULT_CROP = "MaizeGDD"
THERMAL_KEYS = (
    "Emergence",
    "MaxRooting",
    "Senescence",
    "Maturity",
    "HIstart",
    "Flowering",
    "YldForm",
)
REQUIRED_WEATHER_VALUES = (
    "T2M_MIN",
    "T2M_MAX",
    "PRECTOTCORR",
    "RH2M",
    "WS2M",
    "PS",
    "ALLSKY_SFC_SW_DWN",
)
# Only constructor inputs, never derived calendar fields or dynamic triggers.
NATIVE_CROP_BOUNDS = {
    **{key: (0.0, 20_000.0) for key in THERMAL_KEYS},
    "HI0": (0.0, 1.0),
    "CCx": (0.0, 1.0),
    "CGC": (0.0, 1.0),
    "CDC": (0.0, 1.0),
    "Zmin": (0.0, 5.0),
    "Zmax": (0.0, 5.0),
    "PlantPop": (0.0, 10_000_000.0),
    "SeedSize": (0.0, 1000.0),
    "Tbase": (-20.0, 50.0),
    "Tupp": (-20.0, 60.0),
    "WP": (0.0, 100.0),
    "WPy": (0.0, 200.0),
    "Kcb": (0.0, 2.0),
    "SxTopQ": (0.0, 1.0),
    "SxBotQ": (0.0, 1.0),
    "fshape_r": (0.0, 100.0),
    "GermThr": (0.0, 1.0),
    "HIini": (0.0, 1.0),
    "YldWC": (0.0, 100.0),
}
NATIVE_CROP_ENUMS = {
    "CalendarType": (2,),
    "CropType": (3,),
    "PlantMethod": (1,),
    "SwitchGDD": (0,),
    "GDDmethod": (1, 2, 3),
    "Determinant": (0, 1),
    "ETadj": (0, 1),
    "PolColdStress": (0, 1),
    "PolHeatStress": (0, 1),
    "TrColdStress": (0, 1),
}
NATIVE_IGNORED_PARAMETERS = (
    "root_depth_scale",
    "initial_available_water_pct",
    "irrigation_smt",
    "soil_type",
)
NATIVE_ADAPTER_PARAMETERS = {
    *NATIVE_IGNORED_PARAMETERS,
    "model_version",
    "crop",
    "planting_date",
    "phenology_scale",
    "postflower_scale",
    "phenology_scale_site",
    "HI0_site",
    "soil_depth_m",
    "soil_compartment_m",
    "save_daily",
    "plant_population_ha",
    "grain_standard_moisture_fraction",
}
SOIL_PROPERTY_BOUNDS = {
    "theta_wp": (0.0, 1.0),
    "theta_fc": (0.0, 1.0),
    "theta_sat": (0.0, 1.0),
    "ksat_mm_day": (0.0, 100_000.0),
    "bulk_density_g_cm3": (0.0, 2.65),
    "sand_pct": (0.0, 100.0),
    "clay_pct": (0.0, 100.0),
    "organic_carbon_pct": (0.0, 100.0),
}


class RequestValidationError(ValueError):
    """A request cannot be represented by the supported AquaCrop contract."""


class _CultivarModel(AquaCropModel):
    """Observe native biology without changing the pinned engine's solution."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.native_biology: list[dict[str, Any]] = []

    def _perform_timestep(self) -> tuple[Any, Any, Any, Any]:
        step = self._clock_struct.time_step_counter
        returned = super()._perform_timestep()
        state = returned[1]
        self.native_biology.append(
            {
                "time_step_counter": step,
                "native_germinated": bool(state.germination),
                "native_delayed_cds": int(state.delayed_cds),
                "native_delayed_gdds": float(state.delayed_gdds),
                "native_development_gdd": max(
                    0.0, float(state.gdd_cum - state.delayed_gdds)
                ),
                "native_yield_form": bool(state.yield_form),
                "native_crop_mature": bool(state.crop_mature),
                "native_crop_dead": bool(state.crop_dead),
            }
        )
        return returned


def simulation_end_for_planting(planting_date: date) -> tuple[date, bool]:
    """Return the supported recurring-calendar end and adjustment flag."""

    anniversary = date(planting_date.year + 1, 4, 30)
    adjusted = anniversary.month == 2 and anniversary.day == 29
    if adjusted:
        anniversary -= timedelta(days=1)
    return anniversary, adjusted


def map_exception_status(error: BaseException) -> RunStatus:
    """Map known AquaCrop restrictions without collapsing unexpected failures."""

    message = str(error).lower()
    if "not enough growing degree days in simulation" in message:
        return RunStatus.INSUFFICIENT_THERMAL_TIME
    if "crop will take longer than 1 year to mature" in message:
        return RunStatus.MODEL_LIMIT
    return RunStatus.EXECUTION_FAILED


def map_crop_state(crop_mature: bool, crop_dead: bool, germinated: bool) -> RunStatus:
    """Map AquaCrop's final state flags to the stable domain status."""

    if crop_mature:
        return RunStatus.MATURED
    if crop_dead:
        return RunStatus.CROP_DIED
    if not germinated:
        return RunStatus.NOT_GERMINATED
    return RunStatus.NOT_MATURED


def _sha256_tree(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*.py")):
        digest.update(str(path.relative_to(root)).encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


@lru_cache(maxsize=1)
def adapter_source_fingerprint() -> str:
    return _sha256_tree(Path(__file__).parent)


@lru_cache(maxsize=1)
def aquacrop_source_fingerprint() -> str:
    import aquacrop

    return _sha256_tree(Path(aquacrop.__file__).parent)


def _plain_request(request: SimulationRequest) -> dict[str, Any]:
    content = request.to_json_dict()
    content.pop("request_id", None)
    content.pop("output_dir", None)
    parameters = dict(content["model_parameters"])
    parameters.pop("save_daily", None)
    content["model_parameters"] = parameters
    return content


def _as_date(value: object) -> date:
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError as exc:
        raise RequestValidationError(f"invalid planting date: {value!r}") from exc


def _number(
    parameters: dict[str, Any],
    name: str,
    default: float,
    *,
    minimum: float,
    maximum: float,
    minimum_inclusive: bool = True,
) -> float:
    try:
        value = float(parameters.get(name, default))
    except (TypeError, ValueError) as exc:
        raise RequestValidationError(f"{name} must be numeric") from exc
    lower_ok = value >= minimum if minimum_inclusive else value > minimum
    if not math.isfinite(value) or not lower_ok or value > maximum:
        bracket = "[" if minimum_inclusive else "("
        raise RequestValidationError(
            f"{name} must be in {bracket}{minimum}, {maximum}]"
        )
    return value


def _json_default(value: object) -> object:
    if isinstance(value, (date, pd.Timestamp, Path)):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if hasattr(value, "item"):
        return value.item()
    raise TypeError(f"{type(value).__name__} is not JSON serializable")


def _atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}-{uuid.uuid4().hex}")
    try:
        temporary.write_text(
            json.dumps(
                value,
                allow_nan=False,
                default=_json_default,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _atomic_parquet(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}-{uuid.uuid4().hex}")
    try:
        frame.to_parquet(temporary, index=False)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _soil_type(request: SimulationRequest, parameters: dict[str, Any]) -> str:
    if "soil_type" in parameters:
        return str(parameters["soil_type"])
    if request.environment.soil:
        properties = request.environment.soil[0].properties
        for key in ("aquacrop_soil_type", "soil_type", "texture"):
            if key in properties:
                return str(properties[key])
    for key in ("aquacrop_soil_type", "soil_type", "default_soil_type"):
        if key in request.environment.metadata:
            return str(request.environment.metadata[key])
    return "Loam"


def _cultivar_mode(request: SimulationRequest) -> bool:
    return request.environment.metadata.get("cultivar_calibration") is True


def _native_number(
    values: Mapping[str, Any],
    key: str,
    minimum: float,
    maximum: float,
    *,
    positive: bool = False,
) -> float:
    if key not in values or isinstance(values[key], bool):
        raise RequestValidationError(f"{key} must be a supplied numeric value")
    return _number(
        dict(values),
        key,
        0.0,
        minimum=minimum,
        maximum=maximum,
        minimum_inclusive=not positive,
    )


def _native_soil(request: SimulationRequest) -> Soil:
    """Keep horizon boundaries exact; the pinned engine rounds geometry to cm."""

    layers = request.environment.soil
    if not layers:
        raise RequestValidationError("cultivar soil layers must be supplied")
    parameters = dict(request.model_parameters)
    compartment = _number(
        parameters, "soil_compartment_m", 0.1, minimum=0.05, maximum=0.5
    )
    if not math.isclose(compartment, round(compartment, 2), abs_tol=1e-9):
        raise RequestValidationError("soil compartment depth must use whole cm")
    dz: list[float] = []
    previous = 0.0
    for layer in layers:
        top, bottom = layer.top_depth_m, layer.bottom_depth_m
        if (
            not math.isfinite(top)
            or not math.isfinite(bottom)
            or not math.isclose(top, previous, abs_tol=1e-9)
            or bottom <= top
            or not math.isclose(bottom, round(bottom, 2), abs_tol=1e-9)
        ):
            raise RequestValidationError(
                "soil layers must be contiguous from zero with whole-cm depth bounds"
            )
        if not layer.source:
            raise RequestValidationError("each soil layer requires source evidence")
        props = {
            key: _native_number(
                layer.properties,
                key,
                lower,
                upper,
                positive=key in {"ksat_mm_day", "bulk_density_g_cm3"},
            )
            for key, (lower, upper) in SOIL_PROPERTY_BOUNDS.items()
        }
        if not props["theta_wp"] < props["theta_fc"] < props["theta_sat"]:
            raise RequestValidationError(
                "soil requires theta_wp < theta_fc < theta_sat"
            )
        if props["sand_pct"] + props["clay_pct"] > 100:
            raise RequestValidationError("sand_pct + clay_pct must not exceed 100")
        remaining_cm = round((bottom - top) * 100)
        step_cm = round(compartment * 100)
        while remaining_cm:
            size_cm = min(step_cm, remaining_cm)
            dz.append(size_cm / 100)
            remaining_cm -= size_cm
        previous = bottom
    depth = _number(parameters, "soil_depth_m", previous, minimum=0.4, maximum=5.0)
    if not math.isclose(depth, previous, abs_tol=1e-9):
        raise RequestValidationError("soil_depth_m must equal supplied layer depth")
    soil = Soil("custom", dz=dz)
    for layer in layers:
        props = layer.properties
        soil.add_layer(
            # add_layer compares float sums to cm-rounded compartment bottoms.
            # One outward ULP avoids dropping the last compartment of a horizon.
            np.nextafter(layer.bottom_depth_m - layer.top_depth_m, math.inf),
            float(props["theta_wp"]),
            float(props["theta_fc"]),
            float(props["theta_sat"]),
            float(props["ksat_mm_day"]),
            100.0,
        )
    if soil.profile["Layer"].isna().any():
        raise RequestValidationError("soil layer boundaries cannot be represented")
    return soil


def _native_population(request: SimulationRequest) -> dict[str, Any]:
    """Never substitute final stand or an implicit crop-default sowing density."""
    population = _native_number(
        {"population_plants_m2": request.management.population_plants_m2},
        "population_plants_m2",
        0.0,
        1000.0,
        positive=True,
    )
    metadata = request.management.metadata
    if "population_verified" in metadata and not isinstance(
        metadata["population_verified"], bool
    ):
        raise RequestValidationError("population_verified must be boolean")
    source = metadata.get("population_source")
    source = source.strip() if isinstance(source, str) else ""
    verified = bool(source) and (
        metadata.get("population_verified") is True
        or (
            "population_verified" not in metadata and source == "verified_sowing_record"
        )
    )
    assumption = metadata.get("population_assumption")
    assumption = assumption.strip() if isinstance(assumption, str) else ""
    if not assumption and source == "assumption":
        assumption = metadata.get("assumption_source")
        assumption = assumption.strip() if isinstance(assumption, str) else ""
    if not (verified or assumption):
        raise RequestValidationError(
            "population requires verified sowing evidence "
            "or a sourced explicit sowing assumption"
        )
    return {
        "population_plants_m2": population,
        "PlantPop": population * 10_000,
        "verified": verified,
        "evidence_source": source if verified else assumption,
    }


def _native_crop(request: SimulationRequest, soil_depth: float) -> Crop:
    parameters = dict(request.model_parameters)
    if "postflower_scale" in parameters and "phenology_scale" in parameters:
        raise RequestValidationError(
            "simultaneous phenology_scale and postflower_scale"
        )
    crop_name = str(parameters.get("crop", DEFAULT_CROP))
    if crop_name not in {"Maize", "MaizeGDD"}:
        raise RequestValidationError("cultivar AquaCrop requires native maize GDD crop")
    for key in ("phenology_scale_site", "HI0_site"):
        if parameters.get(key, 1.0) != 1.0:
            raise RequestValidationError(f"{key} site fitting is not supported")
    native = {}
    base = crop_params[crop_name]
    if "phenology_scale" in parameters:
        scale = _native_number(parameters, "phenology_scale", 0.1, 3.0, positive=True)
        # Original two-parameter comparator, on the same cultivar inputs.
        # Explicit native coefficients below take precedence per key.
        native.update({key: float(base[key]) * scale for key in THERMAL_KEYS})
    for key, value in parameters.items():
        if key in NATIVE_CROP_ENUMS:
            numeric = _native_number(parameters, key, 0.0, 3.0)
            if numeric not in NATIVE_CROP_ENUMS[key]:
                raise RequestValidationError(f"unsupported cultivar {key}: {value}")
            native[key] = int(numeric)
        elif key in NATIVE_CROP_BOUNDS:
            lower, upper = NATIVE_CROP_BOUNDS[key]
            native[key] = _native_number(
                parameters, key, lower, upper, positive=key not in {"Tbase", "Tupp"}
            )
        elif key in base:
            # Other native maize coefficients (stress thresholds, shapes, flags).
            if key.endswith("CD") or key == "Name":
                raise RequestValidationError(f"unsupported cultivar crop input: {key}")
            upper = 1.0 if key.startswith(("p_up", "p_lo")) or key == "fsink" else 100.0
            native[key] = _native_number(
                parameters, key, 0.0, upper, positive=key.startswith("fshape_w")
            )
        elif key not in NATIVE_ADAPTER_PARAMETERS:
            raise RequestValidationError(f"unconsumed cultivar parameter: {key}")
    if "postflower_scale" in parameters:
        from snowwindow.cultivar_pragmatic import effective_native_parameters

        scalar = _native_number(parameters, "postflower_scale", 0.5, 1.25)
        native = effective_native_parameters(
            "aquacrop",
            {**native, "postflower_scale": scalar},
            reference=crop_params["MaizeGDD"],
        )
    sow_population = _native_population(request)["PlantPop"]
    for key in ("PlantPop", "plant_population_ha"):
        if key in parameters:
            supplied = _native_number(parameters, key, 0.0, 10_000_000.0, positive=True)
            if not math.isclose(supplied, sow_population, abs_tol=1e-6):
                raise RequestValidationError(f"{key} conflicts with sowing population")
    native["PlantPop"] = sow_population
    root_cap = round(soil_depth - 0.1, 2)
    native.setdefault("Zmax", min(float(base["Zmax"]), root_cap))
    crop = Crop(
        crop_name,
        request.management.planting_date.strftime("%m/%d"),
        harvest_date=request.end_date.strftime("%m/%d"),
        **native,
    )
    crop.PlantTrigger = None
    if crop.CalendarType != 2:
        raise RequestValidationError("cultivar maize must use GDD phenology")
    if not (
        0 < crop.Emergence < crop.HIstart < crop.Senescence < crop.Maturity
        and crop.Emergence < crop.MaxRooting <= crop.Maturity
        and crop.HIstart + crop.Flowering
        <= crop.HIstart + crop.YldForm
        <= crop.Maturity
    ):
        raise RequestValidationError("native crop phenology chronology is invalid")
    if not (0 < crop.Zmin <= crop.Zmax <= root_cap):
        raise RequestValidationError("native Zmin/Zmax exceed supplied soil depth")
    if not (
        crop.Tbase < crop.Tupp
        and crop.Tmin_lo < crop.Tmin_up
        and crop.Tmax_up < crop.Tmax_lo
        and crop.GDD_lo < crop.GDD_up
        and 0 < crop.CC0 < crop.CCx <= 1
        and 0 < crop.HIini < crop.HI0 <= 1
    ):
        raise RequestValidationError("native crop physical bounds are invalid")
    for stage in range(1, 5):
        if getattr(crop, f"p_up{stage}") > getattr(crop, f"p_lo{stage}"):
            raise RequestValidationError("native crop water stress thresholds invalid")
    return crop


def _native_events(
    request: SimulationRequest, key: str, amount_key: str
) -> pd.DataFrame:
    events = request.management.metadata.get(key, ())
    if not isinstance(events, (tuple, list)):
        raise RequestValidationError(f"{key} must be an explicit event sequence")
    rows = []
    for event in events:
        if not isinstance(event, Mapping):
            raise RequestValidationError(f"{key} event must be a mapping")
        try:
            event_date = date.fromisoformat(str(event["date"]))
        except (KeyError, TypeError, ValueError) as exc:
            raise RequestValidationError(f"{key} has invalid event date") from exc
        earliest = (
            request.management.planting_date
            if key == "irrigation_events"
            else request.start_date
        )
        if not earliest <= event_date <= request.end_date:
            raise RequestValidationError(f"{key} date must be in the requested season")
        try:
            amount = _native_number(event, amount_key, 0.0, 100_000.0)
        except RequestValidationError as exc:
            raise RequestValidationError(f"{key}: {exc}") from exc
        rows.append({"Date": pd.Timestamp(event_date), "Depth": amount})
    frame = pd.DataFrame(rows, columns=["Date", "Depth"])
    return frame.groupby("Date", as_index=False)["Depth"].sum()


def _native_setup(
    request: SimulationRequest,
) -> tuple[Soil, Crop, InitialWaterContent, IrrigationManagement, dict[str, Any]]:
    soil = _native_soil(request)
    crop = _native_crop(request, round(sum(soil.profile["dz"]), 2))
    sowing_population = _native_population(request)
    initial = request.environment.metadata.get("initial_conditions", {})
    if not isinstance(initial, Mapping):
        raise RequestValidationError("initial_conditions must be a mapping")
    fraction = _native_number(initial, "available_water_fraction", 0.0, 1.0)
    water = InitialWaterContent(
        wc_type="Pct",
        method="Layer",
        depth_layer=list(range(1, soil.nLayer + 1)),
        value=[fraction * 100] * soil.nLayer,
    )
    for key in ("no3_kg_ha", "nh4_kg_ha"):
        if key in initial:
            _native_number(initial, key, 0.0, 100_000.0)
    schedule = _native_events(request, "irrigation_events", "amount_mm")
    _native_events(request, "fertilizer_events", "nitrogen_kg_ha")
    assumption = request.management.irrigation_assumption
    if assumption == "irrigated_confirmed" and not len(schedule):
        raise RequestValidationError("confirmed irrigation requires irrigation_events")
    if (
        assumption in {"rainfed_confirmed", "assumed_rainfed"}
        and schedule["Depth"].sum() > 0
    ):
        raise RequestValidationError(f"irrigation_events conflict with {assumption}")
    irrigation = (
        IrrigationManagement(
            irrigation_method=3,
            Schedule=schedule,
            MaxIrr=max(25.0, float(schedule["Depth"].max())),
            MaxIrrSeason=max(10_000.0, float(schedule["Depth"].sum())),
        )
        if len(schedule)
        else IrrigationManagement(irrigation_method=0)
    )
    for key, maximum in (("sowing_depth_m", 0.5), ("row_spacing_m", 10.0)):
        if key in request.management.metadata:
            _native_number(
                request.management.metadata, key, 0.0, maximum, positive=True
            )
    limitations = [
        "AquaCrop does not model nitrogen stress: fertilizer_events, no3_kg_ha "
        "and nh4_kg_ha are retained but ignored; this is not a nitrogen-limited model.",
        "bulk_density_g_cm3, sand_pct, clay_pct and organic_carbon_pct are validated "
        "and retained per layer, not dynamic inputs with explicit hydraulics; "
        "no topsoil chemistry is copied to subsoil.",
        "sowing_depth_m and row_spacing_m are retained only: no native constructor "
        "inputs; sowing population is consumed through PlantPop (plants/ha).",
        "Custom soil uses default curve number 61, REW 9 mm and penetrability 100%; "
        "these are assumptions, not inferred from bulk density or chemistry.",
        "Irrigation is applied only while the crop is active; scheduled events after "
        "native maturity or death are retained but not applied.",
    ]
    if assumption == "unknown" and schedule.empty:
        limitations.append("Unknown irrigation is explicitly assumed rainfed.")
    elif assumption == "assumed_rainfed":
        limitations.append("Canonical assumed_rainfed is explicitly assumed rainfed.")
    if not sowing_population["verified"]:
        limitations.append(
            "Sowing population is an explicit uncertain assumption, not verified "
            "sowing or final stand: " + sowing_population["evidence_source"]
        )
    if "phenology_scale" in request.model_parameters:
        limitations.append(
            "Explicit comparator phenology_scale scales all legacy THERMAL_KEYS; "
            "supplied native stage keys take precedence over their scaled defaults."
        )
    ignored = NATIVE_IGNORED_PARAMETERS
    if any(key in request.model_parameters for key in ignored):
        limitations.append(
            "Legacy inputs ignored in cultivar mode: "
            + ", ".join(key for key in ignored if key in request.model_parameters)
        )
    snapshot = {
        "request": _plain_request(request),
        "crop": dict(crop.__dict__),
        "sowing_population": sowing_population,
        "soil_layers": [layer.to_json_dict() for layer in request.environment.soil],
        "soil_profile": soil.profile.to_dict(orient="records"),
        "soil_assumptions": {"cn": soil.cn, "rew": soil.rew, "penetrability": 100.0},
        "initial_water": dict(water.__dict__),
        "irrigation": {
            "irrigation_method": irrigation.irrigation_method,
            "schedule": schedule.to_dict(orient="records"),
            "MaxIrr": irrigation.MaxIrr,
            "MaxIrrSeason": irrigation.MaxIrrSeason,
            "AppEff": irrigation.AppEff,
        },
        "limitations": limitations,
    }
    return soil, crop, water, irrigation, snapshot


def _model_weather(
    request: SimulationRequest,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = [
        {"date": record.date, **dict(record.values)}
        for record in sorted(request.environment.weather, key=lambda item: item.date)
    ]
    weather = reference_et(
        pd.DataFrame(rows),
        latitude_deg=request.environment.latitude,
        elevation_m=float(request.environment.metadata.get("elevation_m", 0.0)),
    )
    model_weather = pd.DataFrame(
        {
            "MinTemp": weather["T2M_MIN"].to_numpy(),
            "MaxTemp": weather["T2M_MAX"].to_numpy(),
            "Precipitation": weather["PRECTOTCORR"].to_numpy(),
            "ReferenceET": weather["ReferenceET"].to_numpy(),
            "Date": pd.to_datetime(weather["date"]),
        }
    )
    return weather, model_weather


def _cache_paths(output_dir: Path, key: str) -> dict[str, Path]:
    root = output_dir / "aquacrop"
    return {
        "summary": root / f"{key}.json",
        "daily": root / f"{key}.daily.parquet",
        "crop": root / f"{key}.crop.json",
        "soil": root / f"{key}.soil.parquet",
        "native_inputs": root / f"{key}.native-inputs.json",
    }


def _cached_result(path: Path) -> SimulationResult:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return SimulationResult(
        request_id=payload["request_id"],
        adapter_name=payload["adapter_name"],
        adapter_version=payload["adapter_version"],
        status=RunStatus(payload["status"]),
        summary=payload.get("summary", {}),
        artifacts={
            name: Path(artifact_path)
            for name, artifact_path in payload.get("artifacts", {}).items()
        },
        diagnostics=payload.get("diagnostics", {}),
        failure_reason=payload.get("failure_reason"),
    )


class AquaCropAdapter:
    """Translate model-independent requests to AquaCrop 3.1.0."""

    name = ADAPTER_NAME
    version = MODEL_VERSION
    capabilities = ModelCapabilities(
        display_name="AquaCrop",
        phenology_parameter=CalibrationParameter(
            "phenology_scale", 1.0, (0.8, 1.2, 0.02), 0.005
        ),
        yield_parameter=CalibrationParameter("HI0", 0.48, (0.35, 0.55, 0.01), 0.0025),
        site_calibration_supported=True,
        site_phenology_parameter="phenology_scale_site",
        site_yield_parameter="HI0_site",
        supported_folds=(FoldStrategy.HELD_YEAR, FoldStrategy.LEAVE_SITE),
        weather_strategy=WeatherStrategy.G2F,
        scan_request_strategy=ScanRequestStrategy.PER_DATE,
        report_notes=(
            "- 开花日期采用 AquaCrop `HIstart` 首次跨越的日末代理，并非独立花粉事件。",
            "- 默认土壤仅用于探索；缺失灌溉信息按配置标记为假定雨养。",
            "- 全局校准仅拟合 `phenology_scale` 与 `HI0`；"
            "根深、灌溉和土壤水力参数固定。",
            "- `site_calibrated` 在全局参数基础上应用满足训练年数要求的站点偏移。",
        ),
    )

    @property
    def source_fingerprints(self) -> dict[str, str]:
        return {
            "adapter_source_sha256": adapter_source_fingerprint(),
            "model_source_sha256": aquacrop_source_fingerprint(),
        }

    def cache_key(self, request: SimulationRequest) -> str:
        identity = {
            "request": _plain_request(request),
            "adapter_source_sha256": self.source_fingerprints["adapter_source_sha256"],
            "model_version": self.version,
            "model_source_sha256": self.source_fingerprints["model_source_sha256"],
        }
        if _cultivar_mode(request) and "postflower_scale" in request.model_parameters:
            from snowwindow.cultivar_pragmatic import effective_native_parameters

            identity["effective_native_parameters"] = effective_native_parameters(
                "aquacrop",
                request.model_parameters,
                reference=crop_params["MaizeGDD"],
            )
        payload = json.dumps(
            identity,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def validate(self, request: SimulationRequest) -> None:
        self._validate_request(request)
        try:
            json.dumps(
                _plain_request(request),
                allow_nan=False,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            )
        except (TypeError, ValueError) as exc:
            raise RequestValidationError(str(exc)) from exc

    def _validate_request(self, request: SimulationRequest) -> None:
        parameters = dict(request.model_parameters)
        installed_version = importlib.metadata.version("aquacrop")
        requested_version = str(parameters.get("model_version", self.version))
        if installed_version != self.version or requested_version != self.version:
            raise RequestValidationError(
                "model version must be AquaCrop 3.1.0 "
                f"(installed={installed_version}, requested={requested_version})"
            )

        requested_planting = _as_date(
            parameters.get("planting_date", request.management.planting_date)
        )
        if requested_planting != request.management.planting_date:
            raise RequestValidationError(
                "requested planting date must equal management planting date"
            )
        if request.environment.environment_id != request.management.environment_id:
            raise RequestValidationError(
                "management environment does not match request environment"
            )
        if request.environment.year != request.management.planting_date.year:
            raise RequestValidationError("environment year must equal planting year")
        expected_start = date(request.environment.year, 1, 1)
        if request.start_date != expected_start:
            raise RequestValidationError(
                "simulation must start on January 1 of the planting year"
            )
        weather_end = max(record.date for record in request.environment.weather)
        if request.end_date > weather_end:
            raise RequestValidationError(
                "every calendar day in the inclusive simulation interval "
                "must have exactly one weather row"
            )
        expected_end, _ = simulation_end_for_planting(request.management.planting_date)
        if request.end_date > expected_end:
            raise RequestValidationError(
                "simulation end must be one day before the next sowing anniversary"
            )

        expected_dates = pd.date_range(request.start_date, request.end_date)
        weather_dates = [record.date for record in request.environment.weather]
        if (
            len(weather_dates) != len(expected_dates)
            or len(set(weather_dates)) != len(weather_dates)
            or set(weather_dates) != {timestamp.date() for timestamp in expected_dates}
        ):
            raise RequestValidationError(
                "every calendar day in the inclusive simulation interval "
                "must have exactly one weather row"
            )
        for record in request.environment.weather:
            if record.environment_id != request.environment.environment_id:
                raise RequestValidationError(
                    "weather environment does not match request environment"
                )
            values = record.values
            if any(name not in values for name in REQUIRED_WEATHER_VALUES):
                raise RequestValidationError("weather row is missing required values")
            try:
                numeric = {
                    name: float(values[name]) for name in REQUIRED_WEATHER_VALUES
                }
            except (TypeError, ValueError) as exc:
                raise RequestValidationError("weather values must be numeric") from exc
            if not all(math.isfinite(value) for value in numeric.values()):
                raise RequestValidationError("weather values must be finite")
            physical = (
                numeric["T2M_MIN"] <= numeric["T2M_MAX"]
                and numeric["PRECTOTCORR"] >= 0
                and 0 <= numeric["RH2M"] <= 100
                and numeric["WS2M"] >= 0
                and numeric["PS"] > 0
                and numeric["ALLSKY_SFC_SW_DWN"] >= 0
            )
            if not physical:
                raise RequestValidationError("weather values are physically invalid")

        irrigation = request.management.irrigation_assumption
        supported_irrigation = {
            "rainfed_confirmed",
            "irrigated_confirmed",
            "unknown",
        }
        if _cultivar_mode(request):
            supported_irrigation.add("assumed_rainfed")
        if irrigation not in supported_irrigation:
            raise RequestValidationError("unsupported irrigation assumption")
        if _cultivar_mode(request):
            _native_setup(request)
            if not isinstance(parameters.get("save_daily", False), bool):
                raise RequestValidationError("save_daily must be boolean")
            moisture = _number(
                parameters,
                "grain_standard_moisture_fraction",
                0.155,
                minimum=0.0,
                maximum=1.0,
            )
            if not math.isclose(moisture, 0.155, abs_tol=1e-12):
                raise RequestValidationError(
                    "grain_standard_moisture_fraction must equal 0.155"
                )
            return
        irrigation_smt = parameters.get("irrigation_smt", [70, 75, 80, 70])
        if (
            not isinstance(irrigation_smt, (list, tuple))
            or len(irrigation_smt) != 4
            or any(
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or not 0 <= float(value) <= 100
                for value in irrigation_smt
            )
        ):
            raise RequestValidationError(
                "irrigation_smt must contain four percentages in [0, 100]"
            )

        soil_depth = _number(parameters, "soil_depth_m", 2.0, minimum=0.2, maximum=5.0)
        compartment = _number(
            parameters,
            "soil_compartment_m",
            0.1,
            minimum=0.05,
            maximum=0.5,
        )
        count = round(soil_depth / compartment)
        if not math.isclose(count * compartment, soil_depth, abs_tol=1e-9):
            raise RequestValidationError(
                "soil depth must be divisible by compartment thickness"
            )
        if len(request.environment.soil) > 1:
            raise RequestValidationError(
                "only one homogeneous AquaCrop soil layer is supported"
            )
        if request.environment.soil:
            layer = request.environment.soil[0]
            if not math.isclose(layer.top_depth_m, 0.0, abs_tol=1e-9) or not (
                math.isclose(layer.bottom_depth_m, soil_depth, abs_tol=1e-9)
            ):
                raise RequestValidationError(
                    "soil layer must span the configured profile depth"
                )

        crop = str(parameters.get("crop", DEFAULT_CROP))
        if crop not in crop_params:
            raise RequestValidationError(f"unsupported AquaCrop crop: {crop}")
        _number(
            parameters,
            "phenology_scale",
            1.0,
            minimum=0.1,
            maximum=3.0,
            minimum_inclusive=False,
        )
        _number(
            parameters,
            "phenology_scale_site",
            1.0,
            minimum=0.0,
            maximum=4.0,
            minimum_inclusive=False,
        )
        _number(
            parameters,
            "HI0",
            float(crop_params[crop]["HI0"]),
            minimum=0.0,
            maximum=1.0,
            minimum_inclusive=False,
        )
        _number(
            parameters,
            "HI0_site",
            1.0,
            minimum=0.0,
            maximum=4.0,
            minimum_inclusive=False,
        )
        _number(
            parameters,
            "initial_available_water_pct",
            50.0,
            minimum=0.0,
            maximum=100.0,
        )
        _number(
            parameters,
            "root_depth_scale",
            1.0,
            minimum=0.0,
            maximum=3.0,
            minimum_inclusive=False,
        )
        default_population = (
            request.management.population_plants_m2 * 10_000
            if request.management.population_plants_m2 is not None
            else 75_000.0
        )
        _number(
            parameters,
            "plant_population_ha",
            default_population,
            minimum=0.0,
            maximum=10_000_000.0,
            minimum_inclusive=False,
        )
        if not isinstance(parameters.get("save_daily", False), bool):
            raise RequestValidationError("save_daily must be boolean")
        moisture_fraction = _number(
            parameters,
            "grain_standard_moisture_fraction",
            0.155,
            minimum=0.0,
            maximum=1.0,
        )
        if not math.isclose(moisture_fraction, 0.155, abs_tol=1e-12):
            raise RequestValidationError(
                "grain_standard_moisture_fraction must equal 0.155"
            )
        try:
            soil = Soil(
                _soil_type(request, parameters),
                dz=[compartment] * count,
            )
        except Exception as exc:
            raise RequestValidationError(
                "unsupported AquaCrop soil/profile assumptions"
            ) from exc
        profile = soil.profile
        if not (
            (profile["th_wp"] < profile["th_fc"]) & (profile["th_fc"] < profile["th_s"])
        ).all():
            raise RequestValidationError("unsupported AquaCrop soil hydraulic ordering")

    def smoke(self) -> dict[str, Any]:
        """Run AquaCrop's bundled reference example through the pinned engine."""

        if importlib.metadata.version("aquacrop") != self.version:
            raise RuntimeError("AquaCrop version mismatch")
        model = AquaCropModel(
            "1979/10/01",
            "1980/05/30",
            prepare_weather(get_filepath("tunis_climate.txt")),
            Soil("SandyLoam"),
            Crop("Wheat", "10/01"),
            InitialWaterContent(value=["FC"]),
        )
        model.run_model(
            till_termination=True,
            initialize_model=True,
            process_outputs=False,
        )
        results = model.get_simulation_results()
        if len(results) != 1:
            raise RuntimeError("bundled AquaCrop smoke example returned no season")
        dry_yield = float(results["Dry yield (tonne/ha)"].iloc[0])
        if not math.isfinite(dry_yield):
            raise RuntimeError("bundled AquaCrop smoke example returned invalid yield")
        return {
            "model_version": self.version,
            "model_source_sha256": self.source_fingerprints["model_source_sha256"],
            "dry_yield_mg_ha": dry_yield,
        }

    def run(self, request: SimulationRequest) -> SimulationResult:
        started = time.perf_counter()
        try:
            self.validate(request)
        except RequestValidationError as exc:
            return SimulationResult(
                request_id=request.request_id,
                adapter_name=self.name,
                adapter_version=self.version,
                status=RunStatus.INVALID_INPUT,
                diagnostics={
                    "cache_hit": False,
                    "traceback": traceback.format_exc(),
                },
                failure_reason=str(exc),
            )
        except Exception as exc:
            return SimulationResult(
                request_id=request.request_id,
                adapter_name=self.name,
                adapter_version=self.version,
                status=RunStatus.EXECUTION_FAILED,
                diagnostics={
                    "cache_hit": False,
                    "traceback": traceback.format_exc(),
                },
                failure_reason=str(exc),
            )

        try:
            key = self.cache_key(request)
        except (TypeError, ValueError) as exc:
            return SimulationResult(
                request_id=request.request_id,
                adapter_name=self.name,
                adapter_version=self.version,
                status=RunStatus.INVALID_INPUT,
                diagnostics={
                    "cache_hit": False,
                    "traceback": traceback.format_exc(),
                },
                failure_reason=str(exc),
            )
        except Exception as exc:
            return SimulationResult(
                request_id=request.request_id,
                adapter_name=self.name,
                adapter_version=self.version,
                status=RunStatus.EXECUTION_FAILED,
                diagnostics={
                    "cache_hit": False,
                    "traceback": traceback.format_exc(),
                },
                failure_reason=str(exc),
            )
        save_daily = bool(request.model_parameters.get("save_daily", False))
        cultivar = _cultivar_mode(request)
        paths = (
            _cache_paths(request.output_dir, key)
            if request.output_dir is not None
            else None
        )
        if paths is not None and paths["summary"].is_file():
            try:
                cached = _cached_result(paths["summary"])
            except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
                cached = None
            if cached is not None:
                requested_artifacts_exist = not save_daily or all(
                    paths[name].is_file() for name in ("daily", "crop", "soil")
                )
                if cultivar:
                    requested_artifacts_exist = requested_artifacts_exist and all(
                        paths[name].is_file()
                        for name in ("native_inputs", "crop", "soil")
                    )
                if (
                    cached.status
                    not in {
                        RunStatus.EXECUTION_FAILED,
                        RunStatus.INVALID_INPUT,
                        RunStatus.MODEL_LIMIT,
                        RunStatus.INSUFFICIENT_THERMAL_TIME,
                    }
                    and requested_artifacts_exist
                ):
                    diagnostics = dict(cached.diagnostics)
                    diagnostics["cache_hit"] = True
                    result = SimulationResult(
                        request_id=request.request_id,
                        adapter_name=cached.adapter_name,
                        adapter_version=cached.adapter_version,
                        status=cached.status,
                        summary=cached.summary,
                        artifacts=cached.artifacts,
                        diagnostics=diagnostics,
                        failure_reason=cached.failure_reason,
                    )
                    try:
                        _atomic_json(paths["summary"], result.to_json_dict())
                        return result
                    except Exception as exc:
                        return SimulationResult(
                            request_id=request.request_id,
                            adapter_name=self.name,
                            adapter_version=self.version,
                            status=RunStatus.EXECUTION_FAILED,
                            diagnostics={
                                "cache_hit": False,
                                "cache_key": key,
                                **self.source_fingerprints,
                                "traceback": traceback.format_exc(),
                            },
                            failure_reason=str(exc),
                        )

        native_snapshot = None
        native_soil_profile = None
        try:
            if cultivar:
                native_soil, _, _, _, native_snapshot = _native_setup(request)
                native_soil_profile = native_soil.profile.copy()
                native_snapshot["source_fingerprints"] = self.source_fingerprints
                native_snapshot["cache_key"] = key
                _, weather_inputs = _model_weather(request)
                native_snapshot["weather"] = weather_inputs.to_dict(orient="records")
            status, summary, daily, crop_values, soil_profile = self._run_model(request)
            failure_reason = None
            diagnostics = {
                "cache_hit": False,
                "cache_key": key,
                **self.source_fingerprints,
            }
        except Exception as exc:
            status = map_exception_status(exc)
            summary = {
                "dry_yield_mg_ha": None,
                "yield_at_15p5_mg_ha": None,
            }
            daily = None
            crop_values = None
            soil_profile = None
            failure_reason = str(exc)
            diagnostics = {
                "cache_hit": False,
                "cache_key": key,
                **self.source_fingerprints,
                "traceback": traceback.format_exc(),
            }

        if native_snapshot is not None:
            diagnostics["native_input_limitations"] = native_snapshot["limitations"]
            if "postflower_scale" in request.model_parameters:
                diagnostics["postflower_scale"] = request.model_parameters[
                    "postflower_scale"
                ]
                diagnostics["effective_native_parameters"] = {
                    name: native_snapshot["crop"][name]
                    for name in (
                        "HIstart",
                        "HI0",
                        "Maturity",
                        "Senescence",
                        "MaxRooting",
                        "YldForm",
                        "Flowering",
                    )
                }
                native_snapshot["postflower_scale"] = diagnostics["postflower_scale"]
                native_snapshot["effective_native_parameters"] = diagnostics[
                    "effective_native_parameters"
                ]
                calendar = summary.get("derived_canopy_calendar")
                if calendar:
                    diagnostics["derived_canopy_calendar"] = calendar
                    native_snapshot["derived_canopy_calendar"] = calendar
            if "native_terminal_state" in summary:
                diagnostics["native_terminal_state"] = summary["native_terminal_state"]
            summary["nitrogen_stress_modeled"] = False
        summary["elapsed_seconds"] = time.perf_counter() - started
        artifacts: dict[str, Path] = {}
        if paths is not None:
            try:
                artifacts["summary"] = paths["summary"]
                if native_snapshot is not None:
                    _atomic_json(paths["native_inputs"], native_snapshot)
                    _atomic_json(paths["crop"], native_snapshot["crop"])
                    _atomic_parquet(paths["soil"], native_soil_profile)
                    artifacts.update(
                        native_inputs=paths["native_inputs"],
                        crop=paths["crop"],
                        soil=paths["soil"],
                    )
                if save_daily and daily is not None:
                    _atomic_parquet(paths["daily"], daily)
                    _atomic_json(paths["crop"], crop_values)
                    _atomic_parquet(paths["soil"], soil_profile)
                    artifacts.update(
                        daily=paths["daily"],
                        crop=paths["crop"],
                        soil=paths["soil"],
                    )
                result = SimulationResult(
                    request_id=request.request_id,
                    adapter_name=self.name,
                    adapter_version=self.version,
                    status=status,
                    summary=summary,
                    artifacts=artifacts,
                    diagnostics=diagnostics,
                    failure_reason=failure_reason,
                )
                _atomic_json(paths["summary"], result.to_json_dict())
                return result
            except Exception as exc:
                return SimulationResult(
                    request_id=request.request_id,
                    adapter_name=self.name,
                    adapter_version=self.version,
                    status=RunStatus.EXECUTION_FAILED,
                    summary={
                        "dry_yield_mg_ha": None,
                        "yield_at_15p5_mg_ha": None,
                        "elapsed_seconds": time.perf_counter() - started,
                    },
                    diagnostics={
                        "cache_hit": False,
                        "cache_key": key,
                        **self.source_fingerprints,
                        "traceback": traceback.format_exc(),
                    },
                    failure_reason=str(exc),
                )
        return SimulationResult(
            request_id=request.request_id,
            adapter_name=self.name,
            adapter_version=self.version,
            status=status,
            summary=summary,
            artifacts=artifacts,
            diagnostics=diagnostics,
            failure_reason=failure_reason,
        )

    def _run_model(
        self, request: SimulationRequest
    ) -> tuple[
        RunStatus,
        dict[str, Any],
        pd.DataFrame,
        dict[str, Any],
        pd.DataFrame,
    ]:
        parameters = dict(request.model_parameters)
        crop_name = str(parameters.get("crop", DEFAULT_CROP))
        base = dict(crop_params[crop_name])
        cultivar = _cultivar_mode(request)
        if cultivar:
            native_soil, native_crop, native_water, native_irrigation, _ = (
                _native_setup(request)
            )
        phenology_scale = float(parameters.get("phenology_scale", 1.0))
        hi0 = float(parameters.get("HI0", base["HI0"]))
        phenology_site_scale = (
            1.0 if cultivar else float(parameters.get("phenology_scale_site", 1.0))
        )
        hi0_site = 1.0 if cultivar else float(parameters.get("HI0_site", 1.0))
        if not 0 < phenology_site_scale <= 4:
            raise ValueError("phenology_scale_site must be in (0, 4]")
        if not 0 < hi0_site <= 4:
            raise ValueError("HI0_site must be in (0, 4]")
        effective_phenology_scale = phenology_scale * phenology_site_scale
        effective_hi0 = hi0 * hi0_site
        water_pct = (
            native_water.value[0]
            if cultivar
            else float(parameters.get("initial_available_water_pct", 50.0))
        )
        root_scale = 1.0 if cultivar else float(parameters.get("root_depth_scale", 1.0))
        population = float(
            parameters.get(
                "plant_population_ha",
                (
                    request.management.population_plants_m2 * 10_000
                    if request.management.population_plants_m2 is not None
                    else base["PlantPop"]
                ),
            )
        )
        soil_depth = float(parameters.get("soil_depth_m", 2.0))
        if cultivar:
            population = native_crop.PlantPop
            soil_depth = round(sum(native_soil.profile["dz"]), 2)
        compartment = float(parameters.get("soil_compartment_m", 0.1))
        irrigation_smt = (
            []
            if cultivar
            else [
                float(value)
                for value in parameters.get("irrigation_smt", (70, 75, 80, 70))
            ]
        )
        irrigation_management = (
            IrrigationManagement(
                irrigation_method=1,
                SMT=irrigation_smt,
                MaxIrr=50.0,
            )
            if request.management.irrigation_assumption == "irrigated_confirmed"
            else IrrigationManagement(irrigation_method=0)
        )
        if cultivar:
            irrigation_management = native_irrigation
        moisture_fraction = float(
            parameters.get("grain_standard_moisture_fraction", 0.155)
        )
        dz = [compartment] * round(soil_depth / compartment)
        if cultivar:
            soil = native_soil
            dz = soil.profile["dz"].tolist()
        else:
            soil = Soil(_soil_type(request, parameters), dz=dz)
        profile = soil.profile.copy()
        theta_initial = (
            profile["th_wp"].to_numpy()
            + water_pct / 100 * (profile["th_fc"] - profile["th_wp"]).to_numpy()
        )

        crop_kwargs = {
            key: float(base[key]) * effective_phenology_scale for key in THERMAL_KEYS
        }
        root_cap = soil_depth - 0.1
        effective_root_depth = min(float(base["Zmax"]) * root_scale, root_cap)
        crop_kwargs.update(
            HI0=effective_hi0,
            PlantPop=population,
            Zmax=effective_root_depth,
        )
        if cultivar:
            crop_kwargs = {
                key: getattr(native_crop, key)
                for key in (*THERMAL_KEYS, "HI0", "PlantPop", "Zmax")
            }
            effective_root_depth = native_crop.Zmax
        simulation_end, leap_adjusted = simulation_end_for_planting(
            request.management.planting_date
        )
        harvest_rule = None
        crop = (
            native_crop
            if cultivar
            else Crop(
                crop_name,
                request.management.planting_date.strftime("%m/%d"),
                harvest_date=request.end_date.strftime("%m/%d"),
                **crop_kwargs,
            )
        )
        harvest_rule = request.end_date.strftime("%m/%d")
        crop.harvest_date = harvest_rule
        crop.PlantTrigger = None
        effective_crop = dict(crop.__dict__)

        weather, model_weather = _model_weather(request)
        model_class = _CultivarModel if cultivar else AquaCropModel
        model = model_class(
            request.start_date.strftime("%Y/%m/%d"),
            request.end_date.strftime("%Y/%m/%d"),
            model_weather,
            soil,
            crop,
            (
                native_water
                if cultivar
                else InitialWaterContent(
                    wc_type="Pct",
                    method="Layer",
                    depth_layer=[1],
                    value=[water_pct],
                )
            ),
            irrigation_management=irrigation_management,
            off_season=True,
        )
        model.run_model(till_termination=True)
        if not np.allclose(soil.profile["dz"].to_numpy(), dz, rtol=0, atol=1e-12):
            raise ValueError(
                "engine changed soil geometry; lower root buffer was insufficient"
            )

        statistics = model.get_simulation_results()
        growth = model.get_crop_growth().copy()
        flux = model.get_water_flux().copy()
        storage = model.get_water_storage().copy()
        simulated_indices = np.flatnonzero(growth["time_step_counter"].to_numpy() > 0)
        count = int(simulated_indices[-1] + 1) if len(simulated_indices) else 1
        growth = growth.iloc[:count].copy()
        flux = flux.iloc[:count].copy()
        storage = storage.iloc[:count].copy()
        expected_steps = np.arange(count)
        for frame in (growth, flux, storage):
            if not np.array_equal(
                frame["time_step_counter"].to_numpy(), expected_steps
            ):
                raise ValueError("AquaCrop output time-step alignment failed")

        daily = growth.copy()
        for column in flux:
            if column not in daily:
                daily[column] = flux[column].to_numpy()
        daily["growing_season"] = storage["growing_season"].to_numpy().astype(bool)
        for column in storage:
            if column.startswith("th"):
                daily[column] = storage[column].to_numpy()
        daily["Date"] = pd.date_range(request.start_date, periods=count)
        daily["Precipitation_mm_day"] = weather["PRECTOTCORR"].iloc[:count].to_numpy()
        daily["ET0_unclipped_mm_day"] = (
            weather["ET0_unclipped_mm_day"].iloc[:count].to_numpy()
        )
        daily["ReferenceET_mm_day"] = weather["ReferenceET"].iloc[:count].to_numpy()
        if cultivar:
            biology = pd.DataFrame(model.native_biology)
            if not np.array_equal(
                biology["time_step_counter"].to_numpy(), expected_steps
            ):
                raise ValueError("native biology time-step alignment failed")
            for column in biology:
                if column != "time_step_counter":
                    daily[column] = biology[column].to_numpy()

        theta_columns = [f"th{number + 1}" for number in range(len(dz))]
        theta = daily[theta_columns].to_numpy()
        daily["soil_water_mm"] = (theta * np.asarray(dz) * 1000).sum(axis=1)
        initial_storage = float((theta_initial * np.asarray(dz) * 1000).sum())
        total_storage = (
            daily["soil_water_mm"].to_numpy() + daily["surface_storage"].to_numpy()
        )
        storage_change = total_storage - np.r_[initial_storage, total_storage[:-1]]
        net_flux = (
            daily["Precipitation_mm_day"]
            + daily["IrrDay"]
            + daily["CR"]
            + daily["GwIn"]
            - daily["Runoff"]
            - daily["DeepPerc"]
            - daily["TileDrain"]
            - daily["Es"]
            - daily["Tr"]
        )
        daily["water_balance_residual_mm"] = storage_change - net_flux.to_numpy()

        active = daily.loc[daily["growing_season"]]
        actual_sowing = active["Date"].iloc[0].date() if not active.empty else None
        if actual_sowing != request.management.planting_date:
            raise ValueError("actual sowing date differs from requested intervention")
        preplant = daily.loc[
            daily["Date"] < pd.Timestamp(request.management.planting_date)
        ]
        condition = model._init_cond
        status = map_crop_state(
            condition.crop_mature,
            condition.crop_dead,
            condition.germination,
        )
        maturity_reached = not active.empty and float(active["gdd_cum"].max()) >= float(
            crop_kwargs["Maturity"]
        )
        forced_maturity_rejected = False
        if cultivar:
            germinated = bool(active["native_germinated"].any())
            maturity_reached = germinated and float(
                active["native_development_gdd"].max()
            ) >= float(crop_kwargs["Maturity"])
            if not germinated:
                status = RunStatus.NOT_GERMINATED
            elif condition.crop_dead:
                status = RunStatus.CROP_DIED
            elif condition.crop_mature and maturity_reached:
                status = RunStatus.MATURED
            else:
                status = RunStatus.NOT_MATURED
            forced_maturity_rejected = (
                bool(condition.crop_mature) and status is not RunStatus.MATURED
            )

        if len(statistics) and pd.notna(
            statistics["Harvest Date (YYYY/MM/DD)"].iloc[0]
        ):
            termination_date = pd.Timestamp(
                statistics["Harvest Date (YYYY/MM/DD)"].iloc[0]
            )
        else:
            termination_date = daily["Date"].iloc[-1] + pd.Timedelta(days=1)
        if len(statistics):
            dry_yield = float(statistics["Dry yield (tonne/ha)"].iloc[0])
        elif not active.empty:
            dry_yield = float(active["DryYield"].iloc[-1])
        else:
            dry_yield = 0.0
        flowering = (
            active.loc[
                active["native_germinated"]
                & (active["native_development_gdd"] >= float(crop_kwargs["HIstart"]))
            ]
            if cultivar
            else active.loc[active["gdd_cum"] >= float(crop_kwargs["HIstart"])]
        )
        flowering_date = (
            flowering["Date"].iloc[0] + pd.Timedelta(days=1)
            if not flowering.empty
            else None
        )
        summary = {
            "cache_key": self.cache_key(request),
            "model_version": self.version,
            "crop": crop_name,
            "parameter_set_id": request.parameter_set_id,
            "phenology_scale": phenology_scale,
            "HI0": hi0,
            "phenology_scale_site": phenology_site_scale,
            "HI0_site": hi0_site,
            "effective_phenology_scale": effective_phenology_scale,
            "effective_HI0": effective_hi0,
            "initial_available_water_pct": water_pct,
            "root_depth_scale": root_scale,
            "plant_population_ha": population,
            "irrigation_method": (
                "soil_moisture_target"
                if request.management.irrigation_assumption == "irrigated_confirmed"
                else "rainfed"
            ),
            "irrigation_smt": irrigation_smt,
            "simulation_start_date": request.start_date.isoformat(),
            "simulation_end_date": simulation_end.isoformat(),
            "configured_harvest_rule": harvest_rule,
            "leap_day_harvest_rule_adjusted": leap_adjusted,
            "requested_sowing_date": request.management.planting_date.isoformat(),
            "actual_sowing_date": actual_sowing.isoformat(),
            "last_simulated_date": daily["Date"].iloc[-1].date().isoformat(),
            "termination_date": termination_date.date().isoformat(),
            "maturity_date": (
                termination_date.date().isoformat()
                if status is RunStatus.MATURED
                else None
            ),
            "termination_reason": (
                status.value
                if status is not RunStatus.NOT_MATURED
                else "anniversary cutoff before maturity"
            ),
            "dry_yield_mg_ha": dry_yield,
            "yield_at_15p5_mg_ha": dry_yield / (1 - moisture_fraction),
            "biomass_mg_ha": float(daily["biomass"].max() / 100),
            "flowering_proxy_date": (
                flowering_date.date().isoformat()
                if flowering_date is not None
                else None
            ),
            "flowering_proxy_dap": (
                (flowering_date.date() - request.management.planting_date).days
                if flowering_date is not None
                else None
            ),
            "flowering_proxy_note": (
                "first end-of-day crossing of HIstart; not an independent pollen event"
            ),
            "seasonal_precipitation_mm": float(active["Precipitation_mm_day"].sum()),
            "seasonal_irrigation_mm": float(active["IrrDay"].sum()),
            "seasonal_evaporation_mm": float(active["Es"].sum()),
            "seasonal_transpiration_mm": float(active["Tr"].sum()),
            "seasonal_et_mm": float((active["Es"] + active["Tr"]).sum()),
            "initial_soil_water_mm": initial_storage,
            "preplant_days_simulated": len(preplant),
            "day_before_planting_soil_water_mm": (
                float(preplant["soil_water_mm"].iloc[-1]) if len(preplant) else None
            ),
            "preplant_soil_water_range_mm": (
                float(preplant["soil_water_mm"].max() - preplant["soil_water_mm"].min())
                if len(preplant)
                else 0.0
            ),
            "soil_water_bounds_ok": bool(
                (theta >= profile["th_dry"].to_numpy() - 1e-6).all()
                and (theta <= profile["th_s"].to_numpy() + 1e-6).all()
            ),
            "soil_profile_depth_m": soil_depth,
            "soil_compartment_m": compartment,
            "soil_type": _soil_type(request, parameters),
            "effective_max_root_depth_m": effective_root_depth,
            "root_depth_clipped_by_profile": (
                float(base["Zmax"]) * root_scale > root_cap
            ),
            "max_simulated_root_depth_m": (
                float(active["z_root"].max()) if len(active) else 0.0
            ),
            "water_balance_max_abs_mm_day": float(
                daily["water_balance_residual_mm"].abs().max()
            ),
            "water_balance_total_residual_mm": float(
                daily["water_balance_residual_mm"].sum()
            ),
            "et0_unclipped_min_mm_day": float(daily["ET0_unclipped_mm_day"].min()),
            "et0_model_input_min_mm_day": float(daily["ReferenceET_mm_day"].min()),
        }
        if cultivar:
            for key in (
                "phenology_scale",
                "phenology_scale_site",
                "HI0_site",
                "effective_phenology_scale",
                "root_depth_scale",
                "irrigation_smt",
            ):
                summary.pop(key, None)
            summary.update(
                parameterization="native_cultivar",
                phenology_parameterization="native",
                cultivar_id=request.management.cultivar_id,
                population_verified=_native_population(request)["verified"],
                population_evidence_source=_native_population(request)[
                    "evidence_source"
                ],
                native_maturity_reached=bool(maturity_reached),
                forced_maturity_rejected=bool(forced_maturity_rejected),
                native_terminal_state={
                    "crop_mature": bool(condition.crop_mature),
                    "crop_dead": bool(condition.crop_dead),
                    "germination": bool(condition.germination),
                    "delayed_cds": int(condition.delayed_cds),
                    "delayed_gdds": float(condition.delayed_gdds),
                    "raw_gdd_cum": float(condition.gdd_cum),
                    "development_gdd": max(
                        0.0, float(condition.gdd_cum - condition.delayed_gdds)
                    ),
                    "yield_form": bool(condition.yield_form),
                },
                native_maturity_rejection_reason=(
                    (
                        "no_native_germination"
                        if not germinated
                        else (
                            "native_crop_dead"
                            if condition.crop_dead
                            else "germination_adjusted_heat_below_maturity"
                        )
                    )
                    if forced_maturity_rejected
                    else None
                ),
                native_yield_form_date=(
                    (
                        active.loc[
                            active["native_germinated"] & active["native_yield_form"],
                            "Date",
                        ].iloc[0]
                        + pd.Timedelta(days=1)
                    )
                    .date()
                    .isoformat()
                    if (active["native_germinated"] & active["native_yield_form"]).any()
                    else None
                ),
                nitrogen_stress_modeled=False,
                irrigation_method=(
                    "schedule"
                    if irrigation_management.irrigation_method == 3
                    else "rainfed"
                ),
                irrigation_assumption=(
                    "assumed_rainfed"
                    if request.management.irrigation_assumption == "unknown"
                    and irrigation_management.irrigation_method == 0
                    else request.management.irrigation_assumption
                ),
                soil_type="custom",
                simulation_end_date=request.end_date.isoformat(),
                root_depth_clipped_by_profile=(
                    "Zmax" not in parameters and float(base["Zmax"]) > root_cap
                ),
                flowering_proxy_note=(
                    "first germinated end-of-day crossing of germination-adjusted "
                    "native HIstart (gdd_cum - delayed_gdds); "
                    "not independent pollen or silking events"
                ),
            )
            if "postflower_scale" in parameters:
                summary["derived_canopy_calendar"] = {
                    name: getattr(crop, name)
                    for name in (
                        "MaxCanopy",
                        "CanopyDevEnd",
                        "MaxCanopyCD",
                        "CanopyDevEndCD",
                        "HIstartCD",
                        "MaturityCD",
                        "SenescenceCD",
                        "MaxRootingCD",
                        "YldFormCD",
                        "FloweringCD",
                    )
                    if hasattr(crop, name)
                }
            if "phenology_scale" in parameters:
                summary.update(
                    phenology_scale=phenology_scale,
                    phenology_parameterization=(
                        "scaled_native_overrides"
                        if any(key in parameters for key in THERMAL_KEYS)
                        else "legacy_thermal_scale"
                    ),
                )
            if status is RunStatus.NOT_MATURED:
                summary["termination_reason"] = (
                    "simulation cutoff before native maturity"
                )
        if not math.isfinite(dry_yield) or not summary["soil_water_bounds_ok"]:
            raise ValueError("AquaCrop returned invalid yield or soil-water bounds")
        if summary["water_balance_max_abs_mm_day"] > 1:
            raise ValueError("water-balance residual exceeds 1 mm/day")
        return status, summary, daily, effective_crop, profile
