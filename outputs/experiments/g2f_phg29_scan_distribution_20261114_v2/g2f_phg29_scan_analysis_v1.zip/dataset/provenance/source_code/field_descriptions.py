"""Chinese descriptions for the frozen PHG29 scan schema."""

from __future__ import annotations

BASE = {
    "approximate_weather_days_used": ("使用近似天气的日数，当前全部为零", "day"),
    "artifacts": ("原运行产物路径的 JSON；所指缓存/逐日文件未随包分发", "JSON"),
    "attempts": ("执行尝试次数，延长时合计初次与延长运行的尝试", "count"),
    "continuation_recovered": ("跨年重跑后达到自然成熟且产量非空", "boolean"),
    "continuation_request_fingerprint": (
        "跨年延长请求内容的 SHA-256；未延长时为空",
        "SHA-256",
    ),
    "cross_year_extended": ("是否使用同初始状态的更长窗口重跑", "boolean"),
    "cultivar_id": ("玉米品种身份，固定为 PHG29/PHG47", "identifier"),
    "days_available_after_sowing": ("播期至请求模拟终点的日数，含首尾", "day"),
    "dry_yield_mg_ha": ("经过自然成熟筛选的模型干产量；有效零值保留", "Mg/ha"),
    "elapsed_seconds_batch_per_request": (
        "批运行时间除以请求数，不是逐请求独立计时",
        "second",
    ),
    "environment_id": ("年度环境身份，关联环境表", "identifier"),
    "failure_reason": ("原模型/执行失败原因；空原因不保证所有字段有效", "text"),
    "first_pass_end_date": ("初次同年请求终点", "ISO date"),
    "first_pass_record": ("延长前完整记录的 JSON；未延长时为空", "JSON"),
    "first_pass_status": ("跨年处理前的第一次运行结局", "category"),
    "flowering_date": ("模型报告的物候代理日期，跨模型事件定义不同", "ISO date"),
    "forced_maturity": ("检测、排除或拒绝强制成熟相关事件的诊断标识", "boolean"),
    "horizon_limited": (
        "当前实现中为 status=not_matured，不保证延长后可成熟",
        "boolean",
    ),
    "irrigation_assumption": (
        "assumed_rainfed 或 rainfed_confirmed 的证据分类",
        "category",
    ),
    "maturity_date": ("模型报告的成熟日期，须结合自然成熟判定", "ISO date"),
    "model": ("模型标识 apsim/aquacrop/dssat", "identifier"),
    "model_version": ("执行模型的版本", "text"),
    "namespace": ("冻结实验命名空间/清单指纹", "SHA-256"),
    "native_diagnostics": ("原生状态、输入和执行诊断的 JSON", "JSON"),
    "native_summary": ("完整原生摘要 JSON，展开列由此派生", "JSON"),
    "native_yield_mg_ha": ("适配器报告的干产量，未按自然成熟筛选", "Mg/ha"),
    "natural_maturity": ("成熟且无强制成熟标识的统一判定，不保证产量非空", "boolean"),
    "planting_date": ("本行模拟播期，通常为反事实日期", "ISO date"),
    "pollen_dap": ("APSIM/AquaCrop 物候代理 DAP，非独立实测散粉", "day after planting"),
    "request_fingerprint": (
        "原播期请求输入内容的 SHA-256，延长后仍保留原请求值",
        "SHA-256",
    ),
    "request_id": ("派生模拟请求标识，不是 G2F 原生键", "identifier"),
    "silk_dap": ("DSSAT 75% 吐丝代理 DAP，不是散粉日期", "day after planting"),
    "simulation_end_date": ("最终请求模拟终点，可能为跨年延长终点", "ISO date"),
    "simulation_start_date": ("最终请求模拟起点，不等于实际出苗日期", "ISO date"),
    "soil_input_tier": (
        "土壤证据分类，当前全部 texture_prior_not_measured",
        "category",
    ),
    "status": ("最终运行结局：成熟/死亡/未成熟/执行失败", "category"),
    "thermal_time_initialization_limited": (
        "是否报告初始化积温不足结局，当前全假",
        "boolean",
    ),
    "year": ("环境及播种所属年，不随跨年成熟改变", "year"),
    "site_id": ("年度环境所对应的站点映射", "identifier"),
    "planting_date_dt": ("planting_date 的日期类型副本", "datetime"),
    "flowering_date_dt": ("flowering_date 的日期类型副本，事件限制不变", "datetime"),
    "maturity_date_dt": ("maturity_date 的日期类型副本，状态限制不变", "datetime"),
}

# Native parameter units are taken from the archived final protocol's catalog.
PARAMETERS = {
    "flag_leaf_tt": "旗叶阶段积温目标",
    "flowering_to_grain_fill_tt": "开花至灌浆积温目标",
    "grain_fill_tt": "灌浆阶段积温目标",
    "juvenile_tt": "幼年阶段积温目标",
    "maximum_grain_size_g": "最大单粒质量参数",
    "photoperiod_sensitivity": "模型光周期敏感性参数",
    "potential_grain_number": "潜在籽粒数参数",
    "HI0": "名义参考收获指数",
    "G2": "DSSAT 潜在籽粒数参数",
    "G3": "DSSAT 籽粒生长速率参数",
    "P1": "DSSAT 幼年阶段积温参数",
    "P2": "DSSAT 光周期响应参数",
    "P5": "DSSAT 灌浆阶段积温参数",
    "PHINT": "DSSAT 叶片出现间隔积温参数",
}

NATIVE = {
    "actual_simulation_dates_source": ("实际模拟日期的证据来源", "text"),
    "actual_simulation_end_date": ("引擎实际执行终点", "ISO date"),
    "actual_simulation_start_date": ("引擎实际执行起点", "ISO date"),
    "biomass_mg_ha": ("模型生物量摘要，需核对统计时点", "Mg/ha"),
    "clock_completed": ("模型时钟执行完成，不等于作物自然成熟", "boolean"),
    "dry_yield_mg_ha": ("原生干产量摘要，尚未经过统一自然成熟筛选", "Mg/ha"),
    "flowering_date": ("原模型开花/物候事件报告日期", "ISO date"),
    "flowering_proxy_dap": ("模型特定物候代理的播后日数", "day after planting"),
    "grain_number_scale": ("APSIM 籽粒数缩放参数", "dimensionless"),
    "harvest_date": ("模型收获日期，不等同于生理成熟", "ISO date"),
    "harvest_ripe_date": ("模型可收获成熟阶段日期", "ISO date"),
    "maturity_date": ("原模型成熟日期报告", "ISO date"),
    "maturity_date_quality": ("成熟日期的事件质量标记", "category"),
    "maturity_date_source": ("成熟日期证据来源", "text"),
    "planting_date": ("原生摘要中的播期", "ISO date"),
    "termination_rule": ("原模型终止规则；clock_end 不代表自然成熟", "category"),
    "actual_sowing_date": ("引擎实际播种日期", "ISO date"),
    "cache_key": ("原引擎缓存标识；缓存未随包分发", "identifier"),
    "configured_harvest_rule": ("配置的收获规则，非成熟事件本身", "text"),
    "crop": ("原模型作物名称", "text"),
    "cultivar_id": ("原模型摘要的品种标识", "identifier"),
    "day_before_planting_soil_water_mm": ("播种前一天模拟土壤水量", "mm"),
    "effective_HI0": ("实际引擎使用的有效收获指数", "dimensionless"),
    "effective_max_root_depth_m": ("引擎实际采用的最大根深", "m"),
    "elapsed_seconds": ("原模型运行耗时", "second"),
    "et0_model_input_min_mm_day": ("进入引擎的 ET0 日值最小值", "mm/day"),
    "et0_unclipped_min_mm_day": ("裁剪前 ET0 日值最小值", "mm/day"),
    "flowering_proxy_date": ("模型特定物候代理日期", "ISO date"),
    "flowering_proxy_note": ("物候代理定义和不等于独立散粉/吐丝的说明", "text"),
    "forced_maturity_rejected": ("强制成熟相关输出是否被拒绝", "boolean"),
    "initial_available_water_pct": ("参考初始可利用水百分比", "%"),
    "initial_soil_water_mm": ("模拟初始土壤水总量", "mm"),
    "irrigation_assumption": ("原生摘要的灌溉证据分类", "category"),
    "irrigation_method": ("原生灌溉方式编码", "model-native code"),
    "last_simulated_date": ("引擎最后模拟日", "ISO date"),
    "leap_day_harvest_rule_adjusted": ("是否进行了闰日收获规则修正", "boolean"),
    "max_simulated_root_depth_m": ("模拟达到的最大根深", "m"),
    "model_version": ("原生摘要中的版本", "text"),
    "native_maturity_reached": ("原生终态是否达到成熟条件", "boolean"),
    "native_maturity_rejection_reason": ("原生成熟结果被拒绝的原因", "text"),
    "native_yield_form_date": ("原生籽粒形成事件日期", "ISO date"),
    "nitrogen_stress_modeled": ("模型是否模拟氮胁迫，AquaCrop 当前为假", "boolean"),
    "parameter_set_id": ("原生参数集身份", "identifier"),
    "parameterization": ("原生参数化方法", "text"),
    "phenology_parameterization": ("物候耦合参数化方法", "text"),
    "plant_population_ha": ("引擎种植密度输入", "plants/ha"),
    "population_evidence_source": ("密度输入证据来源", "text"),
    "population_verified": ("密度是否来自验证证据", "boolean"),
    "preplant_days_simulated": ("播前模拟日数", "day"),
    "preplant_soil_water_range_mm": ("播前模拟土壤水变化幅度", "mm"),
    "requested_sowing_date": ("请求播种日期", "ISO date"),
    "root_depth_clipped_by_profile": ("根深是否因剖面深度被裁剪", "boolean"),
    "seasonal_et_mm": ("季节累计蒸散量；统计窗口为模型定义", "mm"),
    "seasonal_evaporation_mm": ("季节累计蒸发量；统计窗口为模型定义", "mm"),
    "seasonal_irrigation_mm": ("季节累计灌溉量；不是实测灌溉记录", "mm"),
    "seasonal_precipitation_mm": ("模型统计窗口内的输入降水累计", "mm"),
    "seasonal_transpiration_mm": ("季节累计蒸腾量；统计窗口为模型定义", "mm"),
    "simulation_end_date": ("原生摘要的请求终点", "ISO date"),
    "simulation_start_date": ("原生摘要的请求起点", "ISO date"),
    "soil_compartment_m": ("模型土壤计算分室深度结构", "m (array)"),
    "soil_profile_depth_m": ("输入土壤剖面深度", "m"),
    "soil_type": ("AquaCrop 参考土壤类型", "category"),
    "soil_water_bounds_ok": ("土壤含水量边界检查是否通过", "boolean"),
    "termination_date": ("模型作物/模拟终止日期", "ISO date"),
    "termination_reason": ("模型终止原因", "category"),
    "water_balance_max_abs_mm_day": ("日水量平衡残差最大绝对值", "mm/day"),
    "water_balance_total_residual_mm": ("总水量平衡残差", "mm"),
    "yield_at_15p5_mg_ha": ("按 15.5% 含水率折算的模型产量，非干重", "Mg/ha"),
    "crop_status_code": (
        "DSSAT 作物结局原生代码，解释以该引擎定义为准",
        "model-native code",
    ),
    "fertilizer_nitrogen_kg_ha": ("模型施氮输入总量，含参考假设", "kg N/ha"),
    "flowering_event": ("DSSAT ADAT=75% 吐丝的事件说明", "text"),
    "input_mode": ("DSSAT 输入模式", "category"),
    "irrigation_mm": ("DSSAT 模拟灌溉累计", "mm"),
    "population_assumption": ("密度参考假设的说明", "text"),
    "population_plants_m2": ("种植密度输入", "plants/m²"),
    "reference_cultivar_id": (
        "模型参考品种先验标识，非当前 G2F 杂交种测量",
        "identifier",
    ),
    "reference_soil_id": ("参考土壤档案标识", "identifier"),
    "soil_id": ("DSSAT 土壤档案标识", "identifier"),
}

CANOPY = {
    "CanopyDevEnd": "冠层发育结束",
    "CanopyDevEndCD": "冠层发育结束",
    "FloweringCD": "开花代理阶段持续时间",
    "HIstartCD": "收获指数启动",
    "MaturityCD": "成熟",
    "MaxCanopy": "最大冠层",
    "MaxCanopyCD": "最大冠层",
    "MaxRootingCD": "最大根系",
    "SenescenceCD": "衰老",
    "YldFormCD": "籽粒形成阶段持续时间",
}

TERMINAL = {
    "crop_dead": ("原生终态作物死亡", "boolean"),
    "crop_mature": ("原生终态作物成熟", "boolean"),
    "delayed_cds": ("原生萌发/发育延迟日数", "day"),
    "delayed_gdds": ("原生萌发/发育延迟积温", "degC day"),
    "development_gdd": ("终态用于发育判断的积温", "degC day"),
    "germination": ("原生终态萌发标识", "boolean"),
    "raw_gdd_cum": ("终态原始累计积温", "degC day"),
    "yield_form": ("原生终态籽粒形成标识", "boolean"),
}

ASSUMPTIONS = {
    "fertilizer_material_placement": ("肥料材料和施用位置假设", "text"),
    "fertilizer_schedule": ("施肥日程假设", "text"),
    "initial_n_distribution": ("初始氮分层分布假设", "text"),
    "irrigation_assumption": ("灌溉证据假设", "category"),
    "row_spacing_assumed": ("行距是否为假设输入", "boolean"),
    "row_spacing_m": ("行距输入", "m"),
    "soil_root_distribution": ("土壤根系分布假设", "text"),
    "soil_surface.SALB": ("DSSAT 土壤反照率先验", "dimensionless"),
    "soil_surface.SLDR": ("DSSAT 土壤排水速率因子先验", "model-native"),
    "soil_surface.SLNF": ("DSSAT 土壤氮矿化因子先验", "dimensionless"),
    "soil_surface.SLPF": ("DSSAT 土壤肥力因子先验", "dimensionless"),
    "soil_surface.SLRO": ("DSSAT 土壤径流曲线数先验", "dimensionless"),
    "soil_surface.SLU1": ("DSSAT 第一阶段土壤蒸发上限先验", "mm"),
    "sowing_depth_assumed": ("播深是否为假设输入", "boolean"),
    "sowing_depth_m": ("播深输入", "m"),
}

PRIOR = {
    "ecotype": ("DSSAT 参考品种的生态型", "identifier"),
    "id": ("DSSAT 参考品种身份", "identifier"),
    "name": ("DSSAT 参考品种名称", "text"),
    "role": ("参考品种在先验中的角色", "text"),
    "source": ("参考品种来源文件", "path"),
    "source_row": ("参考品种来源行文本", "text"),
    "source_sha256": ("参考品种来源摘要", "SHA-256"),
}


def describe(field: str, parameter_units: dict[str, str]) -> tuple[str, str]:
    """Fail rather than silently ship an undocumented schema addition."""
    if field in BASE:
        return BASE[field]
    prefix = "native_summary_"
    if not field.startswith(prefix):
        raise ValueError(f"Undocumented field: {field}")
    key = field[len(prefix) :]
    if key in NATIVE:
        return NATIVE[key]
    if key in PARAMETERS:
        return PARAMETERS[key] + "，估计/参考值而非实测常数", parameter_units[key]
    if key.startswith("derived_canopy_calendar."):
        name = key.split(".", 1)[1]
        unit = "day after planting / duration" if name.endswith("CD") else "degC day"
        return "AquaCrop 耦合参数化派生的" + CANOPY[name] + "时序", unit
    for stem, mapping in [
        ("native_terminal_state.", TERMINAL),
        ("input_assumptions.", ASSUMPTIONS),
        ("native_cultivar_prior.", PRIOR),
    ]:
        if key.startswith(stem):
            return mapping[key[len(stem) :]]
    raise ValueError(f"Undocumented native field: {field}")
