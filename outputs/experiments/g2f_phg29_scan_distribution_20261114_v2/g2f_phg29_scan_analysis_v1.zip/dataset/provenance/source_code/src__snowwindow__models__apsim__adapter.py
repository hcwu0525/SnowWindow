"""Native APSIM Next Generation adapter for the minimal G2F workflow."""

from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import subprocess
from collections.abc import Iterable, Mapping
from dataclasses import replace
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path
from typing import Any

import pandas as pd

from snowwindow.domain import (
    CalibrationParameter,
    FoldStrategy,
    ModelCapabilities,
    RunStatus,
    ScanRequestStrategy,
    SimulationRequest,
    SimulationResult,
    WeatherStrategy,
)

ADAPTER_NAME = "apsim"
MODEL_VERSION = "2026.9.8116.0"
PHENOLOGY_SCHEMA_VERSION = 3
DAILY_DIAGNOSTICS_SCHEMA_VERSION = 1
RESULT_SCHEMA_VERSION = 3
STAGE_RESET_SCHEMA_VERSION = 1
STAGE_RESET_COLUMNS = (
    "SimulationName", "ResetDate", "ResetStageName", "ResetPhaseName",
)
DAILY_DIAGNOSTICS_COLUMNS = (
    "SimulationName",
    "DiagnosticDate",
    "Water0To200mm",
    "FieldCapacity0To200mm",
    "Water0To400mm",
    "FieldCapacity0To400mm",
)
HARVEST_REPORT_COLUMNS = (
    "SimulationName",
    "Clock.Today",
    "Maize.Phenology.CurrentStageName",
    "FloweringDAS",
    "MaturityDAS",
    "YieldKgHa",
    "BiomassKgHa",
)
PHENOLOGY_REPORT_COLUMNS = {
    "SimulationName": "simulation_name",
    "PhaseDate": "phase_date",
    "StageName": "stage_name",
    "PhaseName": "phase_name",
    "StageNumber": "stage_number",
}
APSIM_PHASE_STAGES = (
    "Germination",
    "Emergence",
    "EndJuvenile",
    "FloralInitiation",
    "FlagLeaf",
    "Flowering",
    "StartGrainFill",
    "EndGrainFill",
    "Maturity",
    "HarvestRipe",
)
REQUIRED_WEATHER = (
    "T2M_MIN",
    "T2M_MAX",
    "PRECTOTCORR",
    "ALLSKY_SFC_SW_DWN",
)
CULTIVAR_PATHS = {
    "juvenile_tt": "[Phenology].Juvenile.Target.FixedValue",
    "flag_leaf_tt": "[Phenology].FlagLeafToFlowering.Target.FixedValue",
    "flowering_to_grain_fill_tt": (
        "[Phenology].FloweringToGrainFilling.Target.FixedValue"
    ),
    "grain_fill_tt": "[Phenology].GrainFilling.Target.FixedValue",
    "potential_grain_number": (
        "[Grain].MaximumGrainsPerCob.PotentialMaximumGrainsPerCob.FixedValue"
    ),
    "maximum_grain_size_g": "[Grain].MaximumPotentialGrainSize.FixedValue",
}
CULTIVAR_DEFAULTS = {
    "juvenile_tt": 211.0,
    # Native Y endpoint at 24 h, not a per-hour slope; zero through 12.5 h.
    "photoperiod_sensitivity": 472.0,
    "flag_leaf_tt": 101.0,
    "flowering_to_grain_fill_tt": 170.0,
    "grain_fill_tt": 813.0,
    "potential_grain_number": 550.0,
    "maximum_grain_size_g": 0.3,
}


class APSIMValidationError(ValueError):
    """A request cannot be represented by the supported APSIM workflow."""


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _find_model(node: dict[str, Any], name: str) -> dict[str, Any]:
    if node.get("Name") == name:
        return node
    for child in node.get("Children", []):
        try:
            return _find_model(child, name)
        except KeyError:
            continue
    raise KeyError(name)


@lru_cache(maxsize=2)
def _expanded_maize(template_path: str) -> dict[str, Any]:
    """Extract the embedded maize resource distributed with Models.dll."""

    models_dll = Path(template_path).resolve().parent.parent / "bin/Models.dll"
    payload = models_dll.read_bytes()
    marker = b'"PlantType": "Maize"'
    marker_offset = payload.find(marker)
    start = payload.rfind(
        b'{\n  "$type": "Models.Core.Simulations, Models"',
        0,
        marker_offset,
    )
    if marker_offset < 0 or start < 0:
        raise APSIMValidationError("cannot locate embedded APSIM maize resource")
    resource, _ = json.JSONDecoder().raw_decode(
        payload[start:].decode("utf-8", errors="replace")
    )
    return copy.deepcopy(_find_model(resource, "Maize"))


def _replace_named_model(
    node: dict[str, Any], name: str, replacement: dict[str, Any]
) -> bool:
    children = node.get("Children", [])
    for index, child in enumerate(children):
        if child.get("Name") == name:
            children[index] = replacement
            return True
        if _replace_named_model(child, name, replacement):
            return True
    return False


def _replace_command(
    commands: list[str], path: str, value: float | str
) -> None:
    prefix = f"{path} ="
    rendered = value if isinstance(value, str) else f"{value:.16g}"
    replacement = f"{path} = {rendered}"
    for index, command in enumerate(commands):
        if command.strip().startswith(prefix):
            commands[index] = replacement
            return
    commands.append(replacement)


def _cultivar_mode(request: SimulationRequest) -> bool:
    return bool(request.environment.metadata.get("cultivar_calibration", False))


def _cultivar_parameters(request: SimulationRequest) -> dict[str, float]:
    parameters = {}
    for key, default in CULTIVAR_DEFAULTS.items():
        value = request.model_parameters.get(key, default)
        if key == "potential_grain_number" and key not in request.model_parameters:
            value = default * float(
                request.model_parameters.get("grain_number_scale", 1)
            )
        number = (
            _nonnegative_number(value) if key == "photoperiod_sensitivity"
            else _positive_number(value)
        )
        if number is None:
            raise APSIMValidationError(f"{key} must be finite and physically positive")
        parameters[key] = number
    return parameters


def _cultivar_name(request: SimulationRequest) -> str:
    identity = json.dumps(_cultivar_parameters(request), sort_keys=True)
    return "SnowWindow_" + hashlib.sha256(identity.encode()).hexdigest()[:16]


def _management_events(
    request: SimulationRequest, key: str, amount_key: str,
) -> list[tuple[date, float]]:
    events = []
    try:
        for event in request.management.metadata.get(key, ()):
            day = date.fromisoformat(str(event["date"]))
            amount = _nonnegative_number(event[amount_key])
            if amount is None or not request.start_date <= day <= request.end_date:
                raise ValueError("invalid amount or date outside simulation interval")
            events.append((day, amount))
    except (KeyError, TypeError, ValueError) as exc:
        raise APSIMValidationError(f"invalid {key}: {exc}") from exc
    return sorted(events)


def _cultivar_sowing_code(request: SimulationRequest) -> list[str]:
    metadata = request.management.metadata
    population = request.management.population_plants_m2
    depth = float(metadata.get("sowing_depth_m", 0.03)) * 1000
    spacing = float(metadata.get("row_spacing_m", 0.75)) * 1000
    fertilizer = _management_events(request, "fertilizer_events", "nitrogen_kg_ha")
    irrigation = _management_events(request, "irrigation_events", "amount_mm")
    sowing = request.management.planting_date
    lines = [
        "using Models.Core;", "using Models.PMF;", "using System;",
        "namespace Models {",
        " [Serializable] public class Script : Model {",
        "  [Link] private Clock Clock;",
        "  [Link] private IPlant Maize;",
    ]
    if fertilizer:
        lines.append("  [Link] private Fertiliser Fertiliser;")
    if irrigation:
        lines.append("  [Link] private Irrigation Irrigation;")
    lines.extend([
        '  [EventSubscribe("DoManagement")]',
        "  private void OnDoManagement(object sender, EventArgs e) {",
        f"   if (Clock.Today == new DateTime({sowing.year}, {sowing.month}, "
        f"{sowing.day}) && !Maize.IsAlive)",
        f'    Maize.Sow(population: {float(population)!r}, '
        f'cultivar: "{_cultivar_name(request)}", '
        f"depth: {depth:.16g}, rowSpacing: {spacing:.16g});",
    ])
    for events, expression in (
        (fertilizer, 'Fertiliser.Apply(amount: {amount:.16g}, type: "NO3N");'),
        (irrigation, "Irrigation.Apply(amount: {amount:.16g}, efficiency: 1.0);"),
    ):
        for day, amount in events:
            lines.extend([
                f"   if (Clock.Today == new DateTime({day.year}, {day.month}, "
                f"{day.day}))",
                "    " + expression.format(amount=amount),
            ])
    return [*lines, "  }", " }", "}"]


def _cultivar_input_values(request: SimulationRequest) -> dict[str, Any]:
    """Validate the shared hydraulic/management contract, without hidden defaults."""

    layers = request.environment.soil
    if not layers:
        raise APSIMValidationError("cultivar mode requires sourced soil layers")
    previous_bottom = 0.0
    for layer in layers:
        top, bottom = layer.top_depth_m, layer.bottom_depth_m
        if (
            not math.isfinite(top) or not math.isfinite(bottom)
            or not math.isclose(top, previous_bottom, abs_tol=1e-8)
            or bottom <= top
        ):
            raise APSIMValidationError("soil layers must be contiguous from zero")
        previous_bottom = bottom
        values = {
            key: _nonnegative_number(layer.properties.get(key))
            for key in (
                "theta_wp", "theta_fc", "theta_sat", "ksat_mm_day",
                "bulk_density_g_cm3", "sand_pct", "clay_pct", "organic_carbon_pct",
            )
        }
        if any(value is None for value in values.values()):
            raise APSIMValidationError(
                "soil requires finite hydraulic/BD/organic values"
            )
        if not (
            0 <= values["theta_wp"] < values["theta_fc"] < values["theta_sat"] <= 1
            and values["bulk_density_g_cm3"] > 0
            and values["sand_pct"] + values["clay_pct"] <= 100
            and values["organic_carbon_pct"] <= 100
        ):
            raise APSIMValidationError(
                "soil hydraulic or composition values are invalid"
            )
    initial = request.environment.metadata.get("initial_conditions", {})
    values = {
        key: _nonnegative_number(initial.get(key))
        for key in ("available_water_fraction", "no3_kg_ha", "nh4_kg_ha")
    }
    if any(value is None for value in values.values()):
        raise APSIMValidationError("initial_conditions requires finite water/no3/nh4")
    if values["available_water_fraction"] > 1:
        raise APSIMValidationError("available_water_fraction must be in [0, 1]")
    if _positive_number(request.management.population_plants_m2) is None:
        raise APSIMValidationError("cultivar mode requires positive sowing population")
    for key, default in (("sowing_depth_m", 0.03), ("row_spacing_m", 0.75)):
        if _positive_number(request.management.metadata.get(key, default)) is None:
            raise APSIMValidationError(f"{key} must be positive and finite")
    sowing_depth = float(request.management.metadata.get("sowing_depth_m", 0.03))
    if sowing_depth >= previous_bottom:
        raise APSIMValidationError("sowing_depth_m must be inside the soil profile")
    if not request.start_date <= request.management.planting_date <= request.end_date:
        raise APSIMValidationError("planting_date must be inside simulation interval")
    _management_events(request, "fertilizer_events", "nitrogen_kg_ha")
    irrigation = _management_events(request, "irrigation_events", "amount_mm")
    assumption = request.management.irrigation_assumption
    if assumption in ("unknown", ""):
        raise APSIMValidationError(
            "unknown irrigation must be explicitly assumed rainfed"
        )
    if "rainfed" in assumption and any(amount > 0 for _, amount in irrigation):
        raise APSIMValidationError(
            "rainfed assumption conflicts with irrigation_events"
        )
    if ("irrigat" in assumption or assumption == "scheduled") and not irrigation:
        raise APSIMValidationError("known irrigation requires irrigation_events")
    return values


def _remap_layer_values(
    values: list[float], old_thickness: list[float], thickness: list[float],
) -> list[float]:
    """Depth-average template ancillary values; extend the last layer if needed."""

    result = []
    top = 0.0
    for width in thickness:
        bottom, old_top, total = top + width, 0.0, 0.0
        for value, old_width in zip(values, old_thickness):
            old_bottom = old_top + old_width
            total += max(0, min(bottom, old_bottom) - max(top, old_top)) * value
            old_top = old_bottom
        total += max(0, bottom - max(top, old_top)) * values[-1]
        result.append(total / width)
        top = bottom
    return result


def _apply_cultivar_soil(
    simulation: dict[str, Any], request: SimulationRequest,
) -> None:
    initial = _cultivar_input_values(request)
    layers = request.environment.soil
    thickness = [
        (layer.bottom_depth_m - layer.top_depth_m) * 1000 for layer in layers
    ]
    soil = _find_model(simulation, "Soil")
    physical = _find_model(soil, "Physical")
    old_physical_thickness = physical["Thickness"]
    # Ancillary properties absent from the shared contract remain explicit
    # template assumptions, regridded by depth rather than copied by index.
    for model in soil["Children"]:
        old_thickness = model.get("Thickness")
        if not old_thickness:
            continue
        for key, value in list(model.items()):
            if (
                key != "Thickness" and isinstance(value, list)
                and len(value) == len(old_thickness)
                and all(isinstance(item, (int, float)) for item in value)
            ):
                model[key] = _remap_layer_values(value, old_thickness, thickness)
        model["Thickness"] = thickness[:]
    for native, key in (
        ("LL15", "theta_wp"), ("DUL", "theta_fc"), ("SAT", "theta_sat"),
        ("KS", "ksat_mm_day"), ("BD", "bulk_density_g_cm3"),
        ("ParticleSizeSand", "sand_pct"), ("ParticleSizeClay", "clay_pct"),
    ):
        physical[native] = [float(layer.properties[key]) for layer in layers]
    physical["ParticleSizeSilt"] = [
        100 - sand - clay for sand, clay in zip(
            physical["ParticleSizeSand"], physical["ParticleSizeClay"],
        )
    ]
    physical["AirDry"] = [wp * 0.5 for wp in physical["LL15"]]
    for crop in physical["Children"]:
        if crop.get("$type", "").startswith("Models.Soils.SoilCrop,"):
            crop["LL"] = physical["LL15"][:]
            for key in ("KL", "XF"):
                crop[key] = _remap_layer_values(
                    crop[key], old_physical_thickness, thickness,
                )
    organic = _find_model(soil, "Organic")
    organic["Carbon"] = [
        float(layer.properties["organic_carbon_pct"]) for layer in layers
    ]
    organic["CarbonUnits"] = 0  # Total organic carbon, percent.
    organic["FOM"] = [0.0] * len(layers)  # No evidenced fresh-organic input.
    # The example's wheat stubble is an unrequested C/N input too.
    _find_model(simulation, "SurfaceOrganicMatter")["InitialResidueMass"] = 0.0
    water = _find_model(soil, "Water")
    fraction = initial["available_water_fraction"]
    water["InitialValues"] = [
        wp + fraction * (fc - wp)
        for wp, fc in zip(physical["LL15"], physical["DUL"])
    ]
    water["InitialPAWmm"] = sum(
        fraction * (fc - wp) * width for wp, fc, width in zip(
            physical["LL15"], physical["DUL"], thickness,
        )
    )
    water["RelativeTo"] = "LL15"
    water["FilledFromTop"] = False
    for name, total in (
        ("NO3", initial["no3_kg_ha"]), ("NH4", initial["nh4_kg_ha"]), ("Urea", 0),
    ):
        solute = _find_model(soil, name)
        solute["InitialValuesUnits"] = 1  # Installed UnitsEnum.kgha, not ppm.
        solute["InitialValues"] = [
            total * width / sum(thickness) for width in thickness
        ]
    soil.update(
        Latitude=request.environment.latitude,
        Longitude=request.environment.longitude,
        DataSource="; ".join(layer.source for layer in layers),
        Comments="SnowWindow shared cultivar soil; ancillary template assumptions",
        Site=request.environment.location, LocalName=request.environment.location,
        ApsoilNumber=None, Country=None, State=None, Region=None, NearestTown=None,
        SoilType=None, ASCOrder=None, ASCSubOrder=None,
    )


def render_met(request: SimulationRequest) -> str:
    """Render G2F daily weather in APSIM met format."""

    rows = []
    mean_temperatures = []
    for record in sorted(request.environment.weather, key=lambda item: item.date):
        values = record.values
        mint = float(values["T2M_MIN"])
        maxt = float(values["T2M_MAX"])
        mean_temperatures.append((mint + maxt) / 2)
        rows.append(
            f"{record.date.year} {record.date.timetuple().tm_yday} "
            f"{float(values['ALLSKY_SFC_SW_DWN']):.3f} {maxt:.3f} "
            f"{mint:.3f} {float(values['PRECTOTCORR']):.3f}"
        )
    tav = sum(mean_temperatures) / len(mean_temperatures)
    amp = max(mean_temperatures) - min(mean_temperatures)
    return "\n".join(
        [
            "[weather.met.weather]",
            f"latitude = {request.environment.latitude:g}",
            f"longitude = {request.environment.longitude:g}",
            f"tav = {tav:.3f}",
            f"amp = {amp:.3f}",
            "year day radn maxt mint rain",
            "() () (MJ/m^2/day) (oC) (oC) (mm)",
            *rows,
            "",
        ]
    )


def render_met_batch(requests: Iterable[SimulationRequest]) -> str:
    """Render one weather file from compatible request-specific subsets."""

    ordered = tuple(requests)
    if not ordered:
        raise APSIMValidationError("cannot render an empty APSIM weather batch")
    records_by_date = {}
    for request in ordered:
        for record in request.environment.weather:
            existing = records_by_date.get(record.date)
            if existing is not None and any(
                float(existing.values[name]) != float(record.values[name])
                for name in REQUIRED_WEATHER
            ):
                raise APSIMValidationError(
                    f"conflicting weather values for {record.date}"
                )
            records_by_date[record.date] = record
    environment = replace(
        ordered[0].environment,
        weather=tuple(records_by_date[key] for key in sorted(records_by_date)),
    )
    return render_met(replace(ordered[0], environment=environment))


def _sowing_code(request: SimulationRequest) -> list[str]:
    if _cultivar_mode(request):
        return _cultivar_sowing_code(request)
    sowing = request.management.planting_date
    population = request.management.population_plants_m2 or 7.5
    return [
        "using Models.Core;",
        "using Models.PMF;",
        "using System;",
        "namespace Models {",
        " [Serializable] public class Script : Model {",
        "  [Link] private Clock Clock;",
        "  [Link] private IPlant Maize;",
        '  [EventSubscribe("DoManagement")]',
        "  private void OnDoManagement(object sender, EventArgs e) {",
        f"   if (Clock.Today == new DateTime({sowing.year}, {sowing.month}, "
        f"{sowing.day}) && !Maize.IsAlive)",
        f'    Maize.Sow(population: {population:g}, cultivar: "Dekalb_XL82", '
        "depth: 30.0, rowSpacing: 750.0);",
        "  }",
        " }",
        "}",
    ]


def _depth_integral_expression(
    model: dict[str, Any], variable: str, depth_mm: float
) -> str:
    """Integrate layer amounts, including the fraction intersecting the boundary."""

    remaining = depth_mm
    terms = []
    for index, thickness in enumerate(model["Thickness"], start=1):
        thickness = float(thickness)
        if not math.isfinite(thickness) or thickness <= 0:
            raise APSIMValidationError(
                "soil layer thickness must be positive and finite"
            )
        fraction = min(remaining, thickness) / thickness
        term = f"[{model['Name']}].{variable}[{index}]"
        terms.append(term if fraction == 1 else f"{term}*{fraction:.16g}")
        remaining -= min(remaining, thickness)
        if remaining <= 0:
            return " + ".join(terms)
    raise APSIMValidationError(f"soil profile does not cover {depth_mm:g} mm")


def build_apsim_document(
    template_path: Path,
    requests: Iterable[SimulationRequest],
    *,
    weather_filename: str | Mapping[str, str],
) -> tuple[dict[str, Any], dict[str, str]]:
    """Clone the official maize simulation once per request."""

    template = json.loads(Path(template_path).read_text(encoding="utf-8"))
    source_simulation = next(
        child
        for child in template["Children"]
        if child.get("$type", "").startswith("Models.Core.Simulation,")
    )
    datastore = next(
        child
        for child in template["Children"]
        if child.get("$type", "").startswith("Models.Storage.DataStore,")
    )
    ordered_requests = tuple(requests)
    if not ordered_requests:
        raise APSIMValidationError("APSIM document requires at least one request")
    request_ids = {request.request_id for request in ordered_requests}
    if len(request_ids) != len(ordered_requests):
        raise APSIMValidationError("APSIM batch requires unique request_id values")
    modes = {_cultivar_mode(request) for request in ordered_requests}
    if len(modes) != 1:
        raise APSIMValidationError("cannot mix legacy and cultivar mode in one batch")
    cultivar_mode = modes.pop()
    parameter_pairs = {
        (
            float(request.model_parameters.get("juvenile_tt", 211.0)),
            float(request.model_parameters.get("grain_number_scale", 1.0)),
        )
        for request in ordered_requests
    }
    if not cultivar_mode and len(parameter_pairs) != 1:
        raise APSIMValidationError("one APSIM batch must share cultivar parameters")
    maize_replacement = copy.deepcopy(_expanded_maize(str(template_path)))
    cultivar_folder = _find_model(maize_replacement, "CultivarFolder")
    cultivar = next(
        child
        for child in cultivar_folder["Children"]
        if child.get("Name") == "Dekalb_XL82"
    )
    if cultivar_mode:
        cultivars = {}
        for request in ordered_requests:
            values = _cultivar_parameters(request)
            native = copy.deepcopy(cultivar)
            native["Name"] = _cultivar_name(request)
            for key, path in CULTIVAR_PATHS.items():
                _replace_command(native["Command"], path, values[key])
            _replace_command(
                native["Command"], "[Phenology].Photosensitive.Target.XYPairs.X",
                "0, 12.5, 24",
            )
            _replace_command(
                native["Command"], "[Phenology].Photosensitive.Target.XYPairs.Y",
                f"0, 0, {values['photoperiod_sensitivity']:.16g}",
            )
            cultivars[native["Name"]] = native
        cultivar_folder["Children"].extend(cultivars.values())
    else:
        juvenile_tt, grain_scale = next(iter(parameter_pairs))
        _replace_command(
            cultivar["Command"],
            "[Phenology].Juvenile.Target.FixedValue",
            juvenile_tt,
        )
        _replace_command(
            cultivar["Command"],
            "[Grain].MaximumGrainsPerCob.PotentialMaximumGrainsPerCob.FixedValue",
            550.0 * grain_scale,
        )
    replacements = {
        "$type": "Models.Core.Folder, Models",
        "Name": "Replacements",
        "ResourceName": None,
        "Children": [maize_replacement],
        "Enabled": True,
        "ReadOnly": False,
    }
    simulations = []
    simulation_names: dict[str, str] = {}
    for index, request in enumerate(ordered_requests):
        simulation = copy.deepcopy(source_simulation)
        simulation_name = f"sim_{index:04d}"
        simulation["Name"] = simulation_name
        simulation_names[simulation_name] = request.request_id

        clock = _find_model(simulation, "Clock")
        clock["Start"] = f"{request.start_date.isoformat()}T00:00:00"
        clock["End"] = f"{request.end_date.isoformat()}T00:00:00"
        _find_model(simulation, "Weather")["FileName"] = (
            weather_filename[request.environment.environment_id]
            if isinstance(weather_filename, Mapping) else weather_filename
        )

        if cultivar_mode:
            _apply_cultivar_soil(simulation, request)
            field = _find_model(simulation, "Field")
            field["Children"] = [
                child for child in field["Children"]
                if child.get("$type") != "Models.Manager, Models"
                or child.get("Name") in ("Sow using a variable rule", "Harvest")
            ]
            if not any(
                child.get("Name") == "Irrigation" for child in field["Children"]
            ):
                field["Children"].append({
                    "$type": "Models.Irrigation, Models", "Name": "Irrigation",
                    "Children": [], "Enabled": True, "ReadOnly": False,
                })
        manager = _find_model(simulation, "Sow using a variable rule")
        manager["CodeArray"] = _sowing_code(request)
        if cultivar_mode:
            manager["Parameters"] = []

        report = _find_model(simulation, "Report")
        report["VariableNames"] = [
            "[Clock].Today",
            "[Maize].Phenology.CurrentStageName",
            "[Maize].Phenology.FloweringDAS as FloweringDAS",
            "[Maize].Phenology.MaturityDAS as MaturityDAS",
            "[Maize].Grain.Total.Wt*10 as YieldKgHa",
            "[Maize].AboveGround.Wt*10 as BiomassKgHa",
        ]
        report["EventNames"] = ["[Maize].Harvesting"]
        phenology_report = copy.deepcopy(report)
        phenology_report["Name"] = "PhenologyReport"
        phenology_report["VariableNames"] = [
            "[Clock].Today as PhaseDate",
            "[Maize].Phenology.CurrentStageName as StageName",
            "[Maize].Phenology.CurrentPhaseName as PhaseName",
            "[Maize].Phenology.Stage as StageNumber",
        ]
        phenology_report["EventNames"] = ["[Maize].Phenology.PhaseChanged"]
        reset_report = copy.deepcopy(report)
        reset_report["Name"] = "StageWasResetReport"
        reset_report["EventNames"] = ["[Maize].Phenology.StageWasReset"]
        reset_report["VariableNames"] = [
            "[Clock].Today as ResetDate",
            "[Maize].Phenology.CurrentPhase.Start as ResetStageName",
            "[Maize].Phenology.CurrentPhaseName as ResetPhaseName",
        ]
        field = _find_model(simulation, "Field")
        field["Children"] = [
            child
            for child in field["Children"]
            if child.get("Name") not in (
                "PhenologyReport", "DailyDiagnostics", "StageWasResetReport",
            )
        ] + [phenology_report, reset_report]
        if request.model_parameters.get("save_daily_diagnostics", False):
            daily_report = copy.deepcopy(report)
            daily_report["Name"] = "DailyDiagnostics"
            daily_report["EventNames"] = ["[Clock].DoReport"]
            # CurrentStageName is only populated on transition days. Phase.Start
            # represents the occupied stage on ordinary days (blank when not alive).
            daily_report["VariableNames"] = [
                "[Clock].Today as DiagnosticDate",
                "[Maize].Phenology.CurrentPhase.Start as DailyStageName",
            ]
            for depth in (200, 400):
                for model_name, variable, alias in (
                    ("SoilWater", "SWmm", "Water"),
                    ("Physical", "DULmm", "FieldCapacity"),
                ):
                    expression = _depth_integral_expression(
                        _find_model(simulation, model_name), variable, depth
                    )
                    daily_report["VariableNames"].append(
                        f"{expression} as {alias}0To{depth}mm"
                    )
            field["Children"].append(daily_report)
        simulations.append(simulation)

    document = copy.deepcopy(template)
    document["Children"] = [replacements, *simulations, copy.deepcopy(datastore)]
    return document, simulation_names


def _positive_number(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and number > 0 else None


def _nonnegative_number(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and number >= 0 else None


def apsim_batch_complete(
    run_dir: Path, save_daily_diagnostics: bool = False
) -> bool:
    """Require the requested reports; an older diagnostics schema is not reusable."""

    if (run_dir / "execution_failed.json").exists():
        return False
    reports = {
        "Report": HARVEST_REPORT_COLUMNS,
        "PhenologyReport": PHENOLOGY_REPORT_COLUMNS,
    }
    if save_daily_diagnostics:
        reports["DailyDiagnostics"] = DAILY_DIAGNOSTICS_COLUMNS
    # An untriggered native event has no exported CSV. Validate it if present.
    if (run_dir / "batch.StageWasResetReport.csv").is_file():
        reports["StageWasResetReport"] = STAGE_RESET_COLUMNS
    for name, required_columns in reports.items():
        try:
            columns = pd.read_csv(run_dir / f"batch.{name}.csv", nrows=0).columns
        except (OSError, pd.errors.ParserError, pd.errors.EmptyDataError):
            return False
        if not set(required_columns).issubset(columns):
            return False
    return True


def _explicit_forced_flags(report: pd.DataFrame) -> pd.Series:
    """Preserve true/false evidence; absent observations are nullable, not false."""

    flags = pd.Series(pd.NA, index=report.index, dtype="boolean")
    for column in ("forced_transition", "ForcedTransition", "StageWasReset"):
        if column not in report:
            continue
        for index, value in report[column].items():
            if pd.isna(value):
                continue
            text = str(value).strip().lower()
            if text in ("", "not_observed", "unknown"):
                continue
            if text not in ("true", "false", "1", "0", "1.0", "0.0"):
                raise APSIMValidationError(f"invalid explicit forced flag: {value}")
            forced = text in ("true", "1", "1.0")
            if forced or pd.isna(flags.at[index]):
                flags.at[index] = forced
    return flags


def _stage_reset_dates(
    stage_resets: pd.DataFrame | None, simulation_name: str,
) -> set[str]:
    if stage_resets is None:
        return set()
    missing = set(STAGE_RESET_COLUMNS) - set(stage_resets.columns)
    if missing:
        raise APSIMValidationError(
            "stage reset report is missing columns: " + ", ".join(sorted(missing))
        )
    dates = pd.to_datetime(
        stage_resets.loc[stage_resets["SimulationName"].eq(simulation_name),
                         "ResetDate"],
        format="ISO8601", errors="coerce",
    )
    if dates.isna().any():
        raise APSIMValidationError("stage reset report has invalid dates")
    return set(dates.dt.strftime("%Y-%m-%d"))


def parse_phenology_report(
    report: pd.DataFrame,
    requests_by_simulation: dict[str, SimulationRequest],
    *,
    stage_resets: pd.DataFrame | None = None,
) -> dict[str, pd.DataFrame]:
    """Normalize APSIM phase-change rows without collapsing same-day events."""

    columns = PHENOLOGY_REPORT_COLUMNS
    missing = [column for column in columns if column not in report.columns]
    if missing:
        raise APSIMValidationError(
            "phenology report is missing columns: " + ", ".join(missing)
        )
    normalized = report.rename(columns=columns).copy()
    normalized["forced_transition"] = _explicit_forced_flags(report)
    normalized["forced_transition_evidence"] = (
        normalized["forced_transition"].notna().map(
            {True: "explicit_flag", False: "not_observed"}
        )
    )
    normalized["phase_date"] = pd.to_datetime(
        normalized["phase_date"], format="ISO8601", errors="coerce"
    )
    normalized["stage_number"] = pd.to_numeric(
        normalized["stage_number"], errors="coerce"
    )
    if normalized[["phase_date", "stage_number"]].isna().any().any():
        raise APSIMValidationError(
            "phenology report has invalid dates or stage numbers"
        )

    stages: dict[str, pd.DataFrame] = {}
    for simulation_name, request in requests_by_simulation.items():
        reset_dates = _stage_reset_dates(stage_resets, simulation_name)
        group = normalized.loc[
            normalized["simulation_name"].eq(simulation_name)
        ].reset_index(drop=True)
        if group.empty:
            stages[request.request_id] = pd.DataFrame(
                columns=[
                    "request_id",
                    "simulation_name",
                    "phase_date",
                    "stage_name",
                    "phase_name",
                    "stage_number",
                    "dap",
                    "transition_order",
                    "stage_sequence_gap",
                    "forced_transition",
                    "forced_transition_evidence",
                ]
            )
            continue
        stage_order = {
            stage_name: index + 1
            for index, stage_name in enumerate(APSIM_PHASE_STAGES)
        }
        ordered_stages = group["stage_name"].map(stage_order).to_numpy(dtype=float)
        gaps = [False]
        gaps.extend(
            not (
                math.isfinite(current)
                and math.isfinite(previous)
                and current in (previous, previous + 1.0)
            )
            for previous, current in zip(ordered_stages[:-1], ordered_stages[1:])
        )
        group["request_id"] = request.request_id
        group["dap"] = (
            group["phase_date"].dt.date
            - request.management.planting_date
        ).map(lambda value: value.days)
        group["transition_order"] = range(len(group))
        group["stage_sequence_gap"] = gaps
        group["phase_date"] = group["phase_date"].dt.strftime("%Y-%m-%d")
        # Native reset fires after skipped PhaseChanged events. The report proves
        # a reset on this date, not which same-day transitions it caused. Flag
        # all same-day transitions conservatively, retaining unknown elsewhere.
        reset_day = group["phase_date"].isin(reset_dates)
        group.loc[reset_day, "forced_transition"] = True
        group.loc[reset_day, "forced_transition_evidence"] = "stage_was_reset_same_day"
        stages[request.request_id] = group[
            [
                "request_id",
                "simulation_name",
                "phase_date",
                "stage_name",
                "phase_name",
                "stage_number",
                "dap",
                "transition_order",
                "stage_sequence_gap",
                "forced_transition",
                "forced_transition_evidence",
            ]
        ]
    return stages


def _request_daily_diagnostics(
    report: pd.DataFrame, simulation_name: str, request: SimulationRequest
) -> pd.DataFrame:
    """Filter and validate a full-interval diagnostic table for one request."""

    group = report.loc[report["SimulationName"].eq(simulation_name)].copy()
    dates = pd.to_datetime(group["DiagnosticDate"], format="ISO8601", errors="coerce")
    expected_dates = pd.date_range(request.start_date, request.end_date).date.tolist()
    if dates.isna().any() or sorted(dates.dt.date.tolist()) != expected_dates:
        raise APSIMValidationError(
            "APSIM daily diagnostics report must cover every requested calendar day "
            f"exactly once for {simulation_name}"
        )
    for column in DAILY_DIAGNOSTICS_COLUMNS[2:]:
        values = pd.to_numeric(group[column], errors="coerce")
        if not values.map(
            lambda value: math.isfinite(value) and (
                value > 0 if column.startswith("FieldCapacity") else value >= 0
            )
        ).all():
            raise APSIMValidationError(
                f"APSIM daily diagnostics report has invalid {column} values "
                f"for {simulation_name}"
            )
    return group.loc[dates.sort_values().index].reset_index(drop=True)


def parse_report(
    report: pd.DataFrame,
    requests_by_simulation: dict[str, SimulationRequest],
    *,
    adapter_version: str,
    phenology: pd.DataFrame | None = None,
    stage_resets: pd.DataFrame | None = None,
) -> dict[str, SimulationResult]:
    """Combine harvest measurements and phase evidence without conflating dates."""

    missing = set(HARVEST_REPORT_COLUMNS) - set(report.columns)
    if missing:
        raise APSIMValidationError(
            "harvest report is missing columns: " + ", ".join(sorted(missing))
        )
    normalized_phenology = (
        parse_phenology_report(
            phenology, requests_by_simulation, stage_resets=stage_resets,
        )
        if phenology is not None
        else {}
    )
    results: dict[str, SimulationResult] = {}
    for simulation_name, request in requests_by_simulation.items():
        group = report.loc[report["SimulationName"].eq(simulation_name)].copy()
        group["Clock.Today"] = pd.to_datetime(
            group["Clock.Today"], format="ISO8601", errors="coerce"
        )
        if group["Clock.Today"].isna().any():
            raise APSIMValidationError("harvest report has invalid dates")
        group = group.sort_values("Clock.Today")
        flowering = next(
            (
                value
                for value in (_positive_number(item) for item in group["FloweringDAS"])
                if value is not None
            ),
            None,
        )
        maturity_das = next(
            (
                value
                for value in (
                    _positive_number(item)
                    for item in group.loc[
                        ~_explicit_forced_flags(group).fillna(False), "MaturityDAS",
                    ]
                )
                if value is not None
            ),
            None,
        )
        harvest_date = (
            pd.Timestamp(group["Clock.Today"].max()).date().isoformat()
            if not group.empty
            else None
        )
        stage_rows = normalized_phenology.get(request.request_id)
        reset_dates = _stage_reset_dates(stage_resets, simulation_name)
        maturity_stage = (
            stage_rows.loc[stage_rows["stage_name"].eq("Maturity")]
            if stage_rows is not None and not stage_rows.empty
            else pd.DataFrame()
        )
        forced_maturity = (
            maturity_stage["forced_transition"].fillna(False)
            if not maturity_stage.empty else pd.Series(dtype=bool)
        )
        forced_maturity_excluded = bool(forced_maturity.any())
        maturity_stage = maturity_stage.loc[~forced_maturity]
        counter_date = (
            (request.management.planting_date
             + timedelta(days=round(maturity_das))).isoformat()
            if maturity_das is not None else None
        )
        if counter_date in reset_dates or forced_maturity_excluded:
            forced_maturity_excluded = True
            counter_date = None
        maturity_date = (
            str(maturity_stage.iloc[0]["phase_date"])
            if not maturity_stage.empty
            else counter_date
        )
        maturity_date_source = (
            "phenology_phase_changed"
            if not maturity_stage.empty
            else "maturity_das_from_sowing" if maturity_date else None
        )
        # Sequence gaps flag unusual/incomplete evidence, not proven resets.
        maturity_quality = (
            "stage_sequence_gap"
            if not maturity_stage.empty
            and bool(maturity_stage.iloc[0]["stage_sequence_gap"])
            else "phase_changed"
            if not maturity_stage.empty
            else "derived_without_phase_event"
            if maturity_date is not None
            else None
        )
        harvest_ripe_stage = (
            stage_rows.loc[stage_rows["stage_name"].eq("HarvestRipe")]
            if stage_rows is not None else pd.DataFrame()
        )
        flowering_stage = (
            stage_rows.loc[stage_rows["stage_name"].eq("Flowering")]
            if stage_rows is not None else pd.DataFrame()
        )
        flowering_counter_date = (
            (
                request.management.planting_date + timedelta(days=round(flowering))
            ).isoformat()
            if flowering is not None
            else None
        )
        raw_flowering_counter_date = flowering_counter_date
        raw_flowering_date = (
            str(flowering_stage.iloc[0]["phase_date"])
            if not flowering_stage.empty
            else flowering_counter_date
        )
        raw_flowering_dap = (
            flowering
            if flowering is not None
            else float(flowering_stage.iloc[0]["dap"])
            if not flowering_stage.empty
            else None
        )
        explicitly_forced_dates = set(
            group.loc[
                _explicit_forced_flags(group).fillna(False),
                "Clock.Today",
            ].dt.strftime("%Y-%m-%d")
        )
        forced_flowering = (
            flowering_stage["forced_transition"].fillna(False)
            | flowering_stage["phase_date"].isin(explicitly_forced_dates)
            if not flowering_stage.empty
            else pd.Series(dtype=bool)
        )
        forced_flowering_dates = (
            set(flowering_stage.loc[forced_flowering, "phase_date"])
            if not flowering_stage.empty
            else set()
        )
        flowering_stage = flowering_stage.loc[~forced_flowering]
        forced_flowering_excluded = bool(forced_flowering.any()) or (
            flowering_counter_date
            in (reset_dates | explicitly_forced_dates | forced_flowering_dates)
        )
        # A counter must not resurrect a rejected phase. A later, independently
        # retained phase remains usable, without requiring harvest or maturity.
        if forced_flowering_excluded:
            flowering = None
            flowering_counter_date = None
        flowering_date = (
            str(flowering_stage.iloc[0]["phase_date"])
            if not flowering_stage.empty
            else flowering_counter_date
        )
        if flowering is None and not flowering_stage.empty:
            flowering = float(flowering_stage.iloc[0]["dap"])
        matured = maturity_date is not None
        yield_kg_ha = _nonnegative_number(
            pd.to_numeric(group["YieldKgHa"], errors="coerce").max()
        )
        biomass_kg_ha = _nonnegative_number(
            pd.to_numeric(group["BiomassKgHa"], errors="coerce").max()
        )
        results[request.request_id] = SimulationResult(
            request_id=request.request_id,
            adapter_name=ADAPTER_NAME,
            adapter_version=adapter_version,
            status=RunStatus.MATURED if matured else RunStatus.NOT_MATURED,
            summary={
                "planting_date": request.management.planting_date.isoformat(),
                "flowering_proxy_dap": flowering,
                "flowering_date": flowering_date,
                "maturity_date": maturity_date,
                "harvest_ripe_date": (
                    str(harvest_ripe_stage.iloc[0]["phase_date"])
                    if not harvest_ripe_stage.empty else None
                ),
                "harvest_date": harvest_date,
                "maturity_date_source": maturity_date_source,
                "maturity_date_quality": maturity_quality,
                "dry_yield_mg_ha": (
                    yield_kg_ha / 1000.0
                    if matured and yield_kg_ha is not None
                    else None
                ),
                "biomass_mg_ha": (
                    biomass_kg_ha / 1000.0 if biomass_kg_ha is not None else None
                ),
                "juvenile_tt": float(
                    request.model_parameters.get("juvenile_tt", 211.0)
                ),
                "grain_number_scale": float(
                    request.model_parameters.get("grain_number_scale", 1.0)
                ),
                **(_cultivar_parameters(request) if _cultivar_mode(request) else {}),
            },
            artifacts={"phenology": stage_rows} if stage_rows is not None else {},
            diagnostics={
                "phenology_report_available": phenology is not None,
                "flowering_event": "Maize.Phenology.Flowering",
                "flowering_date_source": (
                    "phenology_phase_changed" if not flowering_stage.empty
                    else "flowering_das_from_sowing" if flowering_date else None
                ),
                "flowering_observation_mapping": (
                    "pollen_and_silking_proxy_not_separate_native_events"
                ),
                "forced_flowering_excluded": forced_flowering_excluded,
                "raw_flowering_date": raw_flowering_date,
                "raw_flowering_dap": raw_flowering_dap,
                "raw_flowering_counter_date": raw_flowering_counter_date,
                "flowering_rejection_reason": (
                    "explicit_forced_transition_or_same_day_stage_reset"
                    if forced_flowering_excluded
                    else None
                ),
                "forced_transition_evidence": (
                    "stage_was_reset" if reset_dates
                    else "explicit_flag"
                    if stage_rows is not None
                    and stage_rows["forced_transition"].notna().any()
                    else "not_observed"
                ),
                "forced_maturity_excluded": forced_maturity_excluded,
            },
            failure_reason=(
                None if matured else "no harvest event before simulation end"
                if group.empty else "maturity not reached before simulation end"
            ),
        )
    return results


@lru_cache(maxsize=4)
def _reported_version(executable: str) -> str:
    completed = subprocess.run(
        [executable, "--version"],
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )
    match = re.search(r"APSIM\s+([0-9.]+)", completed.stdout)
    if not match:
        raise APSIMValidationError("cannot parse APSIM version")
    return match.group(1)


class APSIMAdapter:
    """Translate SnowWindow requests to APSIM Next Generation."""

    name = ADAPTER_NAME
    version = MODEL_VERSION
    capabilities = ModelCapabilities(
        display_name="APSIM",
        phenology_parameter=CalibrationParameter(
            "juvenile_tt", 211.0, (100.0, 350.0, 25.0), 5.0
        ),
        yield_parameter=CalibrationParameter(
            "grain_number_scale", 1.0, (0.5, 1.5, 0.1), 0.02
        ),
        supported_folds=(FoldStrategy.HELD_YEAR,),
        weather_strategy=WeatherStrategy.G2F,
        scan_request_strategy=ScanRequestStrategy.PER_DATE,
        phenology_stages=APSIM_PHASE_STAGES,
        report_notes=(
            "- 开花日期采用 APSIM Maize 的 `Flowering` 事件，"
            "与 G2F 花粉日期作代理比较。",
            "- 土壤、水氮、施肥和 Dekalb_XL82 品种均为固定探索情景。",
            "- 全局校准仅拟合 `juvenile_tt` 与 `grain_number_scale`。",
        ),
    )

    def __init__(
        self,
        *,
        executable: Path | None = None,
        template_path: Path | None = None,
    ) -> None:
        root = _repo_root()
        self.executable = (executable or root / "bin/apsim").resolve()
        self.template_path = (
            template_path or root / ".tools/apsim/2026.9.8116.0/Examples/Maize.apsimx"
        ).resolve()

    @property
    def source_fingerprints(self) -> dict[str, str]:
        return {
            "adapter_source_sha256": hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
            "apsim_template_sha256": hashlib.sha256(
                self.template_path.read_bytes()
            ).hexdigest(),
            "apsim_executable_sha256": hashlib.sha256(
                self.executable.read_bytes()
            ).hexdigest(),
            "apsim_models_sha256": hashlib.sha256(
                (
                    self.template_path.parent.parent / "bin/Models.dll"
                ).read_bytes()
            ).hexdigest(),
        }

    def validate(self, request: SimulationRequest) -> None:
        if not self.executable.is_file() or not self.template_path.is_file():
            raise APSIMValidationError("APSIM executable or maize template is missing")
        parameters = dict(request.model_parameters)
        requested_version = str(parameters.get("model_version", self.version))
        if requested_version != self.version:
            raise APSIMValidationError(f"model version must be APSIM {self.version}")
        if request.environment.environment_id != request.management.environment_id:
            raise APSIMValidationError("management environment does not match request")
        records = sorted(request.environment.weather, key=lambda item: item.date)
        expected = [
            timestamp.date()
            for timestamp in pd.date_range(request.start_date, request.end_date)
        ]
        if [record.date for record in records] != expected:
            raise APSIMValidationError(
                "every calendar day in the inclusive simulation interval "
                "must have exactly one weather row"
            )
        for record in records:
            try:
                values = {name: float(record.values[name]) for name in REQUIRED_WEATHER}
            except (KeyError, TypeError, ValueError) as exc:
                raise APSIMValidationError(
                    "weather row is missing numeric required values"
                ) from exc
            if (
                not all(math.isfinite(value) for value in values.values())
                or values["T2M_MIN"] > values["T2M_MAX"]
                or values["PRECTOTCORR"] < 0
                or values["ALLSKY_SFC_SW_DWN"] < 0
            ):
                raise APSIMValidationError("weather values are physically invalid")
        juvenile_tt = float(parameters.get("juvenile_tt", 211.0))
        grain_scale = float(parameters.get("grain_number_scale", 1.0))
        if not 50 <= juvenile_tt <= 500:
            raise APSIMValidationError("juvenile_tt must be in [50, 500]")
        if not 0.1 <= grain_scale <= 3:
            raise APSIMValidationError("grain_number_scale must be in [0.1, 3]")
        if _cultivar_mode(request):
            _cultivar_parameters(request)
            _cultivar_input_values(request)

    def run(self, request: SimulationRequest) -> SimulationResult:
        return self.run_many((request,))[request.request_id]

    def run_many(
        self, requests: Iterable[SimulationRequest]
    ) -> dict[str, SimulationResult]:
        ordered = tuple(requests)
        if not ordered:
            return {}
        if len({request.request_id for request in ordered}) != len(ordered):
            raise APSIMValidationError("APSIM batch requires unique request_id values")
        for request in ordered:
            self.validate(request)
        modes = {_cultivar_mode(request) for request in ordered}
        if len(modes) != 1:
            raise APSIMValidationError(
                "cannot mix legacy and cultivar mode in one batch"
            )
        cultivar_mode = modes.pop()
        environments = {request.environment.environment_id for request in ordered}
        if not cultivar_mode and len(environments) != 1:
            raise APSIMValidationError("one APSIM batch must share one environment")
        requests_by_environment: dict[str, list[SimulationRequest]] = {}
        for request in ordered:
            requests_by_environment.setdefault(
                request.environment.environment_id, [],
            ).append(request)
        weather_texts = {}
        for environment_id, group in requests_by_environment.items():
            if cultivar_mode and len({
                (request.environment.latitude, request.environment.longitude)
                for request in group
            }) != 1:
                raise APSIMValidationError(
                    f"conflicting coordinates for environment {environment_id}"
                )
            # Merge only compatible subsets of the SAME environment. Dates in
            # other environments can (and usually do) carry different weather.
            weather_texts[environment_id] = render_met_batch(group)
        if cultivar_mode:
            # The met header's tav/amp are request-window estimates. Unioning
            # different windows would silently change a request's soil thermal
            # boundary. Keep exact standalone weather/window groups together,
            # after validating all overlapping inputs above, including groups
            # which will run separately. Distinct environments can still share
            # one launch, with one compatible weather group per environment.
            weather_lanes: dict[str, int] = {}
            for group in requests_by_environment.values():
                compatible: dict[tuple[date, date, str], list[str]] = {}
                for request in group:
                    signature = (
                        request.start_date,
                        request.end_date,
                        render_met(request),
                    )
                    compatible.setdefault(signature, []).append(request.request_id)
                for lane, request_ids in enumerate(compatible.values()):
                    weather_lanes.update(
                        (request_id, lane) for request_id in request_ids
                    )
            lane_count = max(weather_lanes.values()) + 1
            if lane_count > 1:
                results = {}
                for lane in range(lane_count):
                    results.update(
                        self.run_many(
                            request
                            for request in ordered
                            if weather_lanes[request.request_id] == lane
                        )
                    )
                return {
                    request.request_id: results[request.request_id]
                    for request in ordered
                }
        actual_version = _reported_version(str(self.executable))
        if actual_version != self.version:
            raise APSIMValidationError(
                f"installed APSIM version is {actual_version}, expected {self.version}"
            )
        output_dir = ordered[0].output_dir
        if output_dir is None:
            raise APSIMValidationError("APSIM requests require output_dir")
        request_identities = []
        for request in ordered:
            item = request.to_json_dict()
            item.pop("output_dir", None)
            item["environment"].pop("weather", None)
            request_identities.append(item)
        weather_hashes = {
            key: hashlib.sha256(text.encode()).hexdigest()
            for key, text in weather_texts.items()
        }
        fingerprints = self.source_fingerprints
        identity = {
            "requests": request_identities,
            "weather_sha256": (
                next(iter(weather_hashes.values()))
                if len(environments) == 1 else weather_hashes
            ),
            "version": actual_version,
            "phenology_schema_version": PHENOLOGY_SCHEMA_VERSION,
            "daily_diagnostics_schema_version": DAILY_DIAGNOSTICS_SCHEMA_VERSION,
            "result_schema_version": RESULT_SCHEMA_VERSION,
            "stage_reset_schema_version": STAGE_RESET_SCHEMA_VERSION,
            **fingerprints,
        }
        batch_key = hashlib.sha256(
            json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        run_dir = Path(output_dir) / "apsim" / batch_key
        run_dir.mkdir(parents=True, exist_ok=True)
        model_path = run_dir / "batch.apsimx"
        weather_paths = {}
        for index, environment_id in enumerate(sorted(environments)):
            path = run_dir / (
                "weather.met" if len(environments) == 1 else f"weather_{index:04d}.met"
            )
            path.write_text(weather_texts[environment_id], encoding="utf-8")
            weather_paths[environment_id] = path
        document, name_to_id = build_apsim_document(
            self.template_path,
            ordered,
            weather_filename={
                key: path.name for key, path in weather_paths.items()
            },
        )
        model_path.write_text(
            json.dumps(document, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        requests_by_id = {request.request_id: request for request in ordered}
        requests_by_simulation = {
            simulation_name: requests_by_id[request_id]
            for simulation_name, request_id in name_to_id.items()
        }
        report_path = run_dir / "batch.Report.csv"
        phenology_path = run_dir / "batch.PhenologyReport.csv"
        daily_path = run_dir / "batch.DailyDiagnostics.csv"
        reset_path = run_dir / "batch.StageWasResetReport.csv"
        failure_path = run_dir / "execution_failed.json"
        clock_success_path = run_dir / "clock_completed.json"
        save_daily = any(
            request.model_parameters.get("save_daily_diagnostics", False)
            for request in ordered
        )
        cache_hit = (
            apsim_batch_complete(run_dir, save_daily_diagnostics=save_daily)
            and clock_success_path.is_file()
        )
        execution_error = None
        if not cache_hit:
            # Keep failed/incomplete attempts for provenance and prevent a new
            # engine invocation from silently inheriting their stale CSVs.
            previous_files = [
                path for path in (
                    report_path, phenology_path, daily_path, failure_path,
                    clock_success_path, reset_path,
                    run_dir / "batch.db",
                    run_dir / "stdout.log",
                    run_dir / "stderr.log",
                    *(
                        run_dir / f"{name}.{suffix}.csv"
                        for name in requests_by_simulation
                        for suffix in (
                            "phenology", "soil_diagnostics", "stage_was_reset",
                        )
                    ),
                ) if path.is_file()
            ]
            if previous_files:
                attempt = 0
                while (run_dir / "attempts" / f"{attempt:04d}").exists():
                    attempt += 1
                archive = run_dir / "attempts" / f"{attempt:04d}"
                archive.mkdir(parents=True)
                for path in previous_files:
                    path.rename(archive / path.name)
            try:
                completed = subprocess.run(
                    [
                        str(self.executable), str(model_path),
                        "--single-threaded", "--csv",
                    ],
                    cwd=run_dir, capture_output=True, text=True, timeout=600,
                )
                stdout, stderr = completed.stdout, completed.stderr
                if completed.returncode != 0:
                    execution_error = (
                        stderr.strip() or stdout.strip()
                        or f"APSIM exited with status {completed.returncode}"
                    )[-2000:]
            except subprocess.TimeoutExpired as exc:
                stdout = exc.stdout or ""
                stderr = exc.stderr or ""
                if isinstance(stdout, bytes):
                    stdout = stdout.decode("utf-8", errors="replace")
                if isinstance(stderr, bytes):
                    stderr = stderr.decode("utf-8", errors="replace")
                execution_error = (
                    f"APSIM execution timed out after {exc.timeout} seconds"
                )
            except OSError as exc:
                stdout, stderr = "", str(exc)
                execution_error = f"APSIM execution failed: {exc}"
            (run_dir / "stdout.log").write_text(stdout, encoding="utf-8")
            (run_dir / "stderr.log").write_text(stderr, encoding="utf-8")
            if execution_error is None:
                clock_success_path.write_text(
                    json.dumps({
                        "cache_key": batch_key,
                        "termination_rule": "clock_end",
                        "intervals": {
                            name: {
                                "start_date": request.start_date.isoformat(),
                                "end_date": request.end_date.isoformat(),
                            } for name, request in requests_by_simulation.items()
                        },
                    }, indent=2) + "\n", encoding="utf-8",
                )

        stages: dict[str, pd.DataFrame] = {}
        phenology = None
        phenology_error = None
        stage_resets = None
        try:
            if reset_path.is_file():
                stage_resets = pd.read_csv(reset_path)
            if not phenology_path.is_file():
                raise APSIMValidationError(
                    "APSIM phenology report is missing after execution"
                )
            phenology = pd.read_csv(phenology_path)
            stages = parse_phenology_report(
                phenology, requests_by_simulation, stage_resets=stage_resets,
            )
        except (OSError, ValueError, pd.errors.ParserError) as exc:
            phenology_error = str(exc)

        reason = execution_error or phenology_error
        if reason is None:
            try:
                report = (
                    pd.read_csv(report_path) if report_path.is_file()
                    # APSIM does not export an untriggered harvest table. This
                    # empty input is not persisted as a fabricated engine report.
                    else pd.DataFrame(columns=HARVEST_REPORT_COLUMNS)
                )
                results = parse_report(
                    report, requests_by_simulation,
                    adapter_version=self.version, phenology=phenology,
                    stage_resets=stage_resets,
                )
            except (OSError, ValueError, pd.errors.ParserError) as exc:
                reason = f"APSIM harvest report is invalid: {exc}"
        if reason is not None:
            results = {
                request.request_id: SimulationResult(
                    request_id=request.request_id, adapter_name=self.name,
                    adapter_version=self.version, status=RunStatus.EXECUTION_FAILED,
                    artifacts=(
                        {"phenology": stages[request.request_id]}
                        if request.request_id in stages else {}
                    ),
                    diagnostics={
                        "phenology_report_available": phenology_error is None,
                        "phenology_report_missing": not phenology_path.is_file(),
                    },
                    failure_reason=reason,
                ) for request in ordered
            }

        daily = None
        daily_error = None
        if save_daily:
            try:
                if not daily_path.is_file():
                    raise APSIMValidationError(
                        "APSIM daily diagnostics report is missing after execution"
                    )
                daily = pd.read_csv(daily_path)
                missing = set(DAILY_DIAGNOSTICS_COLUMNS) - set(daily.columns)
                if missing:
                    raise APSIMValidationError(
                        "APSIM daily diagnostics report is missing columns: "
                        + ", ".join(sorted(missing))
                    )
            except (OSError, ValueError, pd.errors.ParserError) as exc:
                daily = None
                daily_error = str(exc)

        attached = {}
        for simulation_name, request in requests_by_simulation.items():
            result = results[request.request_id]
            clock_completed = execution_error is None
            actual_start = request.start_date.isoformat() if clock_completed else None
            actual_end = request.end_date.isoformat() if clock_completed else None
            dates_source = (
                "successful_batch_clock" if clock_completed else "not_observed"
            )
            if not clock_completed and daily is not None:
                observed = pd.to_datetime(
                    daily.loc[daily["SimulationName"].eq(simulation_name),
                              "DiagnosticDate"],
                    format="ISO8601", errors="coerce",
                ).dropna()
                observed = observed.loc[
                    observed.between(pd.Timestamp(request.start_date),
                                     pd.Timestamp(request.end_date))
                ]
                if not observed.empty:
                    actual_start = observed.min().date().isoformat()
                    actual_end = observed.max().date().isoformat()
                    dates_source = "partial_daily_report"
            artifacts = {
                "apsimx": model_path,
                "weather": weather_paths[request.environment.environment_id],
                **{
                    key: path for key, path in (
                        ("report", report_path), ("phenology_report", phenology_path),
                        ("daily_diagnostics_report", daily_path),
                        ("stage_was_reset_report", reset_path),
                        ("clock_execution_record", clock_success_path),
                        ("stdout", run_dir / "stdout.log"),
                        ("stderr", run_dir / "stderr.log"),
                    ) if path.is_file()
                },
            }
            if request.request_id in stages:
                stage_path = run_dir / f"{simulation_name}.phenology.csv"
                stages[request.request_id].to_csv(stage_path, index=False)
                artifacts["phenology"] = stage_path
            reset_group = None
            if stage_resets is not None and phenology_error is None:
                reset_group = stage_resets.loc[
                    stage_resets["SimulationName"].eq(simulation_name)
                ].copy()
                reset_artifact = run_dir / f"{simulation_name}.stage_was_reset.csv"
                reset_group.to_csv(reset_artifact, index=False)
                artifacts["stage_was_reset"] = reset_artifact
            if request.model_parameters.get("save_daily_diagnostics", False):
                request_daily_error = daily_error
                if daily is not None:
                    try:
                        diagnostic_group = _request_daily_diagnostics(
                            daily, simulation_name, request
                        )
                        diagnostic_path = (
                            run_dir / f"{simulation_name}.soil_diagnostics.csv"
                        )
                        diagnostic_group.to_csv(diagnostic_path, index=False)
                        artifacts["soil_diagnostics"] = diagnostic_path
                    except APSIMValidationError as exc:
                        request_daily_error = str(exc)
                if (
                    request_daily_error is not None
                    and result.status is not RunStatus.EXECUTION_FAILED
                ):
                    result = replace(
                        result, status=RunStatus.EXECUTION_FAILED,
                        failure_reason=request_daily_error,
                    )
            attached[request.request_id] = replace(
                result, artifacts=artifacts,
                summary={
                    **result.summary,
                    "actual_simulation_start_date": actual_start,
                    "actual_simulation_end_date": actual_end,
                    "actual_simulation_dates_source": dates_source,
                    "clock_completed": clock_completed,
                    "termination_rule": "clock_end" if clock_completed else None,
                },
                diagnostics={
                    **result.diagnostics, **fingerprints,
                    **({
                        "cultivar_parameters": _cultivar_parameters(request),
                        "native_cultivar_name": _cultivar_name(request),
                        "native_input_assumptions": {
                            "photoperiod_sensitivity_units": (
                                "deg_day_target_at_24h"
                            ),
                            "initial_mineral_n_distribution": "uniform_per_depth",
                            "air_dry": "0.5 * theta_wp",
                            "fresh_organic_matter": "zero_without_input_evidence",
                            "initial_surface_residue": "zero_without_input_evidence",
                            "ancillary_soil_parameters": "template_depth_remapped",
                            "fertilizer": "scheduled_surface_NO3N_only",
                            "irrigation": "scheduled_only_efficiency_1",
                            "default_sowing_depth_m": 0.03,
                            "default_row_spacing_m": 0.75,
                        },
                    } if _cultivar_mode(request) else {}),
                    "cache_key": batch_key, "cache_hit": cache_hit,
                    "phenology_schema_version": PHENOLOGY_SCHEMA_VERSION,
                    "daily_diagnostics_schema_version": (
                        DAILY_DIAGNOSTICS_SCHEMA_VERSION
                    ),
                    "result_schema_version": RESULT_SCHEMA_VERSION,
                    "stage_reset_schema_version": STAGE_RESET_SCHEMA_VERSION,
                    "harvest_report_available": report_path.is_file(),
                    "stage_reset_report_available": reset_group is not None,
                    "forced_stage_configuration": "none",
                    "forced_transition_evidence": (
                        "stage_was_reset"
                        if reset_group is not None and not reset_group.empty
                        else result.diagnostics.get(
                            "forced_transition_evidence", "not_observed",
                        )
                    ),
                    "forced_transition_attribution": "same_day_conservative",
                },
            )
        failures = {
            request_id: result.failure_reason
            for request_id, result in attached.items()
            if result.status is RunStatus.EXECUTION_FAILED
        }
        if failures:
            for request_id in failures:
                result = attached[request_id]
                attached[request_id] = replace(
                    result,
                    artifacts={**result.artifacts, "failure_record": failure_path},
                )
            failure_path.write_text(
                json.dumps(
                    {
                        "cache_key": batch_key,
                        "failures": failures,
                        "results": {
                            request_id: attached[request_id].to_json_dict()
                            for request_id in failures
                        },
                    },
                    indent=2,
                    allow_nan=False,
                )
                + "\n", encoding="utf-8",
            )
        return attached
