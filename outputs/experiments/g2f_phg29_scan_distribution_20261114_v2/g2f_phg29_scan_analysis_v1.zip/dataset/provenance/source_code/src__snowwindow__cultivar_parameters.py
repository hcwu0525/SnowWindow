"""Native parameter evidence, not cultivar measurements or probability priors.

Bounds are deliberately constrained *search assumptions*. They are not confidence
intervals. Direct-trait availability is not a claim of parameter identifiability.
No native engine is imported; source locators refer to the installed versions.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass, replace
from typing import Literal

OBSERVED_TRAITS = ("pollen_dap", "silk_dap", "dry_yield_mg_ha")
AQUACROP_SOURCE = (
    ".venv/lib/python3.10/site-packages/aquacrop/entities/crops/crop_params.py"
    "::crop_params['MaizeGDD'] (AquaCrop-OSPy 3.1.0)"
)
APSIM_SOURCE = (
    ".tools/apsim/2026.9.8116.0/bin/Models.dll"
    "::embedded Maize resource, CultivarFolder.Dekalb_XL82"
)
DSSAT_SOURCE = (
    ".tools/dssat/4.8.6.2/Genotype/MZCER048.CUL"
    "::IB0035; definitions and 999991 MINIMA / 999992 MAXIMA"
)
FINAL_ROUND_BOUNDS = {
    "aquacrop": {
        "HIstart": (700.0, 1000.0),
        "HI0": (0.25, 0.60),
        "postflower_scale": (0.80, 1.00),
    },
    "apsim": {
        "juvenile_tt": (50.0, 350.0),
        "potential_grain_number": (350.0, 1000.0),
        "photoperiod_sensitivity": (0.0, 650.0),
        "flag_leaf_tt": (60.0, 160.0),
    },
    "dssat": {
        "P1": (100.0, 350.0),
        "P2": (0.0, 2.0),
        "G2": (400.0, 990.0),
        "PHINT": (38.0, 60.0),
    },
}
FINAL_ROUND_RATIONALE = (
    "Prespecified final-round search assumption derived from the completed 96-request "
    "diagnostics; not a cultivar measurement, confidence interval, or proof of "
    "physiological identifiability."
)


@dataclass(frozen=True)
class ParameterSpec:
    """Scalar native mapping; ``prior`` is a starting/reference value only."""

    name: str
    native_key: str
    prior: float
    lower: float
    upper: float
    role: Literal["fit", "fixed", "uncertain"] = "fit"
    stage: str = "phenology"
    units: str = ""
    source: str = ""
    bounds_rationale: str = ""
    direct_traits: tuple[str, ...] = ()
    available_direct_traits: tuple[str, ...] = ()
    indirect_traits: tuple[str, ...] = ()
    support_note: str = ""
    prior_kind: str = "reference_value_not_probability_distribution"

    def __post_init__(self) -> None:
        if (
            not self.name
            or not self.native_key
            or not all(math.isfinite(x) for x in (self.prior, self.lower, self.upper))
            or not self.lower < self.upper
            or not self.lower <= self.prior <= self.upper
            or self.role not in {"fit", "fixed", "uncertain"}
        ):
            raise ValueError(
                "parameter needs finite ordered bounds and an in-bound prior"
            )


def parameter_catalog(
    observed_traits: tuple[str, ...] = OBSERVED_TRAITS,
    *,
    model: str | None = None,
    pragmatic: bool = False,
) -> dict[str, tuple[ParameterSpec, ...]] | tuple[ParameterSpec, ...]:
    """Return all evidence, including fixed/uncertain parameters lacking traits.

    APSIM ``photoperiod_sensitivity`` is the thermal target at 24 h, not
    a days/hour slope: retain native X=[0,12.5,24], Y=[0,0,value].
    AquaCrop HIstart is a harvest-index/flowering *proxy*, not measured pollen.
    """

    def spec(
        name: str,
        prior: float,
        lower: float,
        upper: float,
        *,
        native: str | None = None,
        role: str = "uncertain",
        stage: str = "phenology",
        units: str = "degC day",
        source: str,
        direct: tuple[str, ...] = (),
        indirect: tuple[str, ...] = (),
        note: str,
        bounds: str,
    ) -> ParameterSpec:
        return ParameterSpec(
            name,
            native or name,
            prior,
            lower,
            upper,
            role,
            stage,
            units,
            source,
            bounds,
            direct,
            (),
            indirect,
            note,
        )

    flower = ("pollen_dap",)
    yield_trait = ("dry_yield_mg_ha",)
    reference_bounds = (
        "Analyst-constrained range around installed reference; no cultivar-specific "
        "measurement or published probability prior is available."
    )
    aq = (
        spec(
            "HIstart",
            880,
            600,
            1200,
            role="fit",
            source=AQUACROP_SOURCE,
            indirect=flower,
            note="Pollen timing proxy only; not independent anthesis.",
            bounds=reference_bounds,
        ),
        spec(
            "HI0",
            0.48,
            0.30,
            0.60,
            role="fit",
            stage="yield",
            units="fraction",
            source=AQUACROP_SOURCE,
            indirect=yield_trait,
            note="Effective yield partitioning; no measured harvest index.",
            bounds=reference_bounds,
        ),
        spec(
            "Flowering",
            180,
            100,
            260,
            source=AQUACROP_SOURCE,
            direct=("flowering_duration_gdd",),
            indirect=yield_trait,
            note="Duration is not identified by a single pollen/silk date.",
            bounds=reference_bounds,
        ),
        spec(
            "YldForm",
            750,
            550,
            900,
            source=AQUACROP_SOURCE,
            direct=("grain_fill_duration_gdd",),
            indirect=yield_trait,
            note="No observed grain-fill duration; potentially yield-confounded.",
            bounds=reference_bounds,
        ),
        spec(
            "Maturity",
            1700,
            1400,
            2100,
            source=AQUACROP_SOURCE,
            direct=("maturity_dap",),
            indirect=yield_trait,
            note="Harvest date is not physiological maturity.",
            bounds=reference_bounds,
        ),
        spec(
            "Senescence",
            1400,
            1100,
            1700,
            role="fixed",
            source=AQUACROP_SOURCE,
            direct=("senescence_dap",),
            note="No observed senescence.",
            bounds=reference_bounds,
        ),
        spec(
            "CCx",
            0.96,
            0.75,
            0.99,
            role="fixed",
            stage="canopy",
            units="fraction",
            source=AQUACROP_SOURCE,
            direct=("canopy_cover",),
            note="No measured canopy or LAI; do not infer from yield alone.",
            bounds=reference_bounds,
        ),
        spec(
            "CGC",
            0.012494,
            0.008,
            0.016,
            role="fixed",
            stage="canopy",
            units="1/GDD",
            source=AQUACROP_SOURCE,
            direct=("canopy_cover",),
            note="Canopy growth unsupported by measured LAI/cover.",
            bounds=reference_bounds,
        ),
        spec(
            "WP",
            33.7,
            28,
            38,
            stage="yield",
            units="g/m2",
            source=AQUACROP_SOURCE,
            direct=("biomass_mg_ha",),
            indirect=yield_trait,
            note="No biomass; yield confounds productivity and harvest index.",
            bounds=reference_bounds,
        ),
    )
    ap = (
        spec(
            "juvenile_tt",
            211,
            100,
            350,
            role="fit",
            native="[Phenology].Juvenile.Target.FixedValue",
            source=APSIM_SOURCE,
            direct=flower,
            note="Flower timing constrains combined preflower phases.",
            bounds=reference_bounds,
        ),
        spec(
            "photoperiod_sensitivity",
            472,
            0,
            650,
            native="[Phenology].Photosensitive.Target.XYPairs.Y[2]",
            source=APSIM_SOURCE,
            direct=flower,
            note="Needs day-length leverage; value is 24-hour thermal target.",
            bounds=reference_bounds,
        ),
        spec(
            "flag_leaf_tt",
            101,
            60,
            160,
            native="[Phenology].FlagLeafToFlowering.Target.FixedValue",
            source=APSIM_SOURCE,
            direct=("flag_leaf_dap",),
            indirect=flower,
            note="No flag-leaf observations; confounded with juvenile duration.",
            bounds=reference_bounds,
        ),
        spec(
            "flowering_to_grain_fill_tt",
            170,
            100,
            250,
            native="[Phenology].FloweringToGrainFilling.Target.FixedValue",
            source=APSIM_SOURCE,
            direct=("grain_fill_start_dap",),
            indirect=yield_trait,
            note="No measured grain-fill onset.",
            bounds=reference_bounds,
        ),
        spec(
            "grain_fill_tt",
            813,
            600,
            1000,
            native="[Phenology].GrainFilling.Target.FixedValue",
            source=APSIM_SOURCE,
            direct=("maturity_dap",),
            indirect=yield_trait,
            note="No measured maturity; yield-only response may be confounded.",
            bounds=reference_bounds,
        ),
        spec(
            "potential_grain_number",
            550,
            350,
            850,
            role="fit",
            stage="yield",
            units="kernels/cob",
            native="[Grain].MaximumGrainsPerCob.PotentialMaximumGrainsPerCob.FixedValue",
            source=APSIM_SOURCE,
            direct=("kernels_per_cob",),
            indirect=yield_trait,
            note="Effective yield sink parameter, not measured kernel number.",
            bounds=reference_bounds,
        ),
        spec(
            "maximum_grain_size_g",
            0.3,
            0.18,
            0.4,
            stage="yield",
            units="g/kernel",
            native="[Grain].MaximumPotentialGrainSize.FixedValue",
            source=APSIM_SOURCE + "; Grain.MaximumPotentialGrainSize",
            direct=("grain_size_g",),
            indirect=yield_trait,
            note="No kernel mass; confounded with grain number.",
            bounds=reference_bounds,
        ),
    )
    ds_bounds = (
        "Constrained within installed CUL MINIMA/MAXIMA; reference-start assumption, "
        "not a cultivar-specific probability prior."
    )
    ds_flower = ("silk_dap",)
    ds = (
        spec(
            "P1",
            259,
            100,
            350,
            role="fit",
            source=DSSAT_SOURCE,
            direct=ds_flower,
            note="CERES-Maize ADAT is the silking stage; P1/P2/PHINT are confounded.",
            bounds=ds_bounds,
        ),
        spec(
            "P2",
            1.193,
            0,
            2,
            units="day/hour",
            source=DSSAT_SOURCE,
            direct=ds_flower,
            note="Needs photoperiod leverage; not automatically identifiable.",
            bounds=ds_bounds,
        ),
        spec(
            "P5",
            947.1,
            600,
            999,
            source=DSSAT_SOURCE,
            direct=("maturity_dap",),
            indirect=yield_trait,
            note="No measured maturity; harvest is not an admissible substitute.",
            bounds=ds_bounds,
        ),
        spec(
            "G2",
            924.3,
            400,
            990,
            role="fit",
            stage="yield",
            units="kernels/plant",
            source=DSSAT_SOURCE,
            direct=("kernels_per_plant",),
            indirect=yield_trait,
            note="Effective yield coefficient; no measured kernels/plant.",
            bounds=ds_bounds,
        ),
        spec(
            "G3",
            8.168,
            5,
            12,
            stage="yield",
            units="mg/day",
            source=DSSAT_SOURCE,
            direct=("kernel_growth_mg_day",),
            indirect=yield_trait,
            note="No serial kernel growth; G2/G3/P5 confounding.",
            bounds=ds_bounds,
        ),
        spec(
            "PHINT",
            43,
            38,
            60,
            role="fixed",
            source=DSSAT_SOURCE,
            direct=("leaf_appearance_gdd",),
            indirect=ds_flower,
            note="No leaf-appearance data; native CUL labels this not calibrated.",
            bounds=ds_bounds,
        ),
    )
    if pragmatic:
        aq += (
            spec(
                "postflower_scale",
                1.0,
                0.5,
                1.25,
                native="coupled_postflower_durations",
                stage="yield",
                units="dimensionless",
                source=AQUACROP_SOURCE,
                indirect=yield_trait,
                note=(
                    "Coupled structural approximation, "
                    "not independent native estimates."
                ),
                bounds=reference_bounds,
            ),
        )
    catalog = {"aquacrop": aq, "apsim": ap, "dssat": ds}
    available = set(observed_traits)
    catalog = {
        key: tuple(
            replace(
                p,
                available_direct_traits=tuple(
                    trait for trait in p.direct_traits if trait in available
                ),
            )
            for p in specs
        )
        for key, specs in catalog.items()
    }
    if model is not None:
        if model not in catalog:
            raise ValueError(f"unknown model: {model}")
        return catalog[model]
    return catalog


def final_round_parameter_catalog(model: str) -> tuple[ParameterSpec, ...]:
    """Apply the prespecified final-round bounds to the evidence catalog.

    These are experiment-level search ranges, not newly discovered native limits.
    ``PHINT`` remains explicitly weakly identified: it is an effective preflower
    alternative in this protocol, not a calibrated leaf-appearance measurement.
    """
    if model not in FINAL_ROUND_BOUNDS:
        raise ValueError(f"unknown model: {model}")
    result = []
    for spec in parameter_catalog(model=model, pragmatic=True):
        bounds = FINAL_ROUND_BOUNDS[model].get(spec.name)
        role, support_note = spec.role, spec.support_note
        if spec.name == "PHINT":
            role = "uncertain"
            support_note = (
                support_note
                + " Final-round effective parameter with unconfirmed identifiability."
            )
        if bounds is None:
            result.append(replace(spec, role=role, support_note=support_note))
            continue
        lower, upper = bounds
        if not lower <= spec.prior <= upper:
            raise ValueError(f"final-round bounds exclude reference prior: {spec.name}")
        result.append(
            replace(
                spec,
                lower=lower,
                upper=upper,
                role=role,
                support_note=support_note,
                bounds_rationale=FINAL_ROUND_RATIONALE,
            )
        )
    return tuple(result)


def candidate_parameter_sets(
    model: str,
    *,
    include_uncertain: bool = False,
    supported_names: Sequence[str] | None = None,
    pragmatic: bool = False,
) -> tuple[tuple[str, ...], ...]:
    """Nested baseline → timing → joint sets; uncertain expansion is opt-in.

    Default expansion includes only uncertain preflower timing alternatives.
    Explicit ``supported_names`` can override this evidence gate. Requesting a
    fixed-role coefficient (e.g. PHINT) here does not change its role: callers
    must explicitly replace its spec with an evidence-documented role override
    before fitting. Expanded sets are not identifiability assertions.
    """
    specs = parameter_catalog(model=model, pragmatic=pragmatic)
    names = [p.name for p in specs if p.role == "fit" and p.stage == "phenology"]
    sets = [(), tuple(names)]
    names.extend(p.name for p in specs if p.role == "fit" and p.stage != "phenology")
    sets.append(tuple(names))
    if include_uncertain:
        if supported_names is not None and (
            len(set(supported_names)) != len(supported_names)
            or not set(supported_names) <= {p.name for p in specs}
        ):
            raise ValueError("supported_names must be unique known native parameters")
        allowed = (
            set(supported_names)
            if supported_names is not None
            else {
                p.name
                for p in specs
                if p.role == "uncertain"
                and (
                    {"pollen_dap", "silk_dap"}
                    & set(p.available_direct_traits + p.indirect_traits)
                )
            }
        )
        for parameter in specs:
            if parameter.name in allowed and parameter.name not in names:
                names.append(parameter.name)
                sets.append(tuple(names))
    return tuple(sets)
