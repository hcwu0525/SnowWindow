"""Generate isolated DSSAT maize inputs and read native DSSAT outputs."""

from __future__ import annotations

import hashlib
import json
import math
import re
import subprocess
from collections.abc import Mapping
from datetime import date
from functools import cached_property
from pathlib import Path

from snowwindow.domain import (
    CalibrationParameter,
    FoldStrategy,
    ModelCapabilities,
    RunStatus,
    ScanRequestStrategy,
    SimulationRequest,
    SimulationResult,
    WeatherStrategy,
)

VERSION = "4.8.6.2"
SOIL_ID = "IB00000007"  # DSSAT reference deep sandy loam, not a G2F measurement.
CULTIVAR = "IB0035"  # Reference McCurdy 84aa; G2F genotype is not identified.
P1_DEFAULT = 259.0
G2_DEFAULT = 924.3
WEATHER_FIELDS = ("ALLSKY_SFC_SW_DWN", "T2M_MAX", "T2M_MIN", "PRECTOTCORR")
NATIVE_COEFFICIENTS = ("P1", "P2", "P5", "G2", "G3", "PHINT")
SOIL_PROPERTIES = (
    "theta_wp",
    "theta_fc",
    "theta_sat",
    "ksat_mm_day",
    "bulk_density_g_cm3",
    "sand_pct",
    "clay_pct",
    "organic_carbon_pct",
)


class DSSATValidationError(ValueError):
    """Inputs cannot be represented safely by the DSSAT maize adapter."""


def _date_code(value: date) -> str:
    return f"{value.year % 100:02d}{value.timetuple().tm_yday:03d}"


def _cultivar_mode(request: SimulationRequest) -> bool:
    return request.environment.metadata.get("cultivar_calibration") is True


def _number(value: object, name: str, low: float, high: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise DSSATValidationError(f"{name} must be a finite number") from exc
    if (
        isinstance(value, bool)
        or not math.isfinite(number)
        or not low <= number <= high
    ):
        raise DSSATValidationError(f"{name} must be in [{low}, {high}]")
    return number


def _fixed(value: float, decimals: int = 3, width: int = 5) -> str:
    """Explicit decimal points avoid Fortran Fw.0's implied-decimal surprises."""
    for precision in range(decimals, -1, -1):
        rendered = f"{value:{width}.{precision}f}"
        if len(rendered) == width and (value == 0 or float(rendered) != 0):
            return rendered
    raise DSSATValidationError(f"value {value} is not representable in {width} columns")


def _prior_row(template: str, request: SimulationRequest) -> str:
    cultivar = str(request.model_parameters.get("cultivar", CULTIVAR))
    rows = [line for line in template.splitlines() if line[:6] == cultivar]
    if not re.fullmatch(r"[A-Za-z0-9]{6}", cultivar) or len(rows) != 1:
        raise DSSATValidationError(
            f"native cultivar prior {cultivar} not found uniquely"
        )
    return rows[0]


def _native_coefficients(template: str, request: SimulationRequest) -> dict[str, float]:
    row = _prior_row(template, request)
    coefficients = {}
    # Broad representable physical limits, not cultivar-specific calibration bounds.
    for index, (name, low, high, precision) in enumerate(
        (
            ("P1", 0.1, 9999, 1),
            ("P2", 0, 99.999, 3),
            ("P5", 0.1, 9999, 1),
            ("G2", 1, 9999, 1),
            ("G3", 0.001, 99.999, 3),
            ("PHINT", 0.01, 999.99, 2),
        )
    ):
        value = _number(
            request.model_parameters.get(name, row[36 + index * 6 : 42 + index * 6]),
            name,
            low,
            high,
        )
        coefficients[name] = float(_fixed(value, decimals=precision, width=6))
    return coefficients


def render_native_cultivar(template: str, request: SimulationRequest) -> str:
    """Tune six F6.0 fields of an explicitly selected source prior, not its name."""
    row = _prior_row(template, request)
    coefficients = _native_coefficients(template, request)
    updated = (
        row[:36]
        + "".join(
            _fixed(coefficients[name], decimals=precision, width=6)
            for name, precision in zip(
                NATIVE_COEFFICIENTS, (1, 3, 1, 1, 3, 2), strict=True
            )
        )
        + row[72:]
    )
    return template.replace(row, updated, 1)


def _soil_id(request: SimulationRequest) -> str:
    payload = json.dumps(
        [layer.to_json_dict() for layer in request.environment.soil], sort_keys=True
    )
    return "SW" + hashlib.sha256(payload.encode()).hexdigest()[:8].upper()


def render_soil(request: SimulationRequest) -> str:
    """Render the shared sourced profile; DSSAT uses cm depths and cm/hour Ksat."""
    layers = request.environment.soil
    if not layers or len(layers) > 20:
        raise DSSATValidationError("soil requires 1-20 sourced layers")
    previous = 0.0
    rows = []
    for layer in layers:
        top = _number(layer.top_depth_m, "soil top depth", 0, 9.99)
        bottom = _number(layer.bottom_depth_m, "soil bottom depth", 0.01, 9.99)
        if not math.isclose(top, previous, abs_tol=1e-8) or bottom <= top:
            raise DSSATValidationError(
                "soil layers must be contiguous from the surface"
            )
        if not math.isclose(bottom * 100, round(bottom * 100), abs_tol=1e-8):
            raise DSSATValidationError("soil depth requires whole-centimetre precision")
        if not layer.source.strip():
            raise DSSATValidationError("soil layer source evidence is required")
        values = {
            name: _number(
                layer.properties.get(name),
                name,
                0,
                100000 if name == "ksat_mm_day" else 100,
            )
            for name in SOIL_PROPERTIES
        }
        wp, fc, sat = (values[name] for name in SOIL_PROPERTIES[:3])
        if not 0 <= wp < fc < sat <= 0.75 or not (
            round(wp, 3) < round(fc, 3) < round(sat, 3)
        ):
            raise DSSATValidationError("soil theta_wp < theta_fc < theta_sat <= 0.75")
        if not 0.5 <= values["bulk_density_g_cm3"] <= 2.5:
            raise DSSATValidationError("soil bulk_density_g_cm3 must be in [0.5, 2.5]")
        if values["sand_pct"] + values["clay_pct"] > 100:
            raise DSSATValidationError("soil sand_pct + clay_pct must not exceed 100")
        # Root distribution is a declared generic DSSAT assumption, not measured.
        center_cm = (top + bottom) * 50
        root = 1.0 if bottom <= 0.15 else math.exp(-0.02 * center_cm)
        fields = (
            (wp, 3),
            (fc, 3),
            (sat, 3),
            (root, 3),
            (values["ksat_mm_day"] / 240, 3),
            (values["bulk_density_g_cm3"], 3),
            (values["organic_carbon_pct"], 3),
            (values["clay_pct"], 2),
            (100 - values["sand_pct"] - values["clay_pct"], 2),
        )
        rows.extend(
            (
                "! source: " + json.dumps(layer.source, ensure_ascii=True),
                f"{round(bottom * 100):6d}   -99"
                + "".join(" " + _fixed(value, precision) for value, precision in fields)
                + "   0.0   -99   -99   -99   -99   -99",
            )
        )
        previous = bottom
    return "\n".join(
        (
            f"*{_soil_id(request)}  {'SnowWindow':11s} {'-99':5s}"
            f" {round(previous * 100):5d}"
            " G2F sourced profile",
            "@SITE        COUNTRY          LAT     LONG SCS FAMILY",
            f" {'G2F':11s} {'USA':11s} {request.environment.latitude:8.3f}"
            f" {request.environment.longitude:8.3f} -99",
            "! Declared generic assumptions: SALB=.13 SLU1=6 SLDR=.5 SLRO=73;"
            " SLNF=SLPF=1; SRGF=exp(-.02*layer_center_cm).",
            "@ SCOM  SALB  SLU1  SLDR  SLRO  SLNF  SLPF  SMHB  SMPX  SMKE",
            "   -99  0.13   6.0  0.50  73.0  1.00  1.00 IB001 IB001 IB001",
            "@  SLB  SLMH  SLLL  SDUL  SSAT  SRGF  SSKS  SBDM  SLOC  SLCL"
            "  SLSI  SLCF  SLNI  SLHW  SLHB  SCEC  SADC",
            *rows,
            "",
        )
    )


def _events(
    request: SimulationRequest, name: str, amount_key: str
) -> list[tuple[date, float]]:
    events = request.management.metadata.get(name, ())
    if not isinstance(events, (tuple, list)) or len(events) > 200:
        raise DSSATValidationError(f"{name} requires at most 200 dated events")
    result = []
    for event in events:
        if not isinstance(event, Mapping):
            raise DSSATValidationError(f"{name} requires dated event mappings")
        value = event.get("date")
        try:
            when = value if type(value) is date else date.fromisoformat(str(value))
        except ValueError as exc:
            raise DSSATValidationError(f"{name} requires valid ISO dates") from exc
        if not request.start_date <= when <= request.end_date:
            raise DSSATValidationError(f"{name} date outside simulation interval")
        amount = _number(event.get(amount_key), f"{name}.{amount_key}", 0, 99999)
        result.append((when, float(_fixed(amount))))
    return sorted(result)


def _native_management(request: SimulationRequest) -> dict[str, object]:
    metadata = request.management.metadata
    population = _number(
        request.management.population_plants_m2, "population_plants_m2", 1, 20
    )
    verified = metadata.get("population_verified") is True or (
        "population_verified" not in metadata
        and metadata.get("population_source") == "verified_sowing_record"
    )
    assumed = (
        isinstance(metadata.get("population_assumption"), str)
        and metadata["population_assumption"].strip()
    ) or (
        metadata.get("population_source") == "assumption"
        and isinstance(metadata.get("assumption_source"), str)
        and metadata["assumption_source"].strip()
    )
    if not (verified or assumed):
        raise DSSATValidationError(
            "population requires verified sowing density"
            " or a sourced explicit assumption"
        )
    irrigation = _events(request, "irrigation_events", "amount_mm")
    fertilizer = _events(request, "fertilizer_events", "nitrogen_kg_ha")
    assumption = request.management.irrigation_assumption
    if assumption == "irrigated_confirmed":
        if not irrigation:
            raise DSSATValidationError("confirmed irrigation requires a dated schedule")
    elif assumption in ("rainfed_confirmed", "assumed_rainfed", "rainfed_assumed"):
        if irrigation:
            raise DSSATValidationError(
                "rainfed irrigation assumption conflicts with events"
            )
    else:
        raise DSSATValidationError(
            "irrigation must be confirmed or explicitly assumed rainfed"
        )
    return {
        "population": float(_fixed(population, 2)),
        "population_verified": verified,
        "population_assumption": metadata.get("population_assumption")
        or (metadata.get("assumption_source") if assumed and not verified else None),
        "depth_cm": _number(
            metadata.get("sowing_depth_m", 0.05), "sowing_depth_m", 0.005, 0.3
        )
        * 100,
        "row_cm": _number(metadata.get("row_spacing_m", 0.75), "row_spacing_m", 0.05, 3)
        * 100,
        "irrigation": irrigation,
        "fertilizer": fertilizer,
    }


def _native_initial_rows(request: SimulationRequest) -> str:
    initial = request.environment.metadata.get("initial_conditions")
    if not isinstance(initial, Mapping):
        raise DSSATValidationError("initial_conditions must be explicitly supplied")
    fraction = _number(
        initial.get("available_water_fraction"), "available_water_fraction", 0, 1
    )
    mass_per_ppm = sum(
        10
        * (layer.bottom_depth_m - layer.top_depth_m)
        * float(layer.properties["bulk_density_g_cm3"])
        for layer in request.environment.soil
    )
    no3 = _number(initial.get("no3_kg_ha"), "no3_kg_ha", 0, 100 * mass_per_ppm)
    nh4 = _number(initial.get("nh4_kg_ha"), "nh4_kg_ha", 0, 100 * mass_per_ppm)
    rows = []
    for layer in request.environment.soil:
        wp = float(layer.properties["theta_wp"])
        fc = float(layer.properties["theta_fc"])
        water = wp + fraction * (fc - wp)
        rows.append(
            f" 1 {round(layer.bottom_depth_m * 100):5d}"
            f" {_fixed(water)} {_fixed(nh4 / mass_per_ppm)}"
            f" {_fixed(no3 / mass_per_ppm)}\n"
        )
    return "".join(rows)


def _render_native_experiment(request: SimulationRequest) -> str:
    """Build one treatment without borrowing reference soil/N/irrigation events."""
    if not request.start_date <= request.management.planting_date <= request.end_date:
        raise DSSATValidationError("planting date must be within simulation interval")
    render_soil(request)  # Validate before converting profile totals.
    management = _native_management(request)
    initial_rows = _native_initial_rows(request)
    planted = _date_code(request.management.planting_date)
    start = _date_code(request.start_date)
    end = _date_code(request.end_date)
    cultivar = str(request.model_parameters.get("cultivar", CULTIVAR))
    irrigation = management["irrigation"]
    fertilizer = management["fertilizer"]
    population = management["population"]
    # CU FL SA IC MP MI MF MR MC MT ME MH SM; undefined factors must be zero.
    factors = (
        1,
        1,
        0,
        1,
        1,
        int(bool(irrigation)),
        int(bool(fertilizer)),
        0,
        0,
        0,
        0,
        0,
        1,
    )
    text = (
        "*EXP.DETAILS: G2F cultivar calibration, one sourced-input treatment\n\n"
        "*TREATMENTS                        -------------FACTOR LEVELS------------\n"
        "@N R O C TNAME.................... CU FL SA IC MP MI MF MR MC MT ME MH SM\n"
        f" 1 1 0 0 {'G2F CULTIVAR':25s}"
        + "".join(f"{factor:3d}" for factor in factors)
        + "\n\n"
        "*CULTIVARS\n@C CR INGENO CNAME\n"
        f" 1 MZ {cultivar} Parameter prior, NOT genotype identity\n\n"
        "*FIELDS\n"
        "@L ID_FIELD WSTA....  FLSA  FLOB  FLDT  FLDD  FLDS  FLST"
        " SLTX  SLDP  ID_SOIL    FLNAME\n"
        " 1 G2F00001 G2FW       -99     0 DR000     0     0 00000"
        f" -99  {round(request.environment.soil[-1].bottom_depth_m * 100):5d}"
        f"  {_soil_id(request)} Sourced profile\n"
        "@L ...........XCRD ...........YCRD .....ELEV .............AREA"
        " .SLEN .FLWR .SLAS FLHST FHDUR\n"
        f" 1 {request.environment.longitude:15.4f}"
        f" {request.environment.latitude:15.4f}"
        f" {float(request.environment.metadata.get('elevation_m', 0)):9.0f}"
        "                 0     0     0     0   -99   -99\n\n"
        "*INITIAL CONDITIONS\n"
        "@C   PCR ICDAT  ICRT  ICND  ICRN  ICRE  ICWD"
        " ICRES ICREN ICREP ICRIP ICRID ICNAME\n"
        f" 1    MZ {start}     0     0     1     1"
        "   -99     0     0     0   100     0 -99\n"
        "@C  ICBL  SH2O  SNH4  SNO3\n" + initial_rows + "\n"
        "*PLANTING DETAILS\n"
        "@P PDATE EDATE  PPOP  PPOE  PLME  PLDS  PLRS  PLRD  PLDP"
        "  PLWT  PAGE  PENV  PLPH  SPRL                        PLNAME\n"
        f" 1 {planted}   -99 {_fixed(population, 2)} {_fixed(population, 2)}"
        f"     S     R {_fixed(management['row_cm'], 2)}     0"
        f" {_fixed(management['depth_cm'], 2)}"
        "   -99   -99   -99   -99     0                        -99\n\n"
        "*IRRIGATION AND WATER MANAGEMENT\n"
        "@I  EFIR  IDEP  ITHR  IEPT  IOFF  IAME  IAMT IRNAME\n"
        " 1     1   -99   -99   -99   -99   -99   -99 -99\n"
    )
    if irrigation:
        text += "@I IDATE  IROP IRVAL\n" + "".join(
            f" 1 {_date_code(when)} IR001 {_fixed(amount)}\n"
            for when, amount in irrigation
        )
    text += (
        "\n*FERTILIZERS (INORGANIC)\n"
        "@F FDATE  FMCD  FACD  FDEP  FAMN  FAMP  FAMK  FAMC  FAMO  FOCD FERNAME\n"
        "! Declared application assumption: FE001/AP001 at 10 cm; no P/K/C/other.\n"
    )
    text += "".join(
        f" 1 {_date_code(when)} FE001 AP001    10 {_fixed(amount)}"
        "     0     0     0     0   -99 -99\n"
        for when, amount in fertilizer
    )
    text += (
        "\n*SIMULATION CONTROLS\n"
        "@N GENERAL     NYERS NREPS START SDATE RSEED"
        " SNAME.................... SMODEL\n"
        f" 1 GE              1     1     S {start}  2150 G2F cultivar calibration\n"
        "@N OPTIONS     WATER NITRO SYMBI PHOSP POTAS DISES  CHEM  TILL   CO2\n"
        " 1 OP              Y     Y     N     N     N     N     N     N     M\n"
        "@N METHODS     WTHER INCON LIGHT EVAPO INFIL PHOTO HYDRO NSWIT"
        " MESOM MESEV MESOL\n"
        " 1 ME              M     M     E     R     S     R     R     1"
        "     G     R     2\n"
        "@N MANAGEMENT  PLANT IRRIG FERTI RESID HARVS\n"
        f" 1 MA              R     {'R' if irrigation else 'N'}"
        f"     {'R' if fertilizer else 'N'}     N     M\n"
        "@N OUTPUTS     FNAME OVVEW SUMRY FROPT GROUT CAOUT WAOUT NIOUT"
        " MIOUT DIOUT VBOSE CHOUT OPOUT FMOPT\n"
        " 1 OU              N     Y     Y     1     Y     N     Y     Y"
        "     N     N     Y     N     Y     A\n\n"
        "@  AUTOMATIC MANAGEMENT\n"
        "@N PLANTING    PFRST PLAST PH2OL PH2OU PH2OD PSTMX PSTMN\n"
        f" 1 PL          {planted} {planted}    40   100    30    40    10\n"
        "@N IRRIGATION  IMDEP ITHRL ITHRU IROFF IMETH IRAMT IREFF\n"
        " 1 IR             30    50   100 GS000 IR001    10     1\n"
        "@N NITROGEN    NMDEP NMTHR NAMNT NCODE NAOFF\n"
        " 1 NI             30    50    25 FE001 GS000\n"
        "@N RESIDUES    RIPCN RTIME RIDEP\n"
        " 1 RE            100     1    20\n"
        "@N HARVEST     HFRST HLAST HPCNP HPCNR\n"
        f" 1 HA              0 {end}   100     0\n"
    )
    return text


def render_weather(request: SimulationRequest) -> str:
    records = sorted(request.environment.weather, key=lambda record: record.date)
    temperatures = [
        (float(row.values["T2M_MAX"]) + float(row.values["T2M_MIN"])) / 2
        for row in records
    ]
    tav = sum(temperatures) / len(temperatures)
    amp = max(temperatures) - min(temperatures)
    rows = [
        f"{_date_code(row.date)} "
        + " ".join(f"{float(row.values[key]):5.1f}" for key in WEATHER_FIELDS)
        for row in records
    ]
    return "\n".join(
        [
            "*WEATHER DATA : G2F normalized daily weather; POWER source",
            "@ INSI      LAT     LONG  ELEV   TAV   AMP REFHT WNDHT",
            f"  G2FW {request.environment.latitude:8.3f} "
            f"{request.environment.longitude:8.3f} "
            f"{float(request.environment.metadata.get('elevation_m', 0)):5.0f}"
            f" {tav:5.1f} {amp:5.1f}  2.00  3.00",
            "@DATE  SRAD  TMAX  TMIN  RAIN",
            *rows,
            "",
        ]
    )


def parse_summary(
    text: str, planting_date: date, end_date: date | None = None
) -> dict[str, object] | None:
    """Parse DSSAT's column-aligned Summary.OUT without confusing -99 with maturity."""
    lines = text.splitlines()
    header = next((line for line in lines if line.startswith("@   RUNNO")), None)
    if header is None:
        return None
    row = next(
        (line for line in lines if re.match(r"^\s+1\s+1\s+", line)),
        None,
    )
    if row is None:
        return None
    fields = list(re.finditer(r"\S+", header))
    values = {
        field.group(): row[
            fields[index - 1].end() if index else 0 : field.end()
        ].strip()
        for index, field in enumerate(fields)
    }

    def julian(key: str) -> date | None:
        value = values.get(key, "-99")
        if not re.fullmatch(r"\d{7}", value):
            return None
        try:
            year, day = int(value[:4]), int(value[4:])
            parsed = date.fromordinal(date(year, 1, 1).toordinal() + day - 1)
            if parsed.year != year or parsed <= planting_date:
                return None
            return parsed if end_date is None or parsed <= end_date else None
        except (ValueError, OverflowError):
            return None

    def amount(key: str) -> float | None:
        try:
            number = float(values.get(key, "-99"))
        except ValueError:
            return None
        return number if math.isfinite(number) and number >= 0 else None

    flowering = julian("ADAT")
    termination = julian("MDAT")  # May denote crop failure rather than maturity.
    maturity = termination
    crop_status = amount("CRST")
    if "CRST" in values and crop_status != 1:
        maturity = None
    if crop_status in (12, 13) or (
        termination and flowering and flowering > termination
    ):
        flowering = None
    yield_kg = amount("HWAM")
    biomass_kg = amount("CWAM")
    return {
        "crop_status_code": int(crop_status) if crop_status is not None else None,
        "flowering_date": flowering.isoformat() if flowering else None,
        "flowering_proxy_dap": (
            (flowering - planting_date).days if flowering else None
        ),
        "maturity_date": maturity.isoformat() if maturity else None,
        "dry_yield_mg_ha": yield_kg / 1000
        if maturity and yield_kg is not None
        else None,
        "biomass_mg_ha": biomass_kg / 1000 if biomass_kg is not None else None,
    }


def render_experiment(template: str, request: SimulationRequest) -> str:
    """Retain official experiment layout with explicitly fixed reference assumptions."""
    if _cultivar_mode(request):
        return _render_native_experiment(request)
    sowing = request.management.planting_date
    start = request.start_date
    end = request.end_date
    if not start <= sowing <= end:
        raise DSSATValidationError("planting date must be within simulation interval")
    planted = _date_code(sowing)
    simulation_start = _date_code(start)
    harvest_end = _date_code(end)
    population = request.management.population_plants_m2 or 7.5
    if not 1 <= population <= 20:
        raise DSSATValidationError("plant density must be in [1, 20] plants/m2")

    # Replace whole sections so no Gainesville weather, soil, planting or
    # irrigation events silently leak into G2F simulations.
    replacements = {
        "*FIELDS": (
            "*FIELDS\n"
            "@L ID_FIELD WSTA....  FLSA  FLOB  FLDT  FLDD  FLDS  FLST"
            " SLTX  SLDP  ID_SOIL    FLNAME\n"
            f" 1 G2F00001 G2FW       -99     0 DR000     0     0 00000"
            f" -99    210  {SOIL_ID} Reference\n"
            "@L ...........XCRD ...........YCRD .....ELEV .............AREA"
            " .SLEN .FLWR .SLAS FLHST FHDUR\n"
            f" 1 {request.environment.latitude:15.4f} "
            f"{request.environment.longitude:15.4f} "
            f"{float(request.environment.metadata.get('elevation_m', 0)):9.0f}"
            "                 0     0     0     0   -99   -99\n\n"
        ),
        "*INITIAL CONDITIONS": (
            "*INITIAL CONDITIONS\n"
            "@C   PCR ICDAT  ICRT  ICND  ICRN  ICRE  ICWD"
            " ICRES ICREN ICREP ICRIP ICRID ICNAME\n"
            f" 1    MZ {simulation_start}   100     0     1     1"
            "   -99     0     0     0     0     0 -99\n"
            "@C  ICBL  SH2O  SNH4  SNO3\n"
            + "".join(
                f" 1 {depth:5d}   -99   1.0   5.0\n"
                for depth in (5, 15, 30, 45, 60, 90, 120, 150, 180, 210)
            )
            + "\n"
        ),
        "*PLANTING DETAILS": (
            "*PLANTING DETAILS\n"
            "@P PDATE EDATE  PPOP  PPOE  PLME  PLDS  PLRS  PLRD  PLDP"
            "  PLWT  PAGE  PENV  PLPH  SPRL                        PLNAME\n"
            f" 1 {planted}   -99 {population:5.1f} {population:5.1f}"
            "     S     R    75     0     5   -99   -99   -99"
            "   -99     0                        -99\n\n"
        ),
        "*IRRIGATION AND WATER MANAGEMENT": (
            "*IRRIGATION AND WATER MANAGEMENT\n"
            "@I  EFIR  IDEP  ITHR  IEPT  IOFF  IAME  IAMT IRNAME\n"
            " 1     1   -99   -99   -99   -99   -99   -99 -99\n\n"
        ),
        "*FERTILIZERS (INORGANIC)": (
            "*FERTILIZERS (INORGANIC)\n"
            "@F FDATE  FMCD  FACD  FDEP  FAMN  FAMP  FAMK  FAMC  FAMO  FOCD FERNAME\n"
            f" 1 {planted} FE001 AP001    10   120"
            "     0     0     0     0   -99 -99\n\n"
        ),
    }
    sections = re.split(r"(?=^\*[A-Z][^\n]*\n)", template, flags=re.MULTILINE)
    result = []
    for section in sections:
        key = next((name for name in replacements if section.startswith(name)), None)
        result.append(replacements[key] if key else section)
    text = "".join(result)
    text = re.sub(
        r"^ 1 MZ IB0035 .*$", " 1 MZ IB0035 Reference maize", text, flags=re.MULTILINE
    )
    # Soil/water remains active; irrigation is off; fixed nitrogen input is explicit.
    text = text.replace(
        " 1 MA              R     R     R     N     M",
        " 1 MA              R     N     R     N     M",
    )
    text = re.sub(
        r"(?m)^ 1 GE.*$",
        lambda match: match.group().replace("82056", simulation_start),
        text,
    )
    text = re.sub(
        r"(?m)^ 1 HA.*$",
        lambda match: re.sub(r"\b83057\b", harvest_end, match.group()),
        text,
    )
    text = re.sub(
        r"(?m)^ 1 PL.*$",
        lambda match: match.group().replace("82050", planted).replace("82064", planted),
        text,
    )
    # Set all treatment references to a single fully defined reference treatment.
    text = re.sub(r"(?m)^ [2-6] [1-6] 0 0 .*\n", "", text)
    text = text.replace(
        " 1 1 0 0 RAINFED LOW NITROGEN       1  1  0  1  1  1  1",
        " 1 1 0 0 G2F REFERENCE RAINFED      1  1  0  1  1  1  1",
    )
    return text.rstrip("\x1a\n") + "\n"


def render_cultivar(template: str, p1: float, g2: float) -> str:
    original = next(
        line for line in template.splitlines() if line.startswith("IB0035 ")
    )
    pattern = r"(?<=IB0001)\s+259\.0\s+1\.193\s+947\.1\s+924\.3"
    if re.search(pattern, original) is None:
        raise DSSATValidationError("official IB0035 cultivar format changed")
    updated = re.sub(
        pattern,
        f" {p1:5.1f} 1.193 947.1 {g2:5.1f}",
        original,
        count=1,
    )
    return template.replace(original, updated, 1)


class DSSATAdapter:
    name = "dssat"
    version = VERSION
    capabilities = ModelCapabilities(
        display_name="DSSAT",
        phenology_parameter=CalibrationParameter(
            "P1", P1_DEFAULT, (150.0, 350.0, 50.0), 10.0
        ),
        yield_parameter=CalibrationParameter(
            "G2", G2_DEFAULT, (700.0, 950.0, 50.0), 10.0
        ),
        supported_folds=(FoldStrategy.HELD_YEAR,),
        weather_strategy=WeatherStrategy.G2F,
        scan_request_strategy=ScanRequestStrategy.SLICE_WEATHER_HORIZON,
        report_notes=(
            "- 开花日期采用 DSSAT CERES-Maize 输出的 ADAT 开花日，"
            "与 G2F 花粉日期作代理比较。",
            "- 土壤 IB00000007、IB0035 品种、120 kg N/ha 播期施用和雨养"
            "均为固定参考情景，并非实测管理。",
            "- 全局校准仅拟合 P1 与 G2（2022）；2023 保留用于留年评估。",
        ),
    )

    def __init__(self, installation: Path | None = None) -> None:
        self.installation = (
            installation
            or (Path(__file__).resolve().parents[4] / ".tools/dssat/4.8.6.2")
        ).resolve()
        self.executable = self.installation / "dscsm048"

    @cached_property
    def source_fingerprints(self) -> dict[str, str]:
        paths = {
            "adapter_source_sha256": Path(__file__),
            "dssat_executable_sha256": self.executable,
            "dssat_experiment_template_sha256": self.installation
            / "Maize/UFGA8201.MZX",
            "dssat_cultivar_source_sha256": self.installation / "Genotype/MZCER048.CUL",
            "dssat_ecotype_source_sha256": self.installation / "Genotype/MZCER048.ECO",
            "dssat_species_source_sha256": self.installation / "Genotype/MZCER048.SPE",
            "dssat_soil_source_sha256": self.installation / "Soil/SOIL.SOL",
            "dssat_profile_source_sha256": self.installation / "DSSATPRO.L48",
        }
        return {
            key: hashlib.sha256(path.read_bytes()).hexdigest()
            for key, path in paths.items()
        }

    def validate(self, request: SimulationRequest) -> None:
        for relative in (
            "dscsm048",
            "DSSATPRO.L48",
            "Maize/UFGA8201.MZX",
            "Genotype/MZCER048.CUL",
            "Genotype/MZCER048.ECO",
            "Genotype/MZCER048.SPE",
            "Soil/SOIL.SOL",
        ):
            if not (self.installation / relative).is_file():
                raise DSSATValidationError(f"DSSAT file is missing: {relative}")
        if request.environment.environment_id != request.management.environment_id:
            raise DSSATValidationError("management environment does not match weather")
        if request.model_parameters.get("model_version", VERSION) != VERSION:
            raise DSSATValidationError(f"requires DSSAT {VERSION}")
        if _cultivar_mode(request):
            render_native_cultivar(
                (self.installation / "Genotype/MZCER048.CUL").read_text(
                    encoding="latin1"
                ),
                request,
            )
            _render_native_experiment(request)
        else:
            if str(request.model_parameters.get("cultivar", CULTIVAR)) != CULTIVAR:
                raise DSSATValidationError(
                    f"supported reference cultivar is {CULTIVAR}"
                )
            for name, default, lo, hi in (
                ("P1", P1_DEFAULT, 50, 450),
                ("G2", G2_DEFAULT, 200, 990),
            ):
                value = float(request.model_parameters.get(name, default))
                if not math.isfinite(value) or not lo <= value <= hi:
                    raise DSSATValidationError(f"{name} must be in [{lo}, {hi}]")
        dates = [row.date for row in request.environment.weather]
        expected = [
            date.fromordinal(request.start_date.toordinal() + i)
            for i in range((request.end_date - request.start_date).days + 1)
        ]
        if dates != expected:
            raise DSSATValidationError(
                "exactly one weather row required per calendar day"
            )
        if not 2000 <= request.start_date.year <= 2048 or request.end_date.year > 2048:
            raise DSSATValidationError(
                "supported DSSAT weather year range is 2000-2048"
            )
        for row in request.environment.weather:
            try:
                solar, high, low, rain = (
                    float(row.values[key]) for key in WEATHER_FIELDS
                )
            except (KeyError, TypeError, ValueError) as exc:
                raise DSSATValidationError("required daily weather is missing") from exc
            if not all(map(math.isfinite, (solar, high, low, rain))) or (
                solar < 0 or rain < 0 or low > high
            ):
                raise DSSATValidationError("daily weather is physically invalid")
        if request.output_dir is None:
            raise DSSATValidationError("DSSAT requests require output_dir")
        output = Path(request.output_dir)
        if output.resolve().is_relative_to(self.installation) or (
            output / "dssat"
        ).resolve().is_relative_to(self.installation):
            raise DSSATValidationError(
                "DSSAT installation is read-only, not an output_dir"
            )

    def cache_key(self, request: SimulationRequest) -> str:
        self.validate(request)
        payload = {
            "request": request.content_hash(),
            "sources": self.source_fingerprints,
            "reference_soil": _soil_id(request) if _cultivar_mode(request) else SOIL_ID,
            "reference_cultivar": (
                request.model_parameters.get("cultivar", CULTIVAR)
                if _cultivar_mode(request)
                else CULTIVAR
            ),
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def run(self, request: SimulationRequest) -> SimulationResult:
        key = self.cache_key(request)
        directory = Path(request.output_dir) / "dssat" / key
        if directory.resolve().is_relative_to(self.installation):
            raise DSSATValidationError("DSSAT installation is read-only, not a run_dir")
        directory.mkdir(parents=True, exist_ok=True)
        saved = directory / "result.json"
        if saved.is_file():
            payload = json.loads(saved.read_text(encoding="utf-8"))
            return SimulationResult(
                request_id=request.request_id,
                adapter_name=self.name,
                adapter_version=self.version,
                status=RunStatus(payload["status"]),
                summary=payload["summary"],
                failure_reason=payload["failure_reason"],
                diagnostics={"cache_key": key},
                artifacts={"run_dir": directory},
            )
        source = self.installation
        native = _cultivar_mode(request)
        cultivar_template = (source / "Genotype/MZCER048.CUL").read_text(
            encoding="latin1"
        )
        inputs = {
            "planting_date": request.management.planting_date.isoformat(),
            "reference_soil_id": SOIL_ID,
            "reference_cultivar_id": CULTIVAR,
            "P1": float(request.model_parameters.get("P1", P1_DEFAULT)),
            "G2": float(request.model_parameters.get("G2", G2_DEFAULT)),
        }
        if native:
            row = _prior_row(cultivar_template, request)
            parameters = _native_coefficients(cultivar_template, request)
            management = _native_management(request)
            request_payload = request.to_json_dict()
            prior = {
                "id": row[:6],
                "name": row[7:23].strip(),
                "ecotype": row[30:36],
                "source": "Genotype/MZCER048.CUL",
                "source_row": row,
                "source_sha256": self.source_fingerprints[
                    "dssat_cultivar_source_sha256"
                ],
                "role": "parameter_prior_not_identity",
            }
            assumptions = {
                "soil_surface": {
                    "SALB": 0.13,
                    "SLU1": 6,
                    "SLDR": 0.5,
                    "SLRO": 73,
                    "SLNF": 1,
                    "SLPF": 1,
                },
                "soil_root_distribution": "1 for bottom<=15cm else exp(-.02*center_cm)",
                "initial_n_distribution": (
                    "uniform concentration by profile dry soil mass"
                ),
                "fertilizer_material_placement": "FE001/AP001, 10 cm; no P/K/C/other",
                "fertilizer_schedule": (
                    "supplied"
                    if "fertilizer_events" in request.management.metadata
                    else "not supplied; assumed no fertilizer, NOT confirmed zero"
                ),
                "sowing_depth_m": request.management.metadata.get(
                    "sowing_depth_m", 0.05
                ),
                "sowing_depth_assumed": "sowing_depth_m"
                not in request.management.metadata,
                "row_spacing_m": request.management.metadata.get("row_spacing_m", 0.75),
                "row_spacing_assumed": "row_spacing_m"
                not in request.management.metadata,
                "irrigation_assumption": request.management.irrigation_assumption,
            }
            inputs = {
                **inputs,
                **parameters,
                "input_mode": "cultivar_calibration",
                "reference_soil_id": _soil_id(request),
                "soil_id": _soil_id(request),
                "reference_cultivar_id": row[:6],
                "cultivar_id": request.management.cultivar_id,
                "cultivar_evidence": request_payload["management"]["metadata"].get(
                    "cultivar_evidence", {}
                ),
                "native_cultivar_prior": prior,
                "input_assumptions": assumptions,
                "population_plants_m2": management["population"],
                "population_verified": management["population_verified"],
                "population_assumption": management["population_assumption"],
                "irrigation_mm": sum(amount for _, amount in management["irrigation"]),
                "fertilizer_nitrogen_kg_ha": sum(
                    amount for _, amount in management["fertilizer"]
                ),
                "flowering_event": (
                    "DSSAT CERES-Maize ADAT: 75% silking; "
                    "proxy for observed silk date, not an independent "
                    "pollen/anthesis event"
                ),
            }
            (directory / "input_manifest.json").write_text(
                json.dumps(
                    {
                        "request": request_payload,
                        "sources": self.source_fingerprints,
                        "native_cultivar_prior": prior,
                        "input_assumptions": assumptions,
                    },
                    indent=2,
                    allow_nan=False,
                )
                + "\n",
                encoding="utf-8",
            )
            (directory / "SOIL.SOL").write_text(render_soil(request), encoding="ascii")
        (directory / "G2F.WTH").write_text(render_weather(request), encoding="ascii")
        for year in range(request.start_date.year, request.end_date.year + 1):
            link = directory / f"G2FW{year % 100:02d}01.WTH"
            if not link.is_symlink() and not link.exists():
                link.symlink_to("G2F.WTH")
        (directory / "G2F.MZX").write_text(
            render_experiment(
                (source / "Maize/UFGA8201.MZX").read_text(encoding="latin1"), request
            ),
            encoding="ascii",
        )
        (directory / "MZCER048.CUL").write_text(
            render_native_cultivar(cultivar_template, request)
            if native
            else render_cultivar(
                cultivar_template,
                float(request.model_parameters.get("P1", P1_DEFAULT)),
                float(request.model_parameters.get("G2", G2_DEFAULT)),
            ),
            encoding="latin1",
        )
        for target, origin in (
            ("MZCER048.ECO", "Genotype/MZCER048.ECO"),
            ("MZCER048.SPE", "Genotype/MZCER048.SPE"),
            ("SOIL.SOL", "Soil/SOIL.SOL"),
        ):
            if native and target == "SOIL.SOL":
                continue
            link = directory / target
            if not link.is_symlink() and not link.exists():
                link.symlink_to(source / origin)
        # DSSAT searches CWD first. The local profile retains the short
        # installation paths required by legacy fixed-width Fortran reads.
        (directory / "DSSATPRO.L48").write_bytes((source / "DSSATPRO.L48").read_bytes())
        try:
            process = subprocess.run(
                [str(self.executable), "C", "G2F.MZX", "1"],
                cwd=directory,
                capture_output=True,
                text=True,
                timeout=120,
                input="\n",
            )
            (directory / "stdout.log").write_text(
                process.stdout + process.stderr, encoding="utf-8"
            )
            error = directory / "ERROR.OUT"
            failure = (
                error.read_text(encoding="latin1", errors="replace")
                if error.exists()
                else None
            )
            summary_path = directory / "Summary.OUT"
            parsed = (
                parse_summary(
                    summary_path.read_text(encoding="latin1"),
                    request.management.planting_date,
                    end_date=request.end_date,
                )
                if summary_path.exists() and failure is None
                else None
            )
            if failure or process.returncode or parsed is None:
                status = RunStatus.EXECUTION_FAILED
                reason = (
                    failure or process.stderr or process.stdout or "Summary.OUT missing"
                )[-1200:]
            elif parsed["crop_status_code"] in (12, 13):
                status = RunStatus.NOT_GERMINATED
                reason = f"DSSAT crop failure status {parsed['crop_status_code']}"
            elif parsed["crop_status_code"] in (32, 33):
                status = RunStatus.CROP_DIED
                reason = f"DSSAT crop failure status {parsed['crop_status_code']}"
            elif parsed["maturity_date"] is None or (
                native and parsed["crop_status_code"] != 1
            ):
                status = RunStatus.NOT_MATURED
                reason = "DSSAT reported no physiological maturity"
            else:
                status = RunStatus.MATURED
                reason = None
        except (OSError, subprocess.TimeoutExpired) as exc:
            parsed = None
            status = RunStatus.EXECUTION_FAILED
            reason = str(exc)
        result = {
            "status": status.value,
            "failure_reason": reason,
            "summary": {
                **inputs,
                **(
                    parsed
                    or {
                        "flowering_date": None,
                        "flowering_proxy_dap": None,
                        "maturity_date": None,
                        "dry_yield_mg_ha": None,
                        "biomass_mg_ha": None,
                    }
                ),
            },
        }
        saved.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        return SimulationResult(
            request_id=request.request_id,
            adapter_name=self.name,
            adapter_version=self.version,
            status=status,
            summary=result["summary"],
            failure_reason=reason,
            diagnostics={"cache_key": key},
            artifacts={"run_dir": directory},
        )
