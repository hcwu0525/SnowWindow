"""Package the frozen PHG29/PHG47 scan without running crop models."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from phg29_distribution.fields import PARAMETERS, describe

REPO = Path(__file__).resolve().parents[1]
EXPERIMENTS = REPO / "outputs/experiments"
SCAN = EXPERIMENTS / "g2f_phg29_stage1_scan_20261113_v2"
CALIBRATION = EXPERIMENTS / "g2f_cultivar_calibration_20261112_final_v1"
TEMPLATES = Path(__file__).resolve().parent / "phg29_distribution"
CULTIVAR = "PHG29/PHG47"
IDENTITY = "PHG29_PHG47_1a8a437e"
DEFAULT_ID = "g2f_phg29_scan_distribution_20261114_v2"
CORE = [
    "cultivar_id",
    "model",
    "model_version",
    "environment_id",
    "site_id",
    "year",
    "planting_date",
    "flowering_date",
    "maturity_date",
    "dry_yield_mg_ha",
    "native_yield_mg_ha",
    "pollen_dap",
    "silk_dap",
    "status",
    "failure_reason",
    "natural_maturity",
    "forced_maturity",
    "cross_year_extended",
    "continuation_recovered",
    "first_pass_status",
    "horizon_limited",
    "thermal_time_initialization_limited",
    "irrigation_assumption",
    "soil_input_tier",
    "approximate_weather_days_used",
    "simulation_start_date",
    "simulation_end_date",
    "days_available_after_sowing",
    "request_id",
    "request_fingerprint",
    "namespace",
]


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        checksum = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def verify_seal(document: dict[str, Any], expected: str) -> None:
    body = {key: value for key, value in document.items() if key != "sha256"}
    actual = hashlib.sha256(
        json.dumps(body, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()
    assert actual == document["sha256"] == expected, "Frozen manifest seal mismatch"


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def csv_value(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        value = value.tolist()
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return value


def csv_table(frame: pd.DataFrame, path: Path) -> None:
    result = frame.copy()
    for name in result.select_dtypes("object").columns:
        result[name] = result[name].map(csv_value)
    result.to_csv(path, index=False, encoding="utf-8", lineterminator="\n")


def table(frame: pd.DataFrame, path: Path) -> None:
    frame.to_parquet(path.with_suffix(".parquet"), index=False)
    csv_table(frame, path.with_suffix(".csv"))


def markdown_table(frame: pd.DataFrame) -> str:
    def cell(value: Any) -> str:
        if value is None:
            return ""
        return str(value).replace("|", "\\|").replace("\n", " ")

    lines = ["| " + " | ".join(map(cell, frame.columns)) + " |"]
    lines.append("| " + " | ".join("---" for _ in frame.columns) + " |")
    lines += [
        "| " + " | ".join(map(cell, row)) + " |"
        for row in frame.itertuples(index=False, name=None)
    ]
    return "\n".join(lines)


def validity(field: str) -> str:
    if field == "dry_yield_mg_ha":
        return (
            "status=matured 且 natural_maturity=True、"
            "forced_maturity=False、值非空；保留零"
        )
    if field in {"pollen_dap", "silk_dap"}:
        return "相应模型列非空；检查事件与终止时间；不要求较早物候事件之后一定成熟"
    if field in {
        "flowering_date",
        "flowering_date_dt",
        "maturity_date",
        "maturity_date_dt",
    }:
        return (
            "日期非空不是有效性证明；结合对应 DAP、status、natural_maturity 与模拟窗口"
        )
    if field == "native_yield_mg_ha" or field == "native_summary_dry_yield_mg_ha":
        return "未按自然成熟筛选；诊断使用，不能替代 dry_yield_mg_ha"
    if field.startswith("native_summary_"):
        return "仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效"
    if field in {"first_pass_record", "continuation_request_fingerprint"}:
        return "仅跨年重跑记录适用"
    return "身份/输入/运行信息；保留全部状态；缺失不补零"


def field_source(field: str) -> str:
    if field in {"cultivar_id", "environment_id", "year", "site_id"}:
        return "G2F 身份元数据/派生环境映射"
    if field in {"irrigation_assumption", "soil_input_tier"}:
        return "输入证据分类，可能为假设/先验"
    if field == "planting_date" or field.startswith("simulation_"):
        return "模拟设计/请求"
    key = field.removeprefix("native_summary_")
    if key in PARAMETERS or key.startswith(
        ("input_assumptions.", "native_cultivar_prior.", "derived_canopy_calendar.")
    ):
        return "校准估计/参考先验/耦合参数化或管理假设"
    if field.startswith("native_summary_"):
        return "模型原生摘要展开（含输入与过程诊断）"
    if field.endswith("_dt"):
        return "原日期字段的类型转换"
    if field in {
        "dry_yield_mg_ha",
        "native_yield_mg_ha",
        "pollen_dap",
        "silk_dap",
        "flowering_date",
        "maturity_date",
    }:
        return "仿真输出/模型物候代理"
    return "运行状态、溯源或派生诊断"


def summarize(frame: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    values = frame.assign(
        valid_yield=(
            frame.status.eq("matured")
            & frame.natural_maturity.eq(True)
            & frame.forced_maturity.eq(False)
            & frame.dry_yield_mg_ha.notna()
        ),
        matured_missing_yield=frame.status.eq("matured") & frame.dry_yield_mg_ha.isna(),
    )
    counts = values.groupby(keys, dropna=False).agg(
        records=("status", "size"),
        valid_yield=("valid_yield", "sum"),
        matured_missing_yield=("matured_missing_yield", "sum"),
        cross_year_extended=("cross_year_extended", "sum"),
        continuation_recovered=("continuation_recovered", "sum"),
    )
    statuses = pd.crosstab([values[k] for k in keys], values.status)
    return counts.join(statuses).fillna(0).reset_index()


def build(output: Path) -> None:
    if output.exists():
        raise FileExistsError(
            f"Refusing to overwrite {output}; use a new experiment ID"
        )
    scan_manifest = load(SCAN / "manifest.json")
    input_manifest = load(SCAN / "inputs/manifest.json")
    protocol = load(CALIBRATION / "final_calibration/protocol.json")
    df = pd.read_parquet(SCAN / "scan/results_complete.parquet")
    assert df.shape == (37266, 174)
    assert df.cultivar_id.eq(CULTIVAR).all()
    assert not df.duplicated(["model", "environment_id", "planting_date"]).any()
    assert df.groupby("model").size().to_dict() == dict.fromkeys(
        ["apsim", "aquacrop", "dssat"], 12422
    )
    assert df.status.value_counts().to_dict() == {
        "matured": 33149,
        "crop_died": 4040,
        "not_matured": 65,
        "execution_failed": 12,
    }
    for (_, _, year), group in df.groupby(["model", "environment_id", "year"]):
        expected = pd.date_range(f"{year}-01-01", f"{year}-12-31").strftime("%Y-%m-%d")
        assert set(group.planting_date) == set(expected), "Incomplete calendar grid"
    for filename, expected in input_manifest.items():
        if filename != "sha256":
            assert digest(SCAN / "inputs" / filename) == expected, filename
    for filename, expected in scan_manifest["source_artifact_sha256"].items():
        assert digest(CALIBRATION / filename) == expected, filename
    config_path = REPO / "configs/g2f_cultivar_calibration_20261112_final_v1.yaml"
    assert digest(config_path) == scan_manifest["source_config_sha256"]
    for filename, expected in [
        (
            "manifests/final_calibration_freeze.json",
            scan_manifest["source_freeze_sha256"],
        ),
        ("manifests/cultivar_prepare.json", scan_manifest["source_prepare_sha256"]),
    ]:
        verify_seal(load(CALIBRATION / filename), expected)
    verify_seal(scan_manifest, scan_manifest["sha256"])
    verify_seal(input_manifest, input_manifest["sha256"])

    output.mkdir()
    root = output / "dataset"
    for name in [
        "data",
        "docs",
        "calibration",
        "summaries",
        "examples",
        "provenance/source_code",
    ]:
        (root / name).mkdir(parents=True, exist_ok=True)
    sources: dict[str, dict[str, Any]] = {}

    def source(path: Path, action: str, destination: str = "") -> None:
        relative = str(path.relative_to(REPO))
        item = sources.setdefault(
            relative,
            {
                "source_path": relative,
                "sha256": digest(path),
                "size_bytes": path.stat().st_size,
                "actions": [],
                "destinations": [],
            },
        )
        item["actions"].append(action)
        if destination:
            item["destinations"].append(destination)

    def copy(path: Path, destination: str) -> None:
        shutil.copyfile(path, root / destination)
        source(path, "byte-identical copy", destination)

    def read_table(path: Path) -> pd.DataFrame:
        source(path, "read/derive")
        return pd.read_parquet(path) if path.suffix == ".parquet" else pd.read_csv(path)

    copy(TEMPLATES / "README.md", "README.md")
    for path in sorted(TEMPLATES.glob("*.md")):
        if path.name != "README.md":
            copy(path, "docs/" + path.name)
    for filename in ["verify_package.py", "use_results.py"]:
        copy(TEMPLATES / filename, "examples/" + filename)
    copy(SCAN / "scan/results_complete.parquet", "data/results_complete.parquet")
    csv_table(df[CORE], root / "data/results_core.csv")
    for filename, destination in [
        ("inputs/assumptions.json", "data/assumptions.json"),
        ("inputs/parameters.json", "calibration/frozen_parameters.json"),
        ("manifest.json", "provenance/source_scan_manifest.json"),
        ("completion.json", "provenance/source_completion.json"),
        ("scan/analysis_manifest.json", "provenance/source_analysis_manifest.json"),
        ("inputs/manifest.json", "provenance/source_input_manifest.json"),
        ("actual/replay.csv", "calibration/actual_planting_replay.csv"),
    ]:
        copy(SCAN / filename, destination)
    for filename, destination in [
        ("config.yaml", "provenance/source_calibration_config.yaml"),
        ("final_calibration/protocol.json", "provenance/source_final_protocol.json"),
        ("manifests/cultivar_prepare.json", "provenance/source_prepare_manifest.json"),
        (
            "manifests/final_calibration_freeze.json",
            "provenance/source_freeze_manifest.json",
        ),
        (
            "manifests/final_independent_validation.json",
            "provenance/source_independent_validation_manifest.json",
        ),
    ]:
        copy(CALIBRATION / filename, destination)
    copy(config_path, "provenance/source_original_config.yaml")

    environments = read_table(SCAN / "inputs/environments.parquet")
    units = read_table(SCAN / "inputs/units.parquet")
    obs = read_table(SCAN / "inputs/observations.parquet")
    soil = read_table(SCAN / "inputs/soil.parquet")
    assert units.unit_id.is_unique and obs.observation_id.is_unique
    assert environments.environment_id.is_unique
    assert len(environments) == 34 and len(units) == 35
    site_map = units[["environment_id", "site_id"]].drop_duplicates()
    assert site_map.environment_id.is_unique
    environments = environments.merge(site_map, validate="one_to_one")
    table(environments, root / "data/environments")
    table(units, root / "data/management_units")
    table(obs, root / "data/observations")
    table(soil, root / "data/soil_priors")
    plot_path = CALIBRATION / "normalized/cultivar_plots.parquet"
    preparation = load(CALIBRATION / "manifests/cultivar_prepare.json")
    assert (
        digest(plot_path)
        == preparation["artifact_sha256"]["normalized/cultivar_plots.parquet"]
    )
    source(plot_path, "filter scan units and retain plot provenance")
    plots = pd.read_parquet(
        plot_path, filters=[("unit_id", "in", units.unit_id.tolist())]
    )
    plot_columns = [
        "unit_id",
        "physical_plot_id",
        "environment_id",
        "cultivar_id",
        "source_filename",
        "source_row_number",
        "plot",
        "replicate",
        "block",
        "record_kind",
        "eligible",
        "quality_flags",
        "exclusion_reasons",
        "trait_exclusion_reasons",
        "dry_yield_mg_ha",
        "pollen_dap_days",
        "silk_dap_days",
        "plant_height_m",
        "ear_height_m",
        "stand_count_plants",
    ]
    table(plots[plot_columns], root / "data/observation_plot_provenance")
    scenario = []
    for model, representatives in scan_manifest["representative_units"].items():
        for env, representative in representatives.items():
            eligible = units[
                units.environment_id.eq(env) & units.final_eligible.eq(True)
            ]
            assert representative in set(eligible.unit_id)
            scenario += [
                {
                    "model": model,
                    "environment_id": env,
                    "unit_id": unit,
                    "representative": unit == representative,
                }
                for unit in eligible.unit_id
            ]
    csv_table(pd.DataFrame(scenario), root / "data/scenario_units.csv")
    obs_sources = []
    for item in obs.itertuples():
        for entry in json.loads(item.source_rows_json):
            obs_sources.append(
                {
                    "observation_id": item.observation_id,
                    "unit_id": item.unit_id,
                    "environment_id": item.environment_id,
                    "variable": item.variable,
                    **entry,
                }
            )
    csv_table(pd.DataFrame(obs_sources), root / "data/observation_sources.csv")

    # The final protocol, not a nominal older catalog, supplies the actual bounds.
    parameter_units = {
        p["name"]: p["units"]
        for specs in protocol["priors_and_bounds"].values()
        for p in specs
    }
    source(CALIBRATION / "final_calibration/protocol.json", "actual bounds and units")
    schema = pq.read_schema(SCAN / "scan/results_complete.parquet")
    dictionary, coverage = [], []
    for arrow_field in schema:
        name = arrow_field.name
        description, unit = describe(name, parameter_units)
        counts = {}
        for model, g in df.groupby("model"):
            counts[model] = int(g[name].notna().sum())
            record = {
                "model": model,
                "field": name,
                "records": len(g),
                "non_null": counts[model],
            }
            for status, s in g.groupby("status"):
                record["non_null_" + status] = int(s[name].notna().sum())
            coverage.append(record)
        dictionary.append(
            {
                "field": name,
                "description": description,
                "type": str(arrow_field.type),
                "unit": unit,
                "source_kind": field_source(name),
                "models_with_values": ",".join(m for m, n in counts.items() if n),
                "non_null_total": sum(counts.values()),
                **{"non_null_" + m: n for m, n in counts.items()},
                "validity": validity(name),
            }
        )
    dictionary_df = pd.DataFrame(dictionary)
    assert set(dictionary_df.field) == set(df.columns) and len(dictionary_df) == 174
    csv_table(dictionary_df, root / "docs/field_dictionary.csv")
    (root / "docs/field_dictionary.md").write_text(
        "# 完整字段字典\n\n非空统计来自全部状态，不是有效样本数量。"
        "models_with_values 只说明本数据有值的模型；三个模型都缺失的列不推断适用性。"
        "布尔/日期列可能以原生浮点或字符串存储，类型一栏保留实际 Parquet 类型。"
        "原生参数单位来自冻结最终协议。\n\n" + markdown_table(dictionary_df) + "\n",
        encoding="utf-8",
    )
    csv_table(pd.DataFrame(coverage).fillna(0), root / "summaries/field_coverage.csv")
    for keys, name in [
        (["model"], "by_model"),
        (["year"], "by_year"),
        (["model", "year"], "by_model_year"),
        (["model", "environment_id"], "by_model_environment"),
    ]:
        csv_table(summarize(df, keys), root / f"summaries/{name}.csv")
    missing = df[df.status.eq("matured") & df.dry_yield_mg_ha.isna()]
    assert len(missing) == 24 and missing.model.eq("apsim").all()
    csv_table(missing[CORE], root / "summaries/matured_missing_yield.csv")
    csv_table(
        df[df.status.eq("execution_failed")][CORE],
        root / "summaries/execution_failures.csv",
    )

    targets, training, selections, bounds = [], [], [], []
    for model in ["apsim", "aquacrop", "dssat"]:
        dest = root / "calibration" / model
        dest.mkdir()
        caldir = CALIBRATION / "final_calibration_parallel" / model / IDENTITY
        result = load(caldir / "result.json")
        target_doc = load(caldir / "targets_and_weights.json")
        t = pd.DataFrame(target_doc["targets"])
        t["model"] = model
        targets.append(t)
        for filename in [
            "result.json",
            "targets_and_weights.json",
            "task.json",
            "metrics.csv",
            "starts.csv",
            "trace.csv",
        ]:
            copy(caldir / filename, f"calibration/{model}/{filename}")
        pred = read_table(caldir / "best_predictions.parquet")
        assert pred.cultivar_id.eq(CULTIVAR).all()
        training.append(pred)
        selection = {
            "model": model,
            "selected_status": result["selected_status"],
            "selection_reason": result["selection_reason"],
            "target_records": len(t),
            "target_environments": t.environment_id.nunique(),
            "target_sites": t.site_id.nunique(),
            "target_years": ",".join(str(y) for y in sorted(t.year.unique())),
            "yield_targets": int(t.variable.eq("dry_yield_mg_ha").sum()),
            "pollen_targets": int(t.variable.eq("pollen_dap").sum()),
            "silk_targets": int(t.variable.eq("silk_dap").sum()),
            "requests": result["evaluation_requests"],
            "budget_exhausted": result["budget_exhausted"],
            "converged": result["converged"],
        }
        selections.append(selection)
        for p in protocol["priors_and_bounds"][model]:
            bounds.append(
                {
                    "model": model,
                    "parameter": p["name"],
                    "unit": p["units"],
                    "active_final_search": p["name"]
                    in protocol["active_parameters"][model],
                    "lower": p["lower"],
                    "upper": p["upper"],
                    "selected": result["parameters"].get(p["name"]),
                    "effective_native": result["effective_native_parameters"].get(
                        p["name"]
                    ),
                    "role": p["role"],
                    "source": p["source"],
                    "bounds_rationale": p["bounds_rationale"],
                }
            )
        assert result["parameters"] == load(SCAN / "inputs/parameters.json")[model]
    table(pd.concat(targets, ignore_index=True), root / "calibration/training_targets")
    table(
        pd.concat(training, ignore_index=True),
        root / "calibration/training_predictions",
    )
    csv_table(pd.DataFrame(selections), root / "calibration/parameter_selection.csv")
    csv_table(pd.DataFrame(bounds), root / "calibration/parameter_bounds.csv")
    train_metrics = pd.concat(
        [
            pd.read_csv(root / f"calibration/{m}/metrics.csv")
            for m in ["apsim", "aquacrop", "dssat"]
        ],
        ignore_index=True,
    )
    csv_table(train_metrics, root / "calibration/training_metrics.csv")
    independent = read_table(CALIBRATION / "validation/predictions.parquet")
    independent = independent[independent.cultivar_id.eq(CULTIVAR)].copy()
    table(independent, root / "calibration/independent_predictions")
    metrics = read_table(CALIBRATION / "validation/metrics.csv")
    metrics = metrics[metrics.cultivar_id.eq(CULTIVAR)]
    csv_table(metrics, root / "calibration/independent_metrics.csv")
    differences = read_table(CALIBRATION / "validation/paired_differences.csv")
    csv_table(
        differences[differences.cultivar_id.eq(CULTIVAR)],
        root / "calibration/independent_paired_differences.csv",
    )
    excluded = read_table(CALIBRATION / "validation/excluded_units.csv")
    table(
        excluded[excluded.cultivar_id.eq(CULTIVAR)],
        root / "calibration/independent_excluded_units",
    )
    all_units = read_table(CALIBRATION / "normalized/cultivar_units.parquet")
    table(all_units[all_units.cultivar_id.eq(CULTIVAR)], root / "calibration/units")
    selected_metrics = metrics[
        metrics.scheme.eq("final_selected") & metrics.stratum.eq("overall")
    ]
    (root / "docs/calibration_overview.md").write_text(
        "# 校准数据、流程和验证\n\n"
        "仅整理 PHG29/PHG47。参数在打开独立验证前冻结，验证后不回调参数。"
        "最终训练从已封存的前轮 96 请求校准结果开始；最终轮筛选 32 个候选，"
        "包含参考/前轮参数、坐标 ±10% 范围探针与 Latin Hypercube，"
        "最多三个起点，再进行有界 Powell 搜索。随机种子 20261112。"
        "模型请求上限 AquaCrop=240、APSIM=640、DSSAT=400；缓存命中也计数。\n\n"
        "目标是按性状尺度标准化、按权重平方根缩放的残差平方和："
        "`sum_i [sqrt(w_trait) * (pred_i - obs_i) / scale_trait]^2`。"
        "每个固定主目标必须有有效事件和预测；任一缺失或失败则该候选损失为无穷。"
        "尺度来自目标文档记录的重复观测均值合并方差，具体数值、公式、来源行"
        "见各模型 targets_and_weights.json，不能比较不同模型的裸损失大小。\n\n"
        "替换前轮参数须总损失至少改善 1%，且物候、产量各自 RMSE 恶化不超过 2%；"
        "这是预先规定的工程选择规则，不是显著性检验。"
        "AquaCrop 接受本轮结果；APSIM/DSSAT 因 yield_rmse_degradation 保留前轮参数。"
        "converged 与 accepted 不等价，预算耗尽也不自动判定参数不可用。\n\n"
        "## 实际训练目标\n\n" + markdown_table(pd.DataFrame(selections)) + "\n\n"
        "训练实际年份是 2016、2017、2020、2021、2022。"
        "目标是模型/性状特定的固定观测集，而不是所有 G2F 观测。"
        "final_eligible 输入筛选后扫描环境数可少于训练目标环境数；"
        "AquaCrop 的有效原生日历由耦合参数化产生，名义参数并非独立实测常数。"
        "精确范围、活动参数及有效值见 parameter_bounds.csv 和各模型 result.json。\n\n"
        "## 冻结后的独立验证\n\n"
        "本品种实际可用的独立验证来自 2023 年。以下只展示 final_selected / overall，"
        "每模型 15 项产量、13 项相应物候目标；其他方案和分组指标另表保留。\n\n"
        + markdown_table(
            selected_metrics[
                [
                    "model",
                    "variable",
                    "n",
                    "expected_count",
                    "coverage",
                    "mae",
                    "rmse",
                    "bias",
                ]
            ]
        )
        + "\n\n"
        "以上是模型对观测的误差指标。actual_planting_replay.csv 中 169 项 matched=True"
        "是保存预测和重跑预测的一致性（70 项产量、64 项 pollen、35 项 silk），"
        "不是与观测完全相等。训练重放也不是新增独立验证。\n\n"
        "本轮没有执行交叉验证、bootstrap、输入不确定性传播；配置中的计划不能写成"
        "已完成。早期训练 result.json 保留当时 training_only 状态，之后独立验证的"
        "证据来自 independent_* 文件与原冻结/验证清单。"
        "这些估计不是全局最优或已证实的生理辨识结果。\n",
        encoding="utf-8",
    )

    weather = []
    for env, next_env in scan_manifest["next_environment_ids"].items():
        weather += [
            {
                "environment_id": env,
                "weather_environment_id": env,
                "role": "first_year",
                "calendar_year": int(env.rsplit("_", 1)[1]),
            },
            {
                "environment_id": env,
                "weather_environment_id": next_env,
                "role": "continuation",
                "calendar_year": int(next_env.rsplit("_", 1)[1]),
            },
        ]
    csv_table(pd.DataFrame(weather), root / "provenance/weather_calendars.csv")
    raw_names = set(environments.source_filename) | {
        item["source_filename"] for item in obs_sources
    }
    for filename in ["weather.parquet", "weather_next_year.parquet"]:
        w = read_table(SCAN / "inputs" / filename)
        if "source_filename" in w:
            raw_names.update(w.source_filename.dropna())
    for group in targets:
        for value in group.source_rows_json:
            raw_names.update(item["source_filename"] for item in json.loads(value))
    for value in independent.source_rows_json:
        raw_names.update(item["source_filename"] for item in json.loads(value))
    raw_files = []
    for name in sorted(raw_names):
        path = (REPO / "data" / name).resolve()
        assert (REPO / "data").resolve() in path.parents and path.is_file(), name
        raw_files.append(
            {
                "source_filename": name,
                "sha256": digest(path),
                "size_bytes": path.stat().st_size,
                "included": False,
            }
        )
        source(path, "fingerprint only; raw dataset excluded")
    csv_table(pd.DataFrame(raw_files), root / "provenance/raw_g2f_files.csv")

    code_checks = []
    code_paths = [
        "src/snowwindow/cultivar_scan.py",
        "src/snowwindow/cultivar_stage1_scan.py",
        "src/snowwindow/cultivar_scan_weather.py",
        "src/snowwindow/cultivar_parameters.py",
        "src/snowwindow/cultivar_data.py",
        "src/snowwindow/cultivar_optimization.py",
        "src/snowwindow/data/normalization.py",
        "src/snowwindow/models/aquacrop/adapter.py",
        "src/snowwindow/models/apsim/adapter.py",
        "src/snowwindow/models/dssat/adapter.py",
        "scripts/run_cultivar_quick_calibration.py",
    ]
    for relative in code_paths:
        path = REPO / relative
        key = relative.removeprefix("src/snowwindow/")
        expected = scan_manifest["implementation_sha256"].get(str(path))
        if expected is None:
            expected = protocol["code"].get(key)
        if expected is None and relative.startswith("scripts/"):
            expected = protocol.get("runner_sha256")
        actual = digest(path)
        code_checks.append(
            {
                "source_path": relative,
                "expected_sha256": expected,
                "actual_sha256": actual,
                "matches_frozen": actual == expected,
            }
        )
        archive_name = relative.replace("/", "__")
        if actual != expected:
            archive_name = "CURRENT_NOT_FROZEN__" + archive_name
        copy(path, "provenance/source_code/" + archive_name)
    csv_table(
        pd.DataFrame(code_checks), root / "provenance/code_fingerprint_checks.csv"
    )
    copy(
        Path(__file__).resolve(), "provenance/source_code/package_phg29_scan_results.py"
    )
    copy(TEMPLATES / "fields.py", "provenance/source_code/field_descriptions.py")
    csv_table(pd.DataFrame(sources.values()), root / "provenance/source_files.csv")
    assert all(
        digest(REPO / relative) == item["sha256"] for relative, item in sources.items()
    ), "Source changed while packaging"

    files = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        item = {"sha256": digest(path), "size_bytes": path.stat().st_size}
        if path.suffix == ".parquet":
            metadata = pq.ParquetFile(path).metadata
            item.update(rows=metadata.num_rows, columns=metadata.num_columns)
        elif path.suffix == ".csv":
            sample = pd.read_csv(path)
            item.update(rows=len(sample), columns=len(sample.columns))
        files[str(path.relative_to(root))] = item
    valid_yield = df.natural_maturity.eq(True) & df.dry_yield_mg_ha.notna()
    assert int(valid_yield.sum()) == 33125
    manifest = {
        "dataset_id": output.name,
        "package_version": 1,
        "cultivar_id": CULTIVAR,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scan_experiment": SCAN.name,
        "source_calibration_experiment": CALIBRATION.name,
        "source_scan_namespace": scan_manifest["sha256"],
        "record_key": ["model", "environment_id", "planting_date"],
        "records": len(df),
        "columns": len(df.columns),
        "core_columns": CORE,
        "environments": df.environment_id.nunique(),
        "sites": df.site_id.nunique(),
        "management_units": len(units),
        "status_counts": df.status.value_counts().to_dict(),
        "records_by_year": {
            str(k): int(v) for k, v in df.groupby("year").size().items()
        },
        "valid_yield_records": int(valid_yield.sum()),
        "cross_year_extended": int(df.cross_year_extended.sum()),
        "continuation_recovered": int(df.continuation_recovered.sum()),
        "independent_validation_years": sorted(independent.year.unique().tolist()),
        "source_result_sha256": digest(SCAN / "scan/results_complete.parquet"),
        "known_metadata_issue": "Frozen completion.expected_by_year is wrong; "
        "use records_by_year and source_analysis_manifest.",
        "source_code_mismatches": [
            c["source_path"] for c in code_checks if not c["matches_frozen"]
        ],
        "excluded": [
            "weather_event_validation",
            "daily_native_outputs",
            "model_cache",
            "complete_raw_G2F_dataset",
            "model_executables",
        ],
        "files": files,
        "checksum_scope": "manifest files plus manifest.json in SHA256SUMS; "
        "SHA256SUMS excludes itself",
    }
    write_json(root / "manifest.json", manifest)
    checksums = {name: item["sha256"] for name, item in files.items()}
    checksums["manifest.json"] = digest(root / "manifest.json")
    (root / "SHA256SUMS").write_text(
        "".join(f"{value}  {name}\n" for name, value in sorted(checksums.items())),
        encoding="utf-8",
    )
    archive = output / "g2f_phg29_scan_analysis_v1.zip"
    with zipfile.ZipFile(
        archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as z:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                z.write(path, str(path.relative_to(output)))
    with tempfile.TemporaryDirectory(prefix="phg29-distribution-check-") as temporary:
        extracted = Path(temporary)
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            assert set(z.namelist()) == {
                str(p.relative_to(output)) for p in root.rglob("*") if p.is_file()
            }
            z.extractall(extracted)
        unpacked = extracted / "dataset"
        subprocess.run(
            [sys.executable, str(unpacked / "examples/verify_package.py")], check=True
        )
        subprocess.run(
            [
                sys.executable,
                str(unpacked / "examples/use_results.py"),
                "--output-dir",
                str(extracted / "analysis"),
                "--g2f-dir",
                str(REPO / "data"),
            ],
            check=True,
        )
        reread = pd.read_parquet(unpacked / "data/results_complete.parquet")
        pd.testing.assert_frame_equal(df, reread)
        reread_core = pd.read_csv(unpacked / "data/results_core.csv")
        assert list(reread_core.columns) == CORE and len(reread_core) == len(df)
        assert reread_core.status.value_counts().to_dict() == manifest["status_counts"]
        assert reread_core.dry_yield_mg_ha.notna().sum() == 33125
    write_json(
        output / "verification.json",
        {
            "checks_passed": [
                "frozen_input_fingerprints",
                "source_unchanged",
                "exact_grid_counts",
                "no_duplicate_keys",
                "all_174_fields_documented",
                "zip_crc_and_members",
                "extracted_file_hashes_and_sizes",
                "extracted_read_filter_plot_join_example",
                "G2F_trait_fingerprints_and_source_row",
                "parquet_frame_equal",
                "core_csv_counts",
            ],
            "archive": archive.name,
            "sha256": digest(archive),
            "size_bytes": archive.stat().st_size,
            "payload_files": len(files) + 2,
            "source_code_mismatches": manifest["source_code_mismatches"],
        },
    )
    print(f"Created {archive} ({archive.stat().st_size:,} bytes)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-id", default=DEFAULT_ID)
    args = parser.parse_args()
    if not args.experiment_id or Path(args.experiment_id).name != args.experiment_id:
        parser.error("experiment-id must be a single directory name")
    if args.experiment_id in {".", ".."}:
        parser.error("experiment-id cannot be . or ..")
    build(EXPERIMENTS / args.experiment_id)


if __name__ == "__main__":
    main()
