"""Read-only use of frozen cultivar parameters in calendar planting scans."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping
from dataclasses import replace
from datetime import date, timedelta
from pathlib import Path
from typing import Any

import pandas as pd

from snowwindow.cultivar_scan_weather import (
    WEATHER_APPROXIMATION_POLICY,
    approximation_days,
    complete_next_year_weather,
    extend_request,
    met_header_context,
)
from snowwindow.cultivar_workflow import (
    _engine_fingerprints,
    _models,
    _read_json,
    _requests,
    _seal,
    _verify_seal,
    _write_immutable_json,
    _write_json,
    _write_table,
)
from snowwindow.data.sources import sha256_file
from snowwindow.domain import RunStatus, SimulationRequest, SimulationResult

CULTIVAR = "PHG29/PHG47"
ENVIRONMENTS = ("INH1_2022", "INH1_2023")
MODELS = ("aquacrop", "apsim", "dssat")
DEFAULT_EXPERIMENT_ID = "g2f_phg29_inh1_2022_2023_scan_20261112_v3"
SCHEMA = "cultivar_calendar_scan_v1"


def implementation_fingerprints() -> dict[str, str]:
    package = Path(__file__).resolve().parent
    paths = [
        package / name
        for name in (
            "cultivar_scan.py",
            "cultivar_scan_weather.py",
            "cultivar_workflow.py",
            "cultivar_inputs.py",
            "cultivar_pragmatic.py",
            "config.py",
            "domain.py",
        )
    ]
    paths.append(package.parents[1] / "scripts/run_cultivar_window_scan.py")
    paths.append(package.parents[1] / "scripts/run_cultivar_quick_calibration.py")
    return {str(path): sha256_file(path) for path in paths}


def planting_dates(year: int) -> tuple[date, ...]:
    return tuple(
        day.date()
        for day in pd.date_range(
            date(year, 1, 1),
            date(year, 12, 31),
        )
    )


def scan_request(base: SimulationRequest, planting: date) -> SimulationRequest:
    """Change sowing and assumed planting-time N, never initial water or soil."""
    if planting.year != base.environment.year:
        raise ValueError("candidate planting year differs from annual scenario")
    if not base.start_date <= planting <= base.end_date:
        raise ValueError("planting is outside the sourced initial-state interval")
    metadata = dict(base.management.metadata)
    if metadata.get("fertilizer_source") == "assumption":
        metadata["fertilizer_events"] = [
            {**event, "date": planting.isoformat()}
            for event in metadata.get("fertilizer_events", ())
        ]
    parameters = dict(base.model_parameters)
    # An adapter override must not contradict the request's actual sowing.
    if "planting_date" in parameters:
        parameters["planting_date"] = planting.isoformat()
    return replace(
        base,
        request_id=f"{base.request_id}::{planting.isoformat()}",
        management=replace(base.management, planting_date=planting, metadata=metadata),
        model_parameters=parameters,
    )


def physical_signature(request: SimulationRequest) -> str:
    """Ignore trial labels, not physical inputs, when collapsing one scenario."""
    payload = request.to_json_dict()
    for name in ("request_id", "output_dir", "parameter_set_id"):
        payload.pop(name, None)
    payload["management"].pop("management_unit_id", None)
    payload["management"]["metadata"].pop("experiment", None)
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()


def select_scenario_requests(
    requests: Mapping[str, SimulationRequest],
) -> dict[str, SimulationRequest]:
    selected: dict[str, SimulationRequest] = {}
    for unit_id in sorted(requests):
        request = requests[unit_id]
        env = request.environment.environment_id
        if env in selected:
            if physical_signature(request) != physical_signature(selected[env]):
                raise ValueError(
                    f"{env}: trials have different physical inputs; "
                    "cannot silently collapse management"
                )
        else:
            selected[env] = request
    return selected


def _number(value: Any, *, positive: bool = False) -> float | None:
    if value is None:
        return None
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(numeric) or numeric < 0 or (positive and numeric == 0):
        return None
    return numeric


def result_record(
    request: SimulationRequest,
    result: SimulationResult,
    *,
    namespace: str,
) -> dict[str, Any]:
    if result.request_id != request.request_id:
        raise ValueError("native result request identity mismatch")
    forced = any(
        bool(result.diagnostics.get(name, False))
        for name in (
            "forced_maturity",
            "forced_maturity_excluded",
            "forced_maturity_rejected",
        )
    )
    forced |= bool(result.summary.get("forced_maturity", False))
    natural = (
        result.status == RunStatus.MATURED
        and not forced
        and result.summary.get("natural_maturity", True) is not False
    )
    native_yield = _number(result.summary.get("dry_yield_mg_ha"))
    flowering = _number(
        result.summary.get("flowering_proxy_dap"),
        positive=True,
    )
    invalid_event = result.status in {
        RunStatus.EXECUTION_FAILED,
        RunStatus.INVALID_INPUT,
        RunStatus.NOT_GERMINATED,
    }
    if flowering is not None and (
        invalid_event
        or request.management.planting_date + timedelta(days=flowering)
        > request.end_date
    ):
        flowering = None
    return {
        "request_id": request.request_id,
        "request_fingerprint": request.content_hash(),
        "namespace": namespace,
        "model": result.adapter_name,
        "model_version": result.adapter_version,
        "cultivar_id": request.management.cultivar_id,
        "environment_id": request.environment.environment_id,
        "year": request.environment.year,
        "planting_date": request.management.planting_date.isoformat(),
        "status": result.status.value,
        "dry_yield_mg_ha": native_yield if natural else None,
        "native_yield_mg_ha": native_yield,
        "pollen_dap": flowering if result.adapter_name != "dssat" else None,
        "silk_dap": flowering if result.adapter_name == "dssat" else None,
        "flowering_date": result.summary.get(
            "flowering_proxy_date",
            result.summary.get("flowering_date"),
        ),
        "maturity_date": result.summary.get("maturity_date"),
        "natural_maturity": natural,
        "forced_maturity": forced,
        "failure_reason": result.failure_reason,
        "horizon_limited": result.status == RunStatus.NOT_MATURED,
        "thermal_time_initialization_limited": (
            result.status == RunStatus.INSUFFICIENT_THERMAL_TIME
        ),
        "simulation_start_date": request.start_date.isoformat(),
        "simulation_end_date": request.end_date.isoformat(),
        "days_available_after_sowing": (
            request.end_date - request.management.planting_date
        ).days
        + 1,
        "irrigation_assumption": request.management.irrigation_assumption,
        "soil_input_tier": request.environment.metadata.get("soil_input_tier"),
        "native_summary": json.dumps(
            result.to_json_dict()["summary"],
            sort_keys=True,
        ),
        "native_diagnostics": json.dumps(
            result.to_json_dict()["diagnostics"],
            sort_keys=True,
        ),
        "artifacts": json.dumps(result.to_json_dict()["artifacts"], sort_keys=True),
    }


def write_checkpoint(
    path: Path,
    request: SimulationRequest,
    record: Mapping[str, Any],
    *,
    namespace: str,
) -> None:
    _write_json(
        path,
        _seal(
            {
                "namespace": namespace,
                "request_hash": request.content_hash(),
                "record": dict(record),
            }
        ),
    )


def read_checkpoint(
    path: Path,
    request: SimulationRequest,
    *,
    namespace: str,
) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    document = _verify_seal(_read_json(path))
    if (
        document["namespace"] != namespace
        or document["request_hash"] != request.content_hash()
    ):
        raise ValueError("scan checkpoint parameter/input identity changed")
    return document["record"]


def frozen_parameters(
    freeze: Mapping[str, Any],
    model: str,
    cultivar: str = CULTIVAR,
) -> dict[str, float]:
    verified = _verify_seal(freeze)
    matches = [
        row
        for row in verified["combinations"]
        if row["model"] == model and row["cultivar_id"] == cultivar
    ]
    if len(matches) != 1:
        raise ValueError(f"expected one frozen parameter set for {model}/{cultivar}")
    parameters = {key: float(value) for key, value in matches[0]["parameters"].items()}
    if not parameters or not all(math.isfinite(value) for value in parameters.values()):
        raise ValueError("frozen parameters must be finite and nonempty")
    return parameters


def run_native(
    adapter: Any,
    request: SimulationRequest,
    *,
    initial_result: SimulationResult | None = None,
) -> tuple[SimulationResult, int]:
    """Fixed one technical retry; biological failures never become successes."""
    result = None
    for attempt in range(2):
        current = (
            request
            if attempt == 0
            else replace(
                request,
                output_dir=request.output_dir / "technical_retry_1",
            )
        )
        try:
            result = (
                initial_result
                if attempt == 0 and initial_result is not None
                else adapter.run(current)
            )
            if (
                not isinstance(result, SimulationResult)
                or result.request_id != request.request_id
                or result.adapter_name != adapter.name
            ):
                raise TypeError("native adapter returned wrong result identity")
        except Exception as exc:
            result = SimulationResult(
                request.request_id,
                adapter.name,
                adapter.version,
                RunStatus.INVALID_INPUT
                if isinstance(exc, ValueError)
                else RunStatus.EXECUTION_FAILED,
                failure_reason=f"{type(exc).__name__}: {exc}",
            )
        if result.status != RunStatus.EXECUTION_FAILED:
            return result, attempt + 1
    return result, 2


def _input_tables(root: Path) -> dict[str, pd.DataFrame]:
    names = {
        "units": "units",
        "observations": "observations",
        "environments": "environments",
        "soil": "soil",
        "weather": "weather",
    }
    return {
        name: pd.read_parquet(root / "inputs" / f"{filename}.parquet")
        for name, filename in names.items()
    }


def scenario_bases(config: Any, root: Path, model: str) -> dict[str, SimulationRequest]:
    tables = _input_tables(root)
    requests, _ = _requests(config, tables, CULTIVAR, (2022, 2023))
    parameters = _read_json(root / "inputs/parameters.json")[model]
    requests = {
        unit_id: replace(
            request,
            model_parameters={**request.model_parameters, **parameters},
            parameter_set_id="final_selected",
            output_dir=root / "model_cache" / model,
        )
        for unit_id, request in requests.items()
    }
    selected = select_scenario_requests(requests)
    if set(selected) != set(ENVIRONMENTS):
        raise ValueError("both qualified annual cultivar scenarios are required")
    return selected


def prepare_scan(config: Any, root: Path) -> dict[str, Any]:
    """Snapshot only selected inputs, verifying frozen source and engine lineage."""
    source = config.experiment_dir
    if root.resolve() == source.resolve():
        raise ValueError("scan must use a new experiment, not the frozen source")
    freeze_path = source / "manifests/final_calibration_freeze.json"
    freeze = _verify_seal(_read_json(freeze_path))
    preparation = _verify_seal(_read_json(source / "manifests/cultivar_prepare.json"))
    models = {model.name: model for model in _models(config)}
    if set(models) != set(MODELS):
        raise ValueError("scan requires the three frozen native engines")
    for name, model in models.items():
        expected = freeze["models"][name]
        if (
            model.version != expected["version"]
            or _engine_fingerprints(model) != expected["sources"]
        ):
            raise ValueError(f"{name}: engine/adapter differs from frozen calibration")
    files = {
        "units": "cultivar_units",
        "observations": "cultivar_observations",
        "environments": "environments",
        "soil": "soil_layers",
        "weather": "weather",
    }
    tables, source_hashes = {}, {}
    for name, filename in files.items():
        relative = f"normalized/{filename}.parquet"
        path = source / relative
        actual = sha256_file(path)
        if actual != preparation["artifact_sha256"][relative]:
            raise ValueError(f"frozen prepared input changed: {relative}")
        source_hashes[relative] = actual
        filters = [("environment_id", "in", list(ENVIRONMENTS))]
        if name in {"units", "observations"}:
            filters.append(("cultivar_id", "==", CULTIVAR))
        tables[name] = pd.read_parquet(path, filters=filters)
    tables["units"] = (
        tables["units"].loc[tables["units"]["final_eligible"].eq(True)].copy()
    )
    tables["observations"] = (
        tables["observations"]
        .loc[tables["observations"]["unit_id"].isin(tables["units"]["unit_id"])]
        .copy()
    )
    weather_path = source / "normalized/weather.parquet"
    observed_2024 = pd.read_parquet(
        weather_path,
        filters=[("environment_id", "==", "INH1_2024")],
    )
    historical = pd.read_parquet(
        weather_path,
        filters=[
            ("environment_id", "in", [f"INH1_{year}" for year in range(2014, 2024)]),
        ],
    )
    completed_2024 = complete_next_year_weather(observed_2024, historical, year=2024)
    parameters = {name: frozen_parameters(freeze, name) for name in MODELS}
    settings = {"assumptions": dict(config.calibration.options["assumptions"])}
    # Check before writing a new snapshot. Trial labels may differ, input physics not.
    representatives = {}
    for name in MODELS:
        requests, _ = _requests(config, tables, CULTIVAR, (2022, 2023))
        selected = select_scenario_requests(requests)
        if set(selected) != set(ENVIRONMENTS):
            raise ValueError("missing qualified annual scenario")
        representatives[name] = {
            env: request.management.management_unit_id
            for env, request in selected.items()
        }
    expected_frames = []
    for model in MODELS:
        path = (
            source
            / "final_calibration_parallel"
            / model
            / "PHG29_PHG47_1a8a437e"
            / "best_predictions.parquet"
        )
        source_hashes[str(path.relative_to(source))] = sha256_file(path)
        expected_frames.append(
            pd.read_parquet(
                path,
                filters=[
                    ("environment_id", "==", "INH1_2022"),
                ],
            )
        )
    validation_path = source / "validation/predictions.parquet"
    source_hashes["validation/predictions.parquet"] = sha256_file(validation_path)
    expected_frames.append(
        pd.read_parquet(
            validation_path,
            filters=[
                ("environment_id", "==", "INH1_2023"),
                ("cultivar_id", "==", CULTIVAR),
                ("scheme", "==", "final_selected"),
            ],
        )
    )
    expected = pd.concat(expected_frames, ignore_index=True)
    expected = expected.loc[
        expected["variable"].isin(
            ["dry_yield_mg_ha", "pollen_dap", "silk_dap"],
        )
    ].copy()
    body = {
        "schema": SCHEMA,
        "cultivar_id": CULTIVAR,
        "environments": list(ENVIRONMENTS),
        "models": freeze["models"],
        "source_experiment": str(source),
        "source_freeze_sha256": freeze["sha256"],
        "source_prepare_sha256": preparation["sha256"],
        "source_config_sha256": sha256_file(config.source_path),
        "source_artifact_sha256": source_hashes,
        "parameters": parameters,
        "assumptions": settings["assumptions"],
        "representative_units": representatives,
        "trial_observations_kept_separate": True,
        "scan_horizon": "same_year_then_single_crop_cross_year",
        "expected_count": 2190,
        "requested_end": "next sowing anniversary minus one day for unfinished crops",
        "weather_approximation_policy": WEATHER_APPROXIMATION_POLICY,
        "weather_2024_approximated_days": int(completed_2024.approximate_weather.sum()),
        "continuation_method": (
            "same-initial-state longer-window rerun; no second sowing"
        ),
        "fertilizer_timing": "assumed sowing N follows planting; verified dates fixed",
        "technical_retries": 1,
        "scan_code_sha256": sha256_file(Path(__file__)),
        "implementation_sha256": implementation_fingerprints(),
        "limitations": [
            "Counterfactual planting dates have no independent yield observations.",
            "Unfinished crops are extended; full-season cutoff may still limit them.",
            "All soil inputs are unmeasured texture priors.",
            "2023 is an already evaluated and case-selection-used holdout.",
            "2024 approximate weather is not independent observed weather.",
            "No parameter retuning, forced maturity acceptance, or uncertainty refits.",
        ],
    }
    for name, table in tables.items():
        _write_table(root / "inputs" / f"{name}.parquet", table)
    _write_table(root / "inputs/weather_2024_observed.parquet", observed_2024)
    _write_table(root / "inputs/weather_2024_completed.parquet", completed_2024)
    _write_table(root / "inputs/weather_historical.parquet", historical)
    _write_table(
        root / "inputs/weather_2024_approximation.csv",
        completed_2024.loc[completed_2024.approximate_weather],
    )
    _write_table(root / "inputs/expected_actual_predictions.parquet", expected)
    _write_json(root / "inputs/parameters.json", parameters)
    _write_json(root / "inputs/assumptions.json", settings)
    input_hashes = {
        path.name: sha256_file(path)
        for path in (root / "inputs").iterdir()
        if path.is_file()
    }
    _write_immutable_json(root / "inputs/manifest.json", _seal(input_hashes))
    # Publish the root manifest only after the complete input snapshot exists.
    _write_immutable_json(root / "manifest.json", _seal(body))
    return _read_json(root / "manifest.json")


def verify_scan_inputs(config: Any, root: Path, model: Any) -> dict[str, Any]:
    manifest = _verify_seal(_read_json(root / "manifest.json"))
    if sha256_file(Path(__file__)) != manifest["scan_code_sha256"]:
        raise ValueError("scan code changed after snapshot; use a new experiment ID")
    if sha256_file(config.source_path) != manifest["source_config_sha256"]:
        raise ValueError("source configuration changed after scan freeze")
    for filename, expected_hash in manifest["implementation_sha256"].items():
        if sha256_file(Path(filename)) != expected_hash:
            raise ValueError(
                "request/pipeline implementation changed after scan freeze"
            )
    inputs = _verify_seal(_read_json(root / "inputs/manifest.json"))
    for name, expected in inputs.items():
        if name != "sha256" and sha256_file(root / "inputs" / name) != expected:
            raise ValueError(f"scan input snapshot changed: {name}")
    if config.experiment_dir.resolve() != Path(manifest["source_experiment"]).resolve():
        raise ValueError("source experiment changed")
    expected_model = manifest["models"][model.name]
    if (
        model.version != expected_model["version"]
        or _engine_fingerprints(model) != expected_model["sources"]
    ):
        raise ValueError("native engine lineage changed")
    return manifest


def pilot_dates(base: SimulationRequest) -> tuple[date, ...]:
    year = base.environment.year
    return tuple(
        sorted(
            {
                *(date(year, month, 1) for month in (1, 3, 4, 5, 6, 8, 10, 12)),
                date(year, 12, 31),
                base.management.planting_date,
            }
        )
    )


def next_year_weather(root: Path, year: int) -> pd.DataFrame:
    if year == 2024:
        return pd.read_parquet(root / "inputs/weather_2024_completed.parquet")
    return pd.read_parquet(
        root / "inputs/weather.parquet",
        filters=[
            ("environment_id", "==", f"INH1_{year}"),
        ],
    )


def continuation_needed(
    result: SimulationResult,
    *,
    request: SimulationRequest | None = None,
) -> bool:
    # The pinned AquaCrop calendar cannot initialize a same-day sow/harvest
    # interval. Preserve that technical failure; only its longer-window rerun
    # can supply a valid crop result, never relabel the failed first pass.
    traceback = str(result.diagnostics.get("traceback", ""))
    if (
        result.status == RunStatus.EXECUTION_FAILED
        and result.adapter_name == "aquacrop"
        and request is not None
        and request.management.planting_date == request.end_date
        and "read_model_parameters" in traceback
        and "plant_years[0]" in traceback
    ):
        return True
    if result.status in {RunStatus.NOT_MATURED, RunStatus.INSUFFICIENT_THERMAL_TIME}:
        return True
    return result.status == RunStatus.MATURED and (
        result.summary.get("natural_maturity", True) is False
        or any(
            bool(result.diagnostics.get(key, False))
            for key in (
                "forced_maturity",
                "forced_maturity_excluded",
                "forced_maturity_rejected",
            )
        )
        or bool(result.summary.get("forced_maturity", False))
    )


def _record_result(record: Mapping[str, Any]) -> SimulationResult:
    return SimulationResult(
        record["request_id"],
        record["model"],
        record["model_version"],
        RunStatus(record["status"]),
        json.loads(record["native_summary"]),
        {key: Path(value) for key, value in json.loads(record["artifacts"]).items()},
        json.loads(record["native_diagnostics"]),
        record["failure_reason"],
    )


def _native_batch(
    adapter: Any,
    batch: list[SimulationRequest],
) -> dict[str, tuple[SimulationResult, int]]:
    if not batch:
        return {}
    results = None
    with met_header_context(adapter.name):
        if adapter.name == "apsim":
            try:
                results = adapter.run_many(batch)
                if not isinstance(results, Mapping):
                    raise TypeError("native batch must return a request-result mapping")
            except Exception as exc:
                results = {
                    request.request_id: SimulationResult(
                        request.request_id,
                        adapter.name,
                        adapter.version,
                        RunStatus.EXECUTION_FAILED,
                        failure_reason=f"batch: {type(exc).__name__}: {exc}",
                    )
                    for request in batch
                }
        evaluated = {}
        for request in batch:
            initial = results.get(request.request_id) if results is not None else None
            if results is not None and initial is None:
                initial = SimulationResult(
                    request.request_id,
                    adapter.name,
                    adapter.version,
                    RunStatus.EXECUTION_FAILED,
                    failure_reason="batch omitted request",
                )
            evaluated[request.request_id] = run_native(
                adapter,
                request,
                initial_result=initial,
            )
    return evaluated


def scan_worker(config: Any, root: Path, model: str, env: str, phase: str) -> None:
    import time

    adapter = next(item for item in _models(config) if item.name == model)
    manifest = verify_scan_inputs(config, root, adapter)
    base = scenario_bases(config, root, model)[env]
    future_weather = next_year_weather(root, base.environment.year + 1)
    dates = (
        pilot_dates(base) if phase == "pilot" else planting_dates(base.environment.year)
    )
    directory = root / "scan" / model / env
    namespace = manifest["sha256"]
    requests = [scan_request(base, day) for day in dates]
    records, pending = [], []
    for request in requests:
        path = directory / "points" / f"{request.management.planting_date}.json"
        cached = read_checkpoint(path, request, namespace=namespace)
        if cached is None:
            pending.append(request)
        else:
            records.append(cached)

    def checkpoint() -> None:
        frame = (
            pd.DataFrame(records).sort_values("planting_date")
            if records
            else pd.DataFrame()
        )
        _write_table(directory / "results.parquet", frame)
        _write_json(
            directory / "progress.json",
            {
                "model": model,
                "environment_id": env,
                "phase": phase,
                "completed": len(records),
                "expected": len(dates),
                "status": "complete" if len(records) == len(dates) else "running",
            },
        )

    checkpoint()
    chunk_size = 16 if model == "apsim" else 1
    for offset in range(0, len(pending), chunk_size):
        batch = pending[offset : offset + chunk_size]
        started = time.monotonic()
        first_records = {}
        for request in batch:
            cached = read_checkpoint(
                directory / "first_pass" / f"{request.management.planting_date}.json",
                request,
                namespace=namespace,
            )
            if cached is not None:
                first_records[request.request_id] = cached
        evaluated = _native_batch(
            adapter,
            [request for request in batch if request.request_id not in first_records],
        )
        for request in batch:
            if request.request_id not in first_records:
                result, attempts = evaluated[request.request_id]
                record = result_record(request, result, namespace=namespace)
                record["attempts"] = attempts
                write_checkpoint(
                    directory
                    / "first_pass"
                    / f"{request.management.planting_date}.json",
                    request,
                    record,
                    namespace=namespace,
                )
                first_records[request.request_id] = record
        extended = {
            request.request_id: extend_request(request, future_weather)
            for request in batch
            if continuation_needed(
                _record_result(first_records[request.request_id]),
                request=request,
            )
        }
        extended_results = _native_batch(adapter, list(extended.values()))
        for request in batch:
            first = first_records[request.request_id]
            record = dict(first)
            if request.request_id in extended_results:
                current = extended[request.request_id]
                result, attempts = extended_results[request.request_id]
                record = result_record(current, result, namespace=namespace)
                record["continuation_request_fingerprint"] = current.content_hash()
                # The final point identity remains the original annual scan request.
                record["request_fingerprint"] = request.content_hash()
                record["attempts"] = first["attempts"] + attempts
                record["first_pass_record"] = json.dumps(first, sort_keys=True)
                maturity = pd.to_datetime(record["maturity_date"], errors="coerce")
                record["approximate_weather_days_used"] = approximation_days(
                    current,
                    maturity.date() if pd.notna(maturity) else None,
                )
            else:
                record["continuation_request_fingerprint"] = None
                record["first_pass_record"] = None
                record["approximate_weather_days_used"] = 0
            record["first_pass_status"] = first["status"]
            record["first_pass_end_date"] = request.end_date.isoformat()
            record["cross_year_extended"] = request.request_id in extended
            record["continuation_recovered"] = bool(
                record["cross_year_extended"]
                and record["natural_maturity"]
                and record["dry_yield_mg_ha"] is not None
            )
            record["approximate_weather_policy"] = WEATHER_APPROXIMATION_POLICY
            record["elapsed_seconds_batch_per_request"] = (
                time.monotonic() - started
            ) / len(batch)
            write_checkpoint(
                directory / "points" / f"{request.management.planting_date}.json",
                request,
                record,
                namespace=namespace,
            )
            records.append(record)
        checkpoint()
        print(f"{model}/{env}: {len(records)}/{len(dates)}", flush=True)


def _read_scan_manifest(root: Path) -> dict[str, Any]:
    return _verify_seal(_read_json(root / "manifest.json"))


def collect_scan(root: Path, *, config: Any) -> pd.DataFrame:
    """Reconstruct summaries from verified points, never mutable worker tables."""
    manifest = _read_scan_manifest(root)
    records = []
    for model in MODELS:
        for env, base in scenario_bases(config, root, model).items():
            directory = root / "scan" / model / env / "points"
            for path in sorted(directory.glob("*.json")):
                planting = date.fromisoformat(path.stem)
                request = scan_request(base, planting)
                record = read_checkpoint(path, request, namespace=manifest["sha256"])
                if record is None or any(
                    (
                        record["request_id"] != request.request_id,
                        record["request_fingerprint"] != request.content_hash(),
                        record["namespace"] != manifest["sha256"],
                        record["model"] != model,
                        record["cultivar_id"] != CULTIVAR,
                        record["environment_id"] != env,
                        record["planting_date"] != planting.isoformat(),
                        record["year"] != base.environment.year,
                    )
                ):
                    raise ValueError("point record identity changed")
                records.append(record)
    result = pd.DataFrame(records)
    if not result.empty:
        if result.duplicated(["model", "environment_id", "planting_date"]).any():
            raise ValueError("duplicate annual scan point")
        result = result.sort_values(["model", "environment_id", "planting_date"])
        _write_table(root / "scan/results.parquet", result)
        _write_table(
            root / "scan/results.csv",
            result.drop(
                columns=[
                    "native_summary",
                    "native_diagnostics",
                    "artifacts",
                ],
                errors="ignore",
            ),
        )
    return result


def verify_complete_scan(results: pd.DataFrame) -> None:
    """Failures count as records, but duplicates or missing dates never do."""
    keys = ["model", "cultivar_id", "environment_id", "year", "planting_date"]
    expected = {
        (model, CULTIVAR, env, int(env[-4:]), day.isoformat())
        for model in MODELS
        for env in ENVIRONMENTS
        for day in planting_dates(int(env[-4:]))
    }
    if (
        not set(keys).issubset(results)
        or len(results) != len(expected)
        or results.duplicated(keys).any()
        or set(results[keys].itertuples(index=False, name=None)) != expected
    ):
        raise ValueError("scan does not contain the exact frozen full-calendar grid")


def verify_actual_replay(root: Path, results: pd.DataFrame) -> pd.DataFrame:
    expected = pd.read_parquet(root / "inputs/expected_actual_predictions.parquet")
    units = pd.read_parquet(root / "inputs/units.parquet").set_index("unit_id")
    rows = []
    for observation in expected.to_dict("records"):
        original = units.loc[observation["unit_id"]]
        planting = pd.Timestamp(original["planting_date"]).date().isoformat()
        matching = results.loc[
            results["model"].eq(observation["model"])
            & results["environment_id"].eq(observation["environment_id"])
            & results["planting_date"].eq(planting)
        ]
        if len(matching) != 1:
            raise ValueError("actual planting replay is missing or duplicated")
        actual = matching.iloc[0]
        variable = observation["variable"]
        prediction = actual[variable]
        saved = observation["predicted_value"]
        matched = (
            pd.notna(prediction)
            and pd.notna(saved)
            and math.isclose(
                float(prediction), float(saved), abs_tol=1e-6, rel_tol=1e-8
            )
        )
        matched = matched and actual["status"] == observation["status"]
        rows.append(
            {
                "model": observation["model"],
                "environment_id": observation["environment_id"],
                "unit_id": observation["unit_id"],
                "variable": variable,
                "planting_date": planting,
                "saved_prediction": saved,
                "replayed_prediction": prediction,
                "matched": matched,
                "observed_value": observation["observed_value"],
                "absolute_error": abs(
                    float(prediction) - float(observation["observed_value"])
                )
                if pd.notna(prediction)
                else None,
            }
        )
    replay = pd.DataFrame(rows)
    _write_table(root / "actual/replay.csv", replay)
    if replay.empty or not replay["matched"].all():
        raise ValueError(
            "actual-date replay differs from frozen predictions; scan stopped"
        )
    return replay
