"""Pure bounded calibration of long-form observations via a prediction callback.

No engine, filesystem writes, global random state, or implicit external data.
Observations have unique ``observation_id``, ``trait``, ``value``; aliases
``variable`` / ``observed_value`` are accepted. Predictions have IDs,
``predicted_value``, ``status`` and, for yield, explicit ``forced_maturity=False``.
Optional ``event_valid`` / ``natural_maturity`` flags can veto validity.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Callable, Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import least_squares, minimize

from snowwindow.cultivar_parameters import ParameterSpec

Evaluator = Callable[[dict[str, float]], pd.DataFrame]
RecordCallback = Callable[[dict[str, Any]], None]
BIOLOGICAL_STATUSES = {
    "matured",
    "not_matured",
    "crop_died",
    "not_germinated",
    "insufficient_thermal_time",
    "model_limit",
}
YIELD_TRAITS = {"dry_yield_mg_ha", "yield_mg_ha", "yield_kg_ha", "yield"}


def _observations(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy(deep=True)
    for alias, canonical in (("variable", "trait"), ("observed_value", "value")):
        if canonical not in result and alias in result:
            result = result.rename(columns={alias: canonical})
    required = {"observation_id", "trait", "value"}
    if not required <= set(result) or result.empty:
        raise ValueError("nonempty observations require observation_id, trait, value")
    if result[["observation_id", "trait"]].isna().any().any():
        raise ValueError("observation IDs and traits cannot be missing")
    if result["observation_id"].duplicated().any():
        raise ValueError("observation IDs must be unique")
    if not result["observation_id"].map(lambda x: isinstance(x, str)).all():
        raise ValueError("observation IDs must be strings")
    if not result["trait"].map(lambda x: isinstance(x, str) and bool(x)).all():
        raise ValueError("traits must be nonempty strings")
    result["value"] = pd.to_numeric(result["value"], errors="raise")
    if not np.isfinite(result["value"].to_numpy(float, na_value=np.nan)).all():
        raise ValueError("observations must be finite")
    if "sample_weight" in result:
        result["sample_weight"] = pd.to_numeric(result["sample_weight"], errors="raise")
        weights = result["sample_weight"].to_numpy(float, na_value=np.nan)
        if not (np.isfinite(weights) & (weights > 0)).all():
            raise ValueError("sample weights must be finite and positive")
    return result.reset_index(drop=True)


def _scale_estimates(
    observations: pd.DataFrame,
) -> tuple[dict[str, float], dict[str, dict[str, Any]]]:
    frame = _observations(observations)
    scales, details = {}, {}
    for trait, group in frame.groupby("trait", sort=True):
        weights = group.get("sample_weight", pd.Series(1.0, index=group.index))
        variance_column = next(
            (name for name in ("variance", "sample_variance") if name in group), None
        )
        if variance_column is not None and "n_plots" in group:
            variance = pd.to_numeric(group[variance_column], errors="coerce")
            n = pd.to_numeric(group["n_plots"], errors="coerce")
            usable = np.isfinite(variance) & variance.ge(0) & np.isfinite(n) & n.ge(2)
            if usable.any():
                df_weights = (n.loc[usable] - 1) * weights.loc[usable]
                pooled = float(
                    np.average(variance.loc[usable] / n.loc[usable], weights=df_weights)
                )
                if pooled > np.finfo(float).eps:
                    scales[trait] = math.sqrt(pooled)
                    details[trait] = {
                        "method": "pooled_within_unit_variance_of_mean",
                        "formula": "sqrt(sum(w*(n-1)*variance/n)/sum(w*(n-1)))",
                        "variance_column": variance_column,
                        "supporting_units": int(usable.sum()),
                        "weighted_degrees_of_freedom": float(df_weights.sum()),
                        "pooled_variance_of_mean": pooled,
                    }
                    continue
        mean = float(np.average(group["value"], weights=weights))
        sd = float(np.sqrt(np.average((group["value"] - mean) ** 2, weights=weights)))
        scales[trait] = sd if sd > np.finfo(float).eps else 1.0
        details[trait] = {
            "method": (
                "marginal_sd_fallback_not_measurement_error"
                if sd > np.finfo(float).eps
                else "unit_scale_fallback_constant_not_measurement_error"
            ),
            "reason": "no positive usable replicate error variance",
            "supporting_units": 0,
        }
    return scales, details


def training_scales(observations: pd.DataFrame) -> dict[str, float]:
    """Pool within-unit replicate variance of the mean, from training only.

    scale² = sum(w*(n-1)*variance/n) / sum(w*(n-1)), n>=2.
    No replicate errors: explicitly labeled marginal population-SD fallback;
    constant marginal values: unit scale. See ``problem.scale_details``.
    """
    return _scale_estimates(observations)[0]


@dataclass
class Evaluation:
    loss: float
    status: str
    expected_count: int
    valid_count: int
    technical_count: int
    per_trait: dict[str, float]
    residuals: np.ndarray
    predictions: pd.DataFrame
    message: str = ""


def _digest(payload: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode()
    ).hexdigest()


class CalibrationProblem:
    """Frozen targets, scales and weights with a deterministic callback boundary.

    A shared cache is opt-in; its namespace must identify engine/input versions.
    Evaluation keys include targets, scales, weights and all parameters. Callback
    records are emitted for cached evaluations too, enabling external checkpoints.
    No candidate can improve its loss by omitting or invalidating an expected ID.
    """

    def __init__(
        self,
        observations: pd.DataFrame,
        evaluator: Evaluator,
        *,
        scales: Mapping[str, float] | None = None,
        trait_weights: Mapping[str, float] | None = None,
        cache: MutableMapping[str, Evaluation] | None = None,
        cache_namespace: str = "",
        record_callback: RecordCallback | None = None,
    ) -> None:
        self._observations = _observations(observations)
        self.evaluator = evaluator
        self._prespecified_scales = scales is not None
        if scales is None:
            self.scales, self.scale_details = _scale_estimates(self._observations)
        else:
            self.scales = dict(scales)
            self.scale_details = {
                trait: {"method": "prespecified_by_caller"} for trait in scales
            }
        self.trait_weights = dict(trait_weights or {})
        for trait in self._observations["trait"].unique():
            scale = self.scales.get(trait, float("nan"))
            weight = self.trait_weights.get(trait, 1.0)
            if not (math.isfinite(scale) and scale > 0):
                raise ValueError(f"missing/nonpositive/nonfinite scale for {trait}")
            if not (math.isfinite(weight) and weight > 0):
                raise ValueError(f"trait weight must be finite and positive: {trait}")
        self.cache = cache
        self.cache_namespace = cache_namespace
        self.record_callback = record_callback
        self.trace: list[dict[str, Any]] = []
        targets = self._observations[["observation_id", "trait", "value"]].copy()
        targets["sample_weight"] = self._observations.get("sample_weight", 1.0)
        self.target_hash = _digest(
            targets.sort_values("observation_id").to_dict("records")
        )
        self._fingerprint = _digest(
            {
                "schema": 1,
                "targets": self.target_hash,
                "scales": self.scales,
                "weights": self.trait_weights,
                "namespace": cache_namespace,
                "target_order": self._observations["observation_id"].tolist(),
            }
        )

    @property
    def observations(self) -> pd.DataFrame:
        return self._observations.copy(deep=True)

    def _evaluation_key(self, parameters: Mapping[str, float]) -> str:
        return _digest(
            {
                "problem": self._fingerprint,
                "parameters": dict(parameters),
            }
        )

    def seed_cache(
        self, parameters: Mapping[str, float], predictions: pd.DataFrame
    ) -> Evaluation:
        """Warm an in-memory cache without counting a request or tracing it.

        A later ``evaluate`` at the same point is an explicit cached request and
        therefore counts against the caller's budget. This supports verified reuse
        of prior sealed predictions without silently hiding evaluation effort.
        """
        if self.cache is None:
            raise ValueError("cache seeding requires an enabled cache")
        params = {name: float(value) for name, value in parameters.items()}
        if not all(math.isfinite(value) for value in params.values()):
            raise ValueError("parameters must be finite")
        evaluation = self.score_predictions(predictions)
        key = self._evaluation_key(params)
        existing = self.cache.get(key)
        if existing is not None:
            if existing.loss != evaluation.loss or existing.status != evaluation.status:
                raise ValueError("cached evaluation conflicts with seeded predictions")
            return existing
        self.cache[key] = evaluation
        return evaluation

    def score_predictions(self, predictions: pd.DataFrame) -> Evaluation:
        """Validate events before computing any residual; ignore non-target extras."""
        obs = self._observations
        count = len(obs)
        empty = np.full(count, np.nan)

        def failure(
            status: str, valid: int = 0, technical: int = 0, message: str = ""
        ) -> Evaluation:
            return Evaluation(
                math.inf,
                status,
                count,
                valid,
                technical,
                {},
                empty,
                predictions.copy(deep=True),
                message,
            )

        required = {"observation_id", "predicted_value", "status"}
        if not isinstance(predictions, pd.DataFrame) or not required <= set(
            predictions
        ):
            return Evaluation(
                math.inf,
                "technical_failure",
                count,
                0,
                count,
                {},
                empty,
                pd.DataFrame(),
                "prediction callback must return IDs, values and status",
            )
        pred = predictions.loc[
            predictions["observation_id"].isin(obs["observation_id"])
        ].copy()
        if pred["observation_id"].duplicated().any():
            return failure("incomplete", message="duplicate target predictions")
        if set(pred["observation_id"]) != set(obs["observation_id"]):
            return failure("incomplete", message="missing target predictions")
        pred = pred.set_index("observation_id").loc[obs["observation_id"]].reset_index()
        numeric = pd.to_numeric(pred["predicted_value"], errors="coerce").to_numpy(
            float, na_value=np.nan
        )
        technical = ~pred["status"].isin(BIOLOGICAL_STATUSES)
        if technical.any():
            return failure("technical_failure", technical=int(technical.sum()))
        valid = pd.Series(np.isfinite(numeric), index=pred.index)
        if "variable" in pred:
            valid &= pred["variable"].eq(obs["trait"])
        if "trait" in pred:
            valid &= pred["trait"].eq(obs["trait"])
        if "event_valid" in pred:
            valid &= pred["event_valid"].eq(True).fillna(False)
        # A finite event cannot have occurred in an ungerminated crop.
        valid &= pred["status"].ne("not_germinated")
        is_yield = obs["trait"].isin(YIELD_TRAITS)
        forced = pred.get("forced_maturity", pd.Series(None, index=pred.index))
        natural = pred.get("natural_maturity", pd.Series(True, index=pred.index))
        valid &= ~is_yield | (
            pred["status"].eq("matured")
            & forced.eq(False).fillna(False)
            & natural.eq(True).fillna(False)
        )
        # Nullable comparisons may introduce unknowns even with finite numbers.
        # Every fixed target must have explicitly true validity, never skip-NA.
        valid = valid.fillna(False).to_numpy(bool)
        if not valid.all():
            return failure("invalid_event", valid=int(valid.sum()))
        scale = obs["trait"].map(self.scales).to_numpy(float)
        weight = obs["trait"].map(self.trait_weights).fillna(1.0).to_numpy(float)
        with np.errstate(over="ignore", invalid="ignore"):
            sample_weight = obs.get(
                "sample_weight", pd.Series(1.0, index=obs.index)
            ).to_numpy(float)
            weight *= sample_weight
            finite_weights = np.isfinite(weight) & (weight > 0)
            if not finite_weights.all():
                return failure(
                    "invalid_prediction",
                    valid=int(finite_weights.sum()),
                    message="effective weights must be finite and positive",
                )
            residuals = (numeric - obs["value"].to_numpy(float)) / scale
            residuals *= np.sqrt(weight)
            finite_residuals = np.isfinite(residuals)
            if not finite_residuals.all():
                return failure(
                    "invalid_prediction",
                    valid=int(finite_residuals.sum()),
                    message="weighted residual overflow",
                )
            squared = residuals**2
            total = float(np.sum(squared))
        if not math.isfinite(total):
            return failure("invalid_prediction", message="weighted residual overflow")
        per_trait = {
            trait: float(np.sum(squared[obs["trait"].eq(trait).to_numpy(bool)]))
            for trait in sorted(obs["trait"].unique())
        }
        return Evaluation(
            total,
            "valid",
            count,
            count,
            0,
            per_trait,
            residuals,
            pred,
        )

    def evaluate(
        self, parameters: Mapping[str, float], *, context: str = ""
    ) -> Evaluation:
        params = {name: float(value) for name, value in parameters.items()}
        if not all(math.isfinite(value) for value in params.values()):
            raise ValueError("parameters must be finite")
        key = self._evaluation_key(params)
        cached = self.cache is not None and key in self.cache
        if cached:
            result = self.cache[key]
        else:
            try:
                predictions = self.evaluator(params.copy())
            except Exception as error:
                result = Evaluation(
                    math.inf,
                    "technical_failure",
                    len(self._observations),
                    0,
                    len(self._observations),
                    {},
                    np.full(len(self._observations), np.nan),
                    pd.DataFrame(),
                    f"{type(error).__name__}: {error}",
                )
            else:
                result = self.score_predictions(predictions)
            if self.cache is not None:
                self.cache[key] = result
        record = {
            "evaluation_key": key,
            "parameters": params,
            "loss": result.loss,
            "status": result.status,
            "expected_count": result.expected_count,
            "valid_count": result.valid_count,
            "technical_count": result.technical_count,
            "message": result.message,
            "cached": cached,
            "context": context,
        }
        self.trace.append(record)
        if self.record_callback is not None:
            self.record_callback(record.copy())
        return result


def _json_safe(value: Any) -> Any:
    """Keep nonfinite failed scores explicit as null plus their recorded status."""
    if isinstance(value, pd.DataFrame):
        return _json_safe(value.to_dict("records"))
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, np.ndarray)):
        return [_json_safe(v) for v in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(value) else None
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, np.integer):
        return int(value)
    return value


def aicc(
    sse: float, n: int, n_parameters: int, *, count_residual_variance: bool = True
) -> float:
    """Descriptive Gaussian AICc, omitting a shared likelihood constant.

    Only compare identical targets, scales and weights. Independence/Gaussian
    errors are assumptions, not established here; site/trait dependence can make
    this diagnostic optimistic. CV, not AICc, drives one-SE selection.
    """
    k = n_parameters + int(count_residual_variance)
    if n_parameters < 0 or n <= k + 1 or not math.isfinite(sse) or sse < 0:
        return math.inf
    return float(
        n * math.log(max(sse / n, np.finfo(float).tiny))
        + 2 * k
        + 2 * k * (k + 1) / (n - k - 1)
    )


@dataclass
class FitResult:
    parameters: dict[str, float]
    active: tuple[str, ...]
    loss: float
    success: bool
    status: str
    aicc: float
    starts: pd.DataFrame
    trace: pd.DataFrame
    target_hash: str
    scales: dict[str, float]
    seed: int
    scale_details: dict[str, dict[str, Any]]
    nfev: int
    budget_exhausted: bool
    effective_refit: bool = False
    converged: bool = False
    converged_starts: int = 0
    selected_start: int | None = None
    initial_only: bool = False
    reference_only: bool = False

    @property
    def refit_kind(self) -> str:
        if not self.success:
            return "no_valid_candidate"
        if not self.active:
            return "fixed_parameter_evaluation_no_uncertainty"
        return "effective_refit" if self.effective_refit else "initial_candidate_only"

    def to_dict(self, *, include_trace: bool = True) -> dict[str, Any]:
        result = {
            "parameters": self.parameters,
            "active": self.active,
            "loss": self.loss,
            "success": self.success,
            "status": self.status,
            "aicc": self.aicc,
            "starts": self.starts,
            "target_hash": self.target_hash,
            "scales": self.scales,
            "seed": self.seed,
            "scale_details": self.scale_details,
            "nfev": self.nfev,
            "budget_exhausted": self.budget_exhausted,
            "effective_refit": self.effective_refit,
            "converged": self.converged,
            "converged_starts": self.converged_starts,
            "selected_start": self.selected_start,
            "initial_only": self.initial_only,
            "reference_only": self.reference_only,
            "free_parameter_count": len(self.active),
            "refit_kind": self.refit_kind,
        }
        if include_trace:
            result["trace"] = self.trace
        return _json_safe(result)


def _parameter_setup(
    specs: Sequence[ParameterSpec],
    active: Sequence[str] | None,
    fixed: Mapping[str, float] | None,
) -> tuple[dict[str, ParameterSpec], tuple[str, ...], dict[str, float]]:
    by_name = {spec.name: spec for spec in specs}
    if len(by_name) != len(specs):
        raise ValueError("parameter spec names must be unique")
    names = (
        tuple(p.name for p in specs if p.role == "fit")
        if active is None
        else tuple(active)
    )
    if len(set(names)) != len(names) or not set(names) <= set(by_name):
        raise ValueError("active parameter names must be unique and known")
    if any(by_name[name].role == "fixed" for name in names):
        raise ValueError("fixed-role parameters cannot be fitted")
    fixed = dict(fixed or {})
    if not set(fixed) <= set(by_name) or set(fixed) & set(names):
        raise ValueError(
            "fixed values must be known and disjoint from active parameters"
        )
    base = {p.name: float(p.prior) for p in specs}
    base.update({name: float(value) for name, value in fixed.items()})
    for name, value in base.items():
        spec = by_name[name]
        if not math.isfinite(value) or not spec.lower <= value <= spec.upper:
            raise ValueError(f"out-of-bound fixed/reference value: {name}")
    return by_name, names, base


def fit(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    *,
    active: Sequence[str] | None = None,
    fixed: Mapping[str, float] | None = None,
    n_starts: int = 8,
    seed: int = 0,
    maxiter: int = 300,
    method: str = "Powell",
    initial: Mapping[str, float] | None = None,
    max_nfev: int | None = None,
    initial_candidates: Sequence[Mapping[str, float]] | None = None,
    xtol: float = 1e-7,
    ftol: float = 1e-10,
    parameter_precision: Mapping[str, int] | None = None,
    context: str = "fit",
) -> FitResult:
    """Bounded multistart, scaling every active parameter to [0,1].

    First start uses reference/``initial`` values; others use seeded uniform
    bounded draws (a search design, not a probability prior). Powell tolerates
    stepwise native dates; ``method='least_squares'`` suits smooth callbacks.
    Invalid starts are retained and skipped; invalid trial points receive an
    internal solver penalty but always retain infinite public loss.
    ``success`` means a finite valid candidate was found, not global optimality.
    Inspect per-start ``converged`` separately. ``max_nfev`` is a hard total
    evaluation-request limit across starts, including numerical Jacobians and
    cached requests. Available budget is divided among remaining starts.
    External ``initial_candidates`` follow the reference start, replacing random
    starts; e.g. feasible candidates found by sensitivity screening.
    ``effective_refit`` requires a valid selected start with solver convergence
    or material loss improvement beyond initial/numerical-Jacobian evaluations:
    normalized movement > 10*sqrt(machine epsilon) and loss improvement
    > 100*epsilon*max(1, initial loss). A valid empty-active baseline is effective,
    but is explicitly a fixed-parameter evaluation, not parameter uncertainty.
    """
    by_name, names, base = _parameter_setup(specs, active, fixed)
    if n_starts < 1 or maxiter < 1 or method not in {"Powell", "least_squares"}:
        raise ValueError("positive starts/maxiter and Powell/least_squares required")
    if max_nfev is not None and (not isinstance(max_nfev, int) or max_nfev < 1):
        raise ValueError("max_nfev must be a positive integer or None")
    if not (math.isfinite(xtol) and xtol > 0) or not (
        math.isfinite(ftol) and ftol > 0
    ):
        raise ValueError("xtol and ftol must be finite and positive")
    precision = dict(parameter_precision or {})
    if not set(precision) <= set(by_name):
        raise ValueError("parameter precision names must be known")
    if any(
        isinstance(digits, bool) or not isinstance(digits, int) or digits < 0
        for digits in precision.values()
    ):
        raise ValueError("parameter precision must be nonnegative integers")
    first = base.copy()
    for name, value in (initial or {}).items():
        if name not in names:
            continue
        spec = by_name[name]
        if not math.isfinite(value) or not spec.lower <= value <= spec.upper:
            raise ValueError(f"out-of-bound initial value: {name}")
        first[name] = float(value)
    rng = np.random.default_rng(seed)
    lower = np.array([by_name[name].lower for name in names], dtype=float)
    span = np.array([by_name[name].upper for name in names], dtype=float) - lower
    first_x = (np.array([first[name] for name in names]) - lower) / span
    supplied_starts = []
    for candidate in initial_candidates or ():
        params = first.copy()
        for name in names:
            if name in candidate:
                spec, value = by_name[name], float(candidate[name])
                if not math.isfinite(value) or not spec.lower <= value <= spec.upper:
                    raise ValueError(f"out-of-bound initial candidate: {name}")
                params[name] = value
        supplied_starts.append(
            (np.array([params[name] for name in names]) - lower) / span
        )
    best_loss = math.inf
    best_parameters = first.copy()
    start_rows: list[dict[str, Any]] = []
    trace_start = len(problem.trace)
    nfev, budget_exhausted = 0, False

    class EvaluationBudgetExhausted(Exception):
        pass

    def unpack(x: np.ndarray) -> dict[str, float]:
        params = base.copy()
        values = lower + span * x
        for index, name in enumerate(names):
            value = float(values[index])
            if name in precision:
                value = round(value, precision[name])
            params[name] = value
        return params

    start_count = n_starts if names else 1
    for start in range(start_count):
        if start == 0:
            x0 = first_x
        elif start <= len(supplied_starts):
            x0 = supplied_starts[start - 1]
        else:
            x0 = rng.uniform(size=len(names))
        start_limit = (
            None
            if max_nfev is None
            else min(
                max_nfev, nfev + max(1, (max_nfev - nfev) // (start_count - start))
            )
        )
        start_params = unpack(x0)
        start_nfev = nfev
        local_loss = math.inf
        local_params = start_params.copy()

        def evaluate(x: np.ndarray) -> Evaluation:
            nonlocal local_loss, local_params, best_loss, best_parameters, nfev
            if start_limit is not None and nfev >= start_limit:
                raise EvaluationBudgetExhausted
            nfev += 1
            params = unpack(x)
            evaluation = problem.evaluate(params, context=f"{context}/start-{start}")
            if evaluation.loss < local_loss:
                local_loss, local_params = evaluation.loss, params.copy()
            if evaluation.loss < best_loss:
                best_loss, best_parameters = evaluation.loss, params.copy()
            return evaluation

        try:
            initial_evaluation = evaluate(x0)
        except EvaluationBudgetExhausted:
            budget_exhausted = True
            start_rows.append(
                {
                    "start": start,
                    "loss": math.inf,
                    "converged": False,
                    "nfev": 0,
                    "budget_exhausted": True,
                    "effective_refit": False,
                    "initial_only": False,
                    "initial_loss": math.inf,
                    "initial_status": "budget_exhausted",
                    "status": "budget_exhausted",
                    "parameters": start_params,
                    "message": "evaluation budget exhausted",
                    **{f"initial_{k}": v for k, v in start_params.items()},
                    **{f"final_{k}": v for k, v in start_params.items()},
                }
            )
            continue
        converged = not names and math.isfinite(initial_evaluation.loss)
        message = initial_evaluation.message
        start_exhausted = False
        if names and math.isfinite(initial_evaluation.loss):
            penalty = max(1e12, initial_evaluation.loss * 1e6)
            try:
                if method == "least_squares":

                    def residual(x: np.ndarray) -> np.ndarray:
                        value = evaluate(x)
                        if math.isfinite(value.loss):
                            return value.residuals
                        return np.full(value.expected_count, math.sqrt(penalty))

                    solved = least_squares(
                        residual,
                        x0,
                        bounds=(np.zeros(len(names)), np.ones(len(names))),
                        max_nfev=maxiter,
                        ftol=ftol,
                        xtol=xtol,
                        gtol=1e-10,
                    )
                else:

                    def objective(x: np.ndarray) -> float:
                        value = evaluate(x)
                        return value.loss if math.isfinite(value.loss) else penalty

                    solved = minimize(
                        objective,
                        x0,
                        method="Powell",
                        bounds=[(0.0, 1.0)] * len(names),
                        options={"maxiter": maxiter, "xtol": xtol, "ftol": ftol},
                    )
                converged, message = bool(solved.success), str(solved.message)
            except EvaluationBudgetExhausted:
                start_exhausted = budget_exhausted = True
                converged, message = False, "evaluation budget exhausted"
        finite = math.isfinite(local_loss)
        movement = (
            float(
                np.max(
                    np.abs(
                        (np.array([local_params[name] for name in names]) - lower)
                        / span
                        - x0
                    )
                )
            )
            if names
            else 0.0
        )
        materially_improved = (
            finite
            and math.isfinite(initial_evaluation.loss)
            and initial_evaluation.loss - local_loss
            > 100 * np.finfo(float).eps * max(1.0, initial_evaluation.loss)
            and movement > 10 * math.sqrt(np.finfo(float).eps)
        )
        effective = finite and (not names or converged or materially_improved)
        start_rows.append(
            {
                "start": start,
                "loss": local_loss,
                "converged": converged,
                "nfev": nfev - start_nfev,
                "budget_exhausted": start_exhausted,
                "effective_refit": effective,
                "initial_only": finite and bool(names) and not effective,
                "initial_loss": initial_evaluation.loss,
                "initial_status": initial_evaluation.status,
                "status": (
                    "budget_exhausted"
                    if start_exhausted
                    else "valid"
                    if math.isfinite(local_loss)
                    else initial_evaluation.status
                ),
                "parameters": local_params,
                "message": message,
                **{f"initial_{k}": v for k, v in start_params.items()},
                **{f"final_{k}": v for k, v in local_params.items()},
            }
        )
    success = math.isfinite(best_loss)
    selected_row = (
        min(
            start_rows,
            key=lambda row: (
                row["loss"],
                not row["effective_refit"],
                not row["converged"],
                row["start"],
            ),
        )
        if success
        else None
    )
    if selected_row is not None:
        best_parameters = selected_row["parameters"].copy()
    return FitResult(
        best_parameters,
        names,
        best_loss,
        success,
        "valid" if success else "no_valid_candidate",
        aicc(best_loss, len(problem._observations), len(names)),
        pd.DataFrame(start_rows),
        pd.DataFrame(problem.trace[trace_start:]),
        problem.target_hash,
        problem.scales.copy(),
        seed,
        problem.scale_details.copy(),
        nfev,
        budget_exhausted,
        effective_refit=bool(selected_row and selected_row["effective_refit"]),
        converged=bool(selected_row and selected_row["converged"]),
        converged_starts=sum(bool(row["converged"]) for row in start_rows),
        selected_start=selected_row["start"] if selected_row else None,
        initial_only=bool(selected_row and selected_row["initial_only"]),
        reference_only=bool(
            selected_row and selected_row["start"] == 0 and selected_row["initial_only"]
        ),
    )


@dataclass
class StagedFitResult:
    stages: tuple[FitResult, ...]
    final: FitResult

    def to_dict(self) -> dict[str, Any]:
        return {
            "stages": [stage.to_dict() for stage in self.stages],
            "final": self.final.to_dict(),
        }


def staged_fit(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    stages: Sequence[Sequence[str]],
    **fit_options: Any,
) -> StagedFitResult:
    """Nested warm-start stages; last stage jointly refits all active parameters."""
    if not stages or any(
        not set(left) <= set(right) for left, right in zip(stages, stages[1:])
    ):
        raise ValueError("stages must be nonempty and nested")
    results = []
    initial = fit_options.pop("initial", None)
    context = fit_options.pop("context", "staged")
    for index, names in enumerate(stages):
        result = fit(
            problem,
            specs,
            active=names,
            initial=initial,
            context=f"{context}/stage-{index}",
            **fit_options,
        )
        results.append(result)
        if result.success:
            initial = result.parameters
    return StagedFitResult(tuple(results), results[-1])


@dataclass(frozen=True)
class GroupedFold:
    name: str
    held_out: Any
    train_ids: tuple[str, ...]
    test_ids: tuple[str, ...]


def grouped_folds(
    observations: pd.DataFrame,
    *,
    group_by: str = "year",
    site_fold_count: int | None = None,
    site_fold_map: Mapping[str, int] | None = None,
) -> tuple[GroupedFold, ...]:
    """Leave-one-group-out (call separately for year and site diagnostics)."""
    obs = _observations(observations)
    if group_by not in obs or obs[group_by].isna().any():
        raise ValueError(f"grouping column must be present and nonmissing: {group_by}")
    groups = sorted(obs[group_by].unique(), key=str)
    if len(groups) < 2:
        raise ValueError("grouped CV requires at least two groups")
    for column in ("management_unit_id", "environment_id"):
        if column in obs:
            if obs[column].isna().any():
                raise ValueError(f"{column} cannot be missing in grouped folds")
            if obs.groupby(column)[group_by].nunique().gt(1).any():
                raise ValueError(f"{column} crosses {group_by} groups")
    if site_fold_count is not None or site_fold_map is not None:
        if group_by != "site":
            raise ValueError(
                "site fold options require group_by='site'; year stays LOYO"
            )
        if site_fold_count is not None and (
            isinstance(site_fold_count, bool)
            or not isinstance(site_fold_count, int)
            or not 2 <= site_fold_count <= 5
        ):
            raise ValueError("site_fold_count must be an integer in [2, 5]")
        mapping = (
            dict(site_fold_map)
            if site_fold_map is not None
            else {
                str(group): index % min(site_fold_count, len(groups))
                for index, group in enumerate(groups)
            }
        )
        if not set(map(str, groups)) <= set(mapping) or any(
            isinstance(value, bool) or not isinstance(value, int) or not 0 <= value < 5
            for value in mapping.values()
        ):
            raise ValueError("site fold map must cover sites with fold IDs 0..4")
        assignments = obs[group_by].astype(str).map(mapping)
        fold_ids = sorted(assignments.unique())
        if len(fold_ids) < 2:
            raise ValueError(
                "grouped CV requires at least two populated global site folds"
            )
        return tuple(
            GroupedFold(
                f"site_fold_{fold_id}",
                tuple(
                    sorted(
                        group for group, value in mapping.items() if value == fold_id
                    )
                ),
                tuple(sorted(obs.loc[assignments.ne(fold_id), "observation_id"])),
                tuple(sorted(obs.loc[assignments.eq(fold_id), "observation_id"])),
            )
            for fold_id in fold_ids
        )
    return tuple(
        GroupedFold(
            f"leave_{group_by}_{group}",
            group,
            tuple(sorted(obs.loc[obs[group_by].ne(group), "observation_id"])),
            tuple(sorted(obs.loc[obs[group_by].eq(group), "observation_id"])),
        )
        for group in groups
    )


def select_one_se(summary: pd.DataFrame) -> str:
    """Choose fewest coefficients within best mean + its fold SE.

    Equal-weight fold variability is a selection heuristic, not a calibrated
    uncertainty interval: overlapping training folds are not independent.
    """
    finite = summary.loc[
        np.isfinite(summary["mean_loss"]) & np.isfinite(summary["se_loss"])
    ]
    if finite.empty:
        raise ValueError("no candidate has complete finite CV scores")
    best = finite.sort_values(
        ["mean_loss", "n_parameters", "candidate"], kind="stable"
    ).iloc[0]
    threshold = best["mean_loss"] + best["se_loss"]
    eligible = finite.loc[finite["mean_loss"] <= threshold + 1e-12]
    return str(
        eligible.sort_values(
            ["n_parameters", "mean_loss", "candidate"], kind="stable"
        ).iloc[0]["candidate"]
    )


def _child_problem(
    problem: CalibrationProblem,
    obs: pd.DataFrame,
    *,
    scales: Mapping[str, float] | None = None,
) -> CalibrationProblem:
    return CalibrationProblem(
        obs,
        problem.evaluator,
        scales=scales,
        trait_weights=problem.trait_weights,
        cache=problem.cache,
        cache_namespace=problem.cache_namespace,
        record_callback=problem.record_callback,
    )


@dataclass
class CrossValidationResult:
    selected: str | None
    refit: FitResult | None
    summary: pd.DataFrame
    fold_scores: pd.DataFrame
    candidate_fits: dict[str, FitResult]
    trace: pd.DataFrame
    excluded_ids: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return _json_safe(
            {
                "selected": self.selected,
                "refit": self.refit.to_dict() if self.refit else None,
                "summary": self.summary,
                "fold_scores": self.fold_scores,
                "candidate_fits": {
                    k: v.to_dict() for k, v in self.candidate_fits.items()
                },
                "trace": self.trace,
                "excluded_ids": self.excluded_ids,
            }
        )


def grouped_cross_validate(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    candidates: Mapping[str, Sequence[str]] | Sequence[Sequence[str]],
    *,
    group_by: str = "year",
    training_years: Sequence[int] = tuple(range(2014, 2023)),
    site_fold_count: int | None = None,
    site_fold_map: Mapping[str, int] | None = None,
    **fit_options: Any,
) -> CrossValidationResult:
    """Fit each candidate in each training fold, select one-SE, joint refit.

    Independent years are excluded before *any* scale estimation/selection/refit.
    Fold scales use training only unless caller supplied prespecified scales.
    A held-out trait without a training/prespecified scale retains its entire
    fold as ``unsupported_trait_fold`` with infinite loss; never borrow holdout
    scales or drop its targets. Other folds and full-training fits still run.
    Test SSE is divided by test sample-weight sum; every fold counts equally.
    Any invalid fold makes that candidate's mean/SE infinite (no nanmean).
    Full-training AICc scores use identical targets/scales and are diagnostic only.
    Finite train-and-test solutions seed the joint refit's first starts, ahead
    of caller/random seeds, within its unchanged start count and request budget.
    Every retained joint-refit candidate is evaluated on all in-year targets.
    """
    obs = problem.observations
    if "year" not in obs or obs["year"].isna().any():
        raise ValueError("CV requires observation years to protect independent years")
    allowed = obs["year"].isin(training_years)
    excluded = tuple(sorted(obs.loc[~allowed, "observation_id"]))
    obs = obs.loc[allowed].reset_index(drop=True)
    folds = grouped_folds(
        obs,
        group_by=group_by,
        site_fold_count=site_fold_count,
        site_fold_map=site_fold_map,
    )
    if not isinstance(candidates, Mapping):
        candidates = {f"candidate_{i}": names for i, names in enumerate(candidates)}
    if not candidates or not all(isinstance(k, str) for k in candidates):
        raise ValueError("candidates need unique string labels and at least one set")
    for names in candidates.values():
        _parameter_setup(specs, names, fit_options.get("fixed"))
    fit_options = dict(fit_options)
    context = fit_options.pop("context", "cv")
    frozen_scales = problem.scales if problem._prespecified_scales else None
    full_problem = _child_problem(problem, obs, scales=frozen_scales)
    traces, scores, summaries = [], [], []
    full_fits: dict[str, FitResult] = {}
    for candidate, names in candidates.items():
        fold_losses = []
        feasible_seeds: list[tuple[float, dict[str, float]]] = []
        for fold in folds:
            train = obs.loc[obs["observation_id"].isin(fold.train_ids)]
            test = obs.loc[obs["observation_id"].isin(fold.test_ids)]
            train_problem = _child_problem(problem, train, scales=frozen_scales)
            fitted = fit(
                train_problem,
                specs,
                active=names,
                context=f"{context}/{candidate}/{fold.name}/train",
                **fit_options,
            )
            unsupported = tuple(sorted(set(test["trait"]) - set(train_problem.scales)))
            test_problem = None
            valid_count, technical_count, message = 0, 0, ""
            if unsupported:
                loss, status = math.inf, "unsupported_trait_fold"
                message = "no training/prespecified scale for: " + ", ".join(
                    unsupported
                )
            elif fitted.success:
                test_problem = _child_problem(
                    problem, test, scales=train_problem.scales
                )
                tested = test_problem.evaluate(
                    fitted.parameters, context=f"{context}/{candidate}/{fold.name}/test"
                )
                denominator = float(
                    test.get("sample_weight", pd.Series(1.0, index=test.index)).sum()
                )
                loss = tested.loss / denominator
                status = tested.status
                valid_count = tested.valid_count
                technical_count = tested.technical_count
                message = tested.message
                if math.isfinite(loss):
                    feasible_seeds.append((loss, fitted.parameters.copy()))
            else:
                loss, status = math.inf, fitted.status
            fold_losses.append(loss)
            scores.append(
                {
                    "candidate": candidate,
                    "fold": fold.name,
                    "held_out": fold.held_out,
                    "n_parameters": len(names),
                    "loss": loss,
                    "status": status,
                    "unsupported_traits": unsupported,
                    "expected_count": len(test),
                    "valid_count": valid_count,
                    "technical_count": technical_count,
                    "message": message,
                    "train_loss": fitted.loss,
                    "train_aicc": fitted.aicc,
                    "scales": train_problem.scales,
                    "parameters": fitted.parameters,
                    "scale_details": train_problem.scale_details,
                    "train_ids": fold.train_ids,
                    "test_ids": fold.test_ids,
                }
            )
            traces.extend(train_problem.trace)
            if test_problem is not None:
                traces.extend(test_problem.trace)
        refit_options = fit_options.copy()
        if feasible_seeds:
            # Each seed covered the full target set across disjoint train/test
            # evaluations. Re-evaluate under full-training scales inside fit;
            # no uncounted prefit requests or holdout-only parameter selection.
            seeds = [
                parameters
                for _, parameters in sorted(feasible_seeds, key=lambda item: item[0])
            ]
            caller_initial = refit_options.get("initial")
            caller_candidates = list(refit_options.get("initial_candidates") or ())
            refit_options["initial"] = seeds[0]
            refit_options["initial_candidates"] = (
                seeds[1:]
                + ([caller_initial] if caller_initial is not None else [])
                + caller_candidates
            )
        fitted = fit(
            full_problem,
            specs,
            active=names,
            context=f"{context}/{candidate}/joint-refit",
            **refit_options,
        )
        full_fits[candidate] = fitted
        complete = all(math.isfinite(value) for value in fold_losses)
        summaries.append(
            {
                "candidate": candidate,
                "active": tuple(names),
                "n_parameters": len(names),
                "mean_loss": float(np.mean(fold_losses)) if complete else math.inf,
                "se_loss": (
                    float(np.std(fold_losses, ddof=1) / math.sqrt(len(fold_losses)))
                    if complete
                    else math.inf
                ),
                "fold_count": len(folds),
                "valid_fold_count": sum(math.isfinite(value) for value in fold_losses),
                "aicc": fitted.aicc,
                "full_training_loss": fitted.loss,
                "full_refit_success": fitted.success,
                "full_refit_status": fitted.status,
                "feasible_fold_seed_count": len(feasible_seeds),
            }
        )
    traces.extend(full_problem.trace)
    summary = pd.DataFrame(summaries)
    try:
        selected = select_one_se(summary)
    except ValueError:
        selected = None
    return CrossValidationResult(
        selected,
        full_fits[selected] if selected else None,
        summary,
        pd.DataFrame(scores),
        full_fits,
        pd.DataFrame(traces),
        excluded,
    )


@dataclass
class SensitivityResult:
    summary: pd.DataFrame
    effects: pd.DataFrame
    trace: pd.DataFrame
    method: str = "randomized_elementary_effects_not_sobol_indices"

    def to_dict(self) -> dict[str, Any]:
        return _json_safe(vars(self))


def global_sensitivity(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    *,
    active: Sequence[str] | None = None,
    fixed: Mapping[str, float] | None = None,
    n_trajectories: int = 16,
    step_fraction: float = 0.1,
    seed: int = 0,
) -> SensitivityResult:
    """Global bounded elementary-effects screening, not variance decomposition.

    Random continuous trajectories perturb each selected parameter once, in
    random order. Effects are changes in weighted/standardized predictions per
    fraction of parameter range. mu is signed mean within trait; mu_star averages
    absolute row-level effects before aggregation to avoid environment-response
    cancellation. sigma describes trajectory variability of signed means.
    Expected/valid counts explicitly expose validity conditioning.
    No sensitivity magnitude is an identifiability or causal-effect claim.
    """
    by_name, names, base = _parameter_setup(specs, active, fixed)
    if not names or n_trajectories < 1 or not 0 < step_fraction < 1:
        raise ValueError("need active parameters, positive trajectories and 0<step<1")
    rng = np.random.default_rng(seed)
    trace_start = len(problem.trace)
    traits = problem._observations["trait"]
    rows = []
    for trajectory in range(n_trajectories):
        x = rng.uniform(0, 1 - step_fraction, size=len(names))
        params = base.copy()
        for i, name in enumerate(names):
            spec = by_name[name]
            params[name] = spec.lower + (spec.upper - spec.lower) * x[i]
        previous = problem.evaluate(params, context=f"sensitivity/{trajectory}/base")
        for i in rng.permutation(len(names)):
            name, spec = names[i], by_name[names[i]]
            params[name] += step_fraction * (spec.upper - spec.lower)
            current = problem.evaluate(
                params, context=f"sensitivity/{trajectory}/{name}"
            )
            valid = math.isfinite(previous.loss) and math.isfinite(current.loss)
            effects = (
                (current.residuals - previous.residuals) / step_fraction
                if valid
                else np.full(len(traits), np.nan)
            )
            for trait in sorted(traits.unique()):
                effect = float(np.mean(effects[traits.eq(trait)])) if valid else np.nan
                absolute_effect = (
                    float(np.mean(np.abs(effects[traits.eq(trait)])))
                    if valid
                    else np.nan
                )
                rows.append(
                    {
                        "trajectory": trajectory,
                        "parameter": name,
                        "trait": trait,
                        "effect": effect,
                        "absolute_effect": absolute_effect,
                        "status": "valid" if valid else "invalid_pair",
                        "base_status": previous.status,
                        "perturbed_status": current.status,
                    }
                )
            previous = current
    effects_frame = pd.DataFrame(rows)
    summaries = []
    for (name, trait), group in effects_frame.groupby(
        ["parameter", "trait"], sort=True
    ):
        finite = group.loc[np.isfinite(group["effect"]), "effect"].to_numpy()
        summaries.append(
            {
                "parameter": name,
                "trait": trait,
                "expected_count": len(group),
                "valid_count": len(finite),
                "mu": float(np.mean(finite)) if len(finite) else np.nan,
                "mu_star": (
                    float(group["absolute_effect"].mean()) if len(finite) else np.nan
                ),
                "sigma": float(np.std(finite, ddof=1)) if len(finite) > 1 else np.nan,
            }
        )
    return SensitivityResult(
        pd.DataFrame(summaries),
        effects_frame,
        pd.DataFrame(problem.trace[trace_start:]),
    )


@dataclass
class ProfileResult:
    profiles: pd.DataFrame
    trace: pd.DataFrame
    reference_loss: float
    interpretation: str = "nuisance_refitted_sse_profile_not_confidence_interval"

    def to_dict(self) -> dict[str, Any]:
        return _json_safe(vars(self))


def parameter_profiles(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    fitted: FitResult,
    *,
    grids: Mapping[str, Sequence[float]] | None = None,
    grid_points: int = 9,
    **fit_options: Any,
) -> ProfileResult:
    """Hold each profiled coefficient and refit every other active coefficient.

    Raw/delta SSE are diagnostic. No automatic chi-square cutoff or confidence
    interval is justified by this generic callback and weighted multitrait loss.
    Negative deltas are retained if profiling finds a better solution.
    """
    if not fitted.success or grid_points < 2:
        raise ValueError("profiles require a valid fit and at least two grid points")
    by_name = {spec.name: spec for spec in specs}
    if grids is None:
        grids = {
            name: sorted(
                set(
                    np.linspace(
                        by_name[name].lower, by_name[name].upper, grid_points
                    ).tolist()
                    + [fitted.parameters[name]]
                )
            )
            for name in fitted.active
        }
    if not grids or not set(grids) <= set(fitted.active):
        raise ValueError("profile grids must name fitted active parameters")
    options = dict(fit_options)
    context = options.pop("context", "profile")
    options.pop("initial", None)
    if "fixed" in options or "active" in options:
        raise ValueError("profiles derive active/fixed values from the supplied fit")
    rows = []
    trace_start = len(problem.trace)
    for name, grid in grids.items():
        spec = by_name[name]
        values = tuple(float(value) for value in grid)
        if not values or any(
            not math.isfinite(value) or not spec.lower <= value <= spec.upper
            for value in values
        ):
            raise ValueError(f"profile grid outside native bounds: {name}")
        nuisance = tuple(p for p in fitted.active if p != name)
        fixed = {p: v for p, v in fitted.parameters.items() if p not in nuisance}
        for value in values:
            fixed[name] = value
            profiled = fit(
                problem,
                specs,
                active=nuisance,
                fixed=fixed,
                initial=fitted.parameters,
                context=f"{context}/{name}/{value:g}",
                **options,
            )
            rows.append(
                {
                    "parameter": name,
                    "value": value,
                    "loss": profiled.loss,
                    "delta_loss": profiled.loss - fitted.loss,
                    "status": profiled.status,
                    "parameters": profiled.parameters,
                    "nuisance_active": nuisance,
                }
            )
    return ProfileResult(
        pd.DataFrame(rows), pd.DataFrame(problem.trace[trace_start:]), fitted.loss
    )


@dataclass
class IdentifiabilityResult:
    rank: int | None
    rank_deficient: bool | None
    singular_values: tuple[float, ...]
    null_directions: tuple[dict[str, float], ...]
    condition_number: float
    parameters: pd.DataFrame
    trace: pd.DataFrame
    status: str
    interpretation: str = (
        "local_finite_difference_and_multistart_diagnostics_not_global_identifiability"
    )

    def to_dict(self) -> dict[str, Any]:
        return _json_safe(vars(self))


def identifiability_diagnostics(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    fitted: FitResult,
    *,
    step_fraction: float = 1e-4,
    rank_rtol: float = 1e-6,
    near_optimal_delta: float = 1e-4,
) -> IdentifiabilityResult:
    """Local scaled residual-Jacobian SVD + spread among near-optimal starts.

    Full local rank does not prove global/statistical identifiability. Discrete
    native events, boundary points and finite-difference step size affect rank.
    Tall/square Jacobians use reduced SVD; wide ones retain the full right-null
    basis (their full left basis is only rows-by-rows, with rows < coefficients).
    """
    if (
        not fitted.success
        or not fitted.active
        or not 0 < step_fraction < 0.5
        or not 0 < rank_rtol < 1
        or near_optimal_delta < 0
    ):
        raise ValueError("need a valid active fit and positive diagnostic settings")
    by_name = {spec.name: spec for spec in specs}
    trace_start = len(problem.trace)
    columns, rows = [], []
    near = fitted.starts.loc[
        np.isfinite(fitted.starts["loss"])
        & fitted.starts["loss"].le(fitted.loss + near_optimal_delta)
    ]
    for name in fitted.active:
        spec = by_name[name]
        span = spec.upper - spec.lower
        center = fitted.parameters[name]
        low, high = (
            max(spec.lower, center - step_fraction * span),
            min(spec.upper, center + step_fraction * span),
        )
        p_low, p_high = fitted.parameters.copy(), fitted.parameters.copy()
        p_low[name], p_high[name] = low, high
        below = problem.evaluate(p_low, context=f"identifiability/{name}/low")
        above = problem.evaluate(p_high, context=f"identifiability/{name}/high")
        if math.isfinite(below.loss) and math.isfinite(above.loss):
            columns.append((above.residuals - below.residuals) / ((high - low) / span))
        else:
            columns.append(np.full(len(problem._observations), np.nan))
        near_values = near[f"final_{name}"].to_numpy(float)
        rows.append(
            {
                "parameter": name,
                "estimate": center,
                "near_optimal_starts": len(near_values),
                "near_optimal_min": float(np.min(near_values))
                if len(near_values)
                else np.nan,
                "near_optimal_max": float(np.max(near_values))
                if len(near_values)
                else np.nan,
                "near_optimal_span_fraction": (
                    float(np.ptp(near_values) / span) if len(near_values) else np.nan
                ),
                "at_bound": min(center - spec.lower, spec.upper - center) / span < 1e-5,
            }
        )
    jacobian = np.column_stack(columns)
    rank, deficient, singular, null, condition = None, None, (), (), math.inf
    status = "incomplete_finite_difference"
    if np.isfinite(jacobian).all():
        _, values, vt = np.linalg.svd(
            jacobian, full_matrices=jacobian.shape[0] < jacobian.shape[1]
        )
        rank = int(np.sum(values > values[0] * rank_rtol)) if values[0] > 0 else 0
        deficient = rank < len(fitted.active)
        singular = tuple(float(value) for value in values)
        null = tuple(dict(zip(fitted.active, vector.tolist())) for vector in vt[rank:])
        if not deficient:
            condition = float(values[0] / values[-1])
        status = "valid_local_diagnostic"
    return IdentifiabilityResult(
        rank,
        deficient,
        singular,
        null,
        condition,
        pd.DataFrame(rows),
        pd.DataFrame(problem.trace[trace_start:]),
        status,
    )


@dataclass
class BootstrapResult:
    replicates: pd.DataFrame
    summary: pd.DataFrame
    trace: pd.DataFrame
    seed: int
    interpretation: str = (
        "conditional_site_cluster_refit_percentiles_not_calibrated_confidence_intervals"
    )

    def to_dict(self) -> dict[str, Any]:
        return _json_safe(vars(self))


def site_cluster_bootstrap(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    *,
    active: Sequence[str] | None = None,
    n_bootstrap: int = 100,
    seed: int = 0,
    cluster_col: str = "site",
    quantiles: tuple[float, float] = (0.025, 0.975),
    replicate_ids: Sequence[int] | None = None,
    replicate_callback: RecordCallback | None = None,
    **fit_options: Any,
) -> BootstrapResult:
    """Resample sites, retaining all years/traits, and genuinely refit each draw.

    Duplicate cluster draws multiply original sample weights, not a set of IDs.
    Original training error scales and the chosen active set are held fixed:
    this is uncertainty conditional on model selection and input assumptions.
    ``success`` retains fit's finite-validity meaning. All draws, including
    failed, initial-only and budget-limited draws, retain per-start/request
    evidence. ``valid_refit_replicates`` counts success AND effective_refit;
    quantiles conservatively require success AND effective_refit AND selected
    start convergence. Counts/policy disclose every exclusion. Empty-active
    baselines are effective fixed-parameter evaluations, with no uncertainty
    summary. Budget exhaustion elsewhere does not erase a converged best start.
    Per-replicate SeedSequence([seed, replicate]) supports deterministic chunks.
    """
    obs = problem.observations
    if cluster_col not in obs or obs[cluster_col].isna().any():
        raise ValueError(f"bootstrap requires nonmissing {cluster_col}")
    if not obs[cluster_col].map(lambda x: isinstance(x, str) and bool(x)).all():
        raise ValueError("bootstrap cluster IDs must be nonempty strings")
    clusters = tuple(sorted(obs[cluster_col].unique()))
    if len(clusters) < 2 or n_bootstrap < 1:
        raise ValueError("bootstrap requires >=2 sites and positive replicate count")
    if not 0 <= quantiles[0] < quantiles[1] <= 1:
        raise ValueError("ordered quantiles must lie in [0,1]")
    indices = (
        tuple(range(n_bootstrap)) if replicate_ids is None else tuple(replicate_ids)
    )
    if (
        not indices
        or len(set(indices)) != len(indices)
        or any(not isinstance(i, int) or not 0 <= i < n_bootstrap for i in indices)
    ):
        raise ValueError("replicate IDs must be unique integers within n_bootstrap")
    _, names, _ = _parameter_setup(specs, active, fit_options.get("fixed"))
    options = dict(fit_options)
    context = options.pop("context", "bootstrap")
    rows, traces = [], []
    for replicate in indices:
        draw_seed, fit_seed = np.random.SeedSequence([seed, replicate]).spawn(2)
        rng = np.random.default_rng(draw_seed)
        draws = rng.choice(clusters, size=len(clusters), replace=True).tolist()
        counts = {cluster: draws.count(cluster) for cluster in sorted(set(draws))}
        sampled = obs.loc[obs[cluster_col].isin(counts)].copy()
        sampled["sample_weight"] = sampled.get(
            "sample_weight", pd.Series(1.0, index=sampled.index)
        ) * sampled[cluster_col].map(counts)
        child = _child_problem(problem, sampled, scales=problem.scales)
        # Preserve evidence provenance: these are frozen training scales, not
        # error estimates recomputed using this resampling draw.
        child.scale_details = {
            trait: {
                **detail,
                "bootstrap_scale_policy": "frozen_original_training_scale",
            }
            for trait, detail in problem.scale_details.items()
        }
        fitted = fit(
            child,
            specs,
            active=names,
            seed=int(fit_seed.generate_state(1)[0]),
            context=f"{context}/replicate-{replicate}",
            **options,
        )
        row = {
            "replicate": replicate,
            "cluster_draws": tuple(draws),
            "cluster_counts": counts,
            "unique_cluster_count": len(counts),
            "sample_weight_sum": float(sampled["sample_weight"].sum()),
            "parameters": fitted.parameters,
            "loss": fitted.loss,
            "success": fitted.success,
            "status": fitted.status,
            "target_hash": fitted.target_hash,
            "nfev": fitted.nfev,
            "max_nfev": options.get("max_nfev"),
            "budget_exhausted": fitted.budget_exhausted,
            "effective_refit": fitted.effective_refit,
            "converged": fitted.converged,
            "converged_starts": fitted.converged_starts,
            "selected_start": fitted.selected_start,
            "initial_only": fitted.initial_only,
            "reference_only": fitted.reference_only,
            "free_parameter_count": len(fitted.active),
            "refit_kind": fitted.refit_kind,
            "starts": fitted.starts.to_dict("records"),
        }
        rows.append(row)
        traces.extend(child.trace)
        if replicate_callback is not None:
            replicate_callback(_json_safe(row))
    replicates = pd.DataFrame(rows)
    successful = replicates["success"].to_numpy(bool)
    effective = successful & replicates["effective_refit"].to_numpy(bool)
    converged = successful & replicates["converged"].to_numpy(bool)
    eligible = effective & converged
    valid = replicates.loc[eligible]
    summaries = []
    for name in names:
        values = np.array([params[name] for params in valid["parameters"]], dtype=float)
        summaries.append(
            {
                "parameter": name,
                "valid_replicates": int(successful.sum()),
                "requested_replicates": len(indices),
                "total_requested_replicates": n_bootstrap,
                "failed_replicates": len(indices) - int(successful.sum()),
                "valid_refit_replicates": int(effective.sum()),
                "effective_refit_replicates": int(effective.sum()),
                "ineffective_replicates": int((successful & ~effective).sum()),
                "converged_replicates": int(converged.sum()),
                "nonconverged_replicates": int((successful & ~converged).sum()),
                "budget_exhausted_replicates": int(
                    replicates["budget_exhausted"].to_numpy(bool).sum()
                ),
                "initial_only_replicates": int(
                    replicates["initial_only"].to_numpy(bool).sum()
                ),
                "reference_only_replicates": int(
                    replicates["reference_only"].to_numpy(bool).sum()
                ),
                "quantile_replicates": len(values),
                "excluded_replicates": len(indices) - len(values),
                "quantile_policy": "success_and_effective_refit_and_converged",
                "summary_status": (
                    "no_effective_converged_refits"
                    if not len(values)
                    else "conditional_on_effective_converged_refits"
                    if len(values) < len(indices)
                    else "effective_converged_refits"
                ),
                "median": float(np.median(values)) if len(values) else np.nan,
                "q_low": float(np.quantile(values, quantiles[0]))
                if len(values)
                else np.nan,
                "q_high": float(np.quantile(values, quantiles[1]))
                if len(values)
                else np.nan,
                "quantile_low": quantiles[0],
                "quantile_high": quantiles[1],
            }
        )
    return BootstrapResult(
        replicates, pd.DataFrame(summaries), pd.DataFrame(traces), seed
    )


@dataclass
class InputUncertaintyResult:
    draws: pd.DataFrame
    predictions: pd.DataFrame
    trace: pd.DataFrame
    interpretation: str = "input_scenarios_at_fixed_cultivar_parameters_no_refitting"

    def to_dict(self) -> dict[str, Any]:
        return _json_safe(vars(self))


def propagate_input_uncertainty(
    observations: pd.DataFrame,
    parameters: Mapping[str, float],
    input_draws: Sequence[Mapping[str, Any]],
    evaluator: Callable[[dict[str, float], dict[str, Any]], pd.DataFrame],
    *,
    scales: Mapping[str, float] | None = None,
    trait_weights: Mapping[str, float] | None = None,
    record_callback: RecordCallback | None = None,
) -> InputUncertaintyResult:
    """Separate input uncertainty from conditional parameter bootstrap.

    The caller supplies and labels soil/management/weather input draws. No
    distribution, independence, cultivar adjustment or refit is inferred here.
    """
    if not input_draws:
        raise ValueError("input uncertainty needs at least one labeled input draw")
    obs = _observations(observations)
    frozen_scales = training_scales(obs) if scales is None else dict(scales)
    rows, predictions, traces = [], [], []
    for draw, inputs in enumerate(input_draws):
        draw_inputs = dict(inputs)
        problem = CalibrationProblem(
            obs,
            lambda p: evaluator(p, draw_inputs.copy()),
            scales=frozen_scales,
            trait_weights=trait_weights,
            record_callback=record_callback,
            cache_namespace=f"input-uncertainty-draw-{draw}",
        )
        evaluation = problem.evaluate(parameters, context=f"input-uncertainty/{draw}")
        rows.append(
            {
                "draw": draw,
                "inputs": draw_inputs,
                "parameters": dict(parameters),
                "loss": evaluation.loss,
                "status": evaluation.status,
                "valid_count": evaluation.valid_count,
                "expected_count": evaluation.expected_count,
                "uncertainty_kind": "input",
            }
        )
        prediction = obs[["observation_id", "trait", "value"]].copy()
        if "observation_id" in evaluation.predictions:
            unambiguous = evaluation.predictions.loc[
                ~evaluation.predictions["observation_id"].duplicated(keep=False)
            ]
            prediction = prediction.merge(
                unambiguous.drop(columns=["trait", "value"], errors="ignore"),
                on="observation_id",
                how="left",
                validate="one_to_one",
            )
        prediction["draw"] = draw
        prediction["uncertainty_kind"] = "input"
        prediction["draw_status"] = evaluation.status
        predictions.append(prediction)
        traces.extend(problem.trace)
    return InputUncertaintyResult(
        pd.DataFrame(rows),
        pd.concat(predictions, ignore_index=True),
        pd.DataFrame(traces),
    )
