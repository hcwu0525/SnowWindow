"""Independent preliminary training-only calibration; never formal selection."""

from __future__ import annotations

import argparse
import ctypes
import fcntl
import hashlib
import json
import math
import os
import selectors
import shutil
import signal
import subprocess
import sys
import time
import traceback
import uuid
from collections.abc import Callable, Iterable, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import qmc

from snowwindow.config import ExperimentConfig, _snapshot_document, load_config
from snowwindow.cultivar_optimization import CalibrationProblem, fit
from snowwindow.cultivar_parameters import ParameterSpec, final_round_parameter_catalog
from snowwindow.cultivar_pragmatic import (
    CONDITIONAL_SCOPE,
    effective_native_parameters,
    freeze_training_eligibility,
    training_eligibility,
    training_inputs,
)
from snowwindow.cultivar_workflow import (
    TRAINING_YEARS,
    NativeEvaluator,
    _engine_fingerprints,
    _frame_records,
    _jsonable,
    _models,
    _preparation_code_fingerprints,
    _read_json,
    _reference_parameters,
    _requests,
    _safe_id,
    _seal,
    _selected,
    _settings,
    _specs_and_candidates,
    _tables,
    _verify_seal,
    _write_immutable_json,
    _write_json,
    _write_table,
    is_cultivar_mode,
    paired_error_differences,
    trait_metrics,
)
from snowwindow.data.sources import (
    build_source_inventory,
    sha256_file,
    source_paths,
)

ACTIVE = {
    "aquacrop": ("HIstart", "HI0", "postflower_scale"),
    "apsim": (
        "juvenile_tt",
        "potential_grain_number",
        "photoperiod_sensitivity",
        "flag_leaf_tt",
    ),
    "dssat": ("P1", "G2", "P2", "PHINT"),
}
PROBE_ORDER = {
    "aquacrop": ("HI0", "HIstart", "postflower_scale"),
    "apsim": (
        "potential_grain_number",
        "juvenile_tt",
        "photoperiod_sensitivity",
        "flag_leaf_tt",
    ),
    "dssat": ("G2", "P1", "P2", "PHINT"),
}
PRELIMINARY = {
    "status": "preliminary_training_only",
    "holdout_used": False,
    "independent_validation": "not_performed",
    "cross_validation": "not_performed",
    "bootstrap": "not_performed",
    "identifiability": "unconfirmed",
    "scientific_improvement": "not_established_by_training_fit",
    "scope": CONDITIONAL_SCOPE,
}
FINAL_BUDGETS = {"aquacrop": 240, "apsim": 640, "dssat": 400}
FINAL_SCREENING_REQUESTS = 32
FINAL_START_COUNT = 3
FINAL_SEED = 20261112
FINAL_XTOL = 1e-3
FINAL_FTOL = 1e-4
FINAL_DSSAT_PRECISION = {"P1": 1, "P2": 3, "G2": 1, "PHINT": 2}


def _budget(model: str, limit: int) -> None:
    minimum = 1 + 2 * len(ACTIVE[model])
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < minimum:
        raise ValueError(f"{model} requires at least {minimum} evaluation requests")


def quick_search(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    *,
    model: str,
    max_evaluations: int = 24,
) -> dict[str, Any]:
    """All requests, including cache hits, share one fixed-target budget."""
    _budget(model, max_evaluations)
    started = time.monotonic()
    by_name = {spec.name: spec for spec in specs}
    if any(
        name not in by_name or by_name[name].role == "fixed" for name in ACTIVE[model]
    ):
        raise ValueError("quick active set is incompatible with parameter specs")
    if problem.cache is None:
        problem.cache = {}
    trace_start = len(problem.trace)
    reference = _reference_parameters(model)
    baseline = problem.evaluate(reference, context="quick/reference")
    current = {spec.name: float(spec.prior) for spec in specs}
    current.update(reference)
    best_loss, best = baseline.loss, baseline
    best_parameters = current.copy()
    for name in PROBE_ORDER[model]:
        spec = by_name[name]
        origin = current[name]
        # Both directions use the same current-coordinate origin, even if - improves.
        for direction in (-1, 1):
            candidate = current.copy()
            candidate[name] = min(
                spec.upper,
                max(spec.lower, origin + direction * 0.10 * (spec.upper - spec.lower)),
            )
            evaluation = problem.evaluate(
                candidate,
                context=f"quick/probe/{name}/{direction:+d}",
            )
            if math.isfinite(evaluation.loss) and evaluation.loss < best_loss:
                best_loss, best, best_parameters = (
                    evaluation.loss,
                    evaluation,
                    candidate.copy(),
                )
                current = candidate.copy()
    used = len(problem.trace) - trace_start
    remaining = max_evaluations - used
    fitted = None
    if remaining:
        fitted = fit(
            problem,
            specs,
            active=PROBE_ORDER[model],
            n_starts=1,
            seed=20261111,
            initial=best_parameters,
            max_nfev=remaining,
            method="Powell",
            context="quick/powell",
        )
        # Retrieve already-scored predictions, without an unbudgeted final request.
        for row in problem.trace[trace_start + used :]:
            if math.isfinite(row["loss"]) and row["loss"] < best_loss:
                best_loss = row["loss"]
                best_parameters = row["parameters"].copy()
                best = problem.cache[row["evaluation_key"]]
    trace = problem.trace[trace_start:]
    actual = len(trace)
    if actual > max_evaluations:
        raise RuntimeError("quick request budget exceeded")
    finite = math.isfinite(best_loss)
    movements = {
        name: {
            "reference": float(by_name[name].prior),
            "best": best_parameters[name],
            "delta": best_parameters[name] - float(by_name[name].prior),
            "span_fraction": (best_parameters[name] - float(by_name[name].prior))
            / (by_name[name].upper - by_name[name].lower),
        }
        for name in ACTIVE[model]
    }
    return {
        **PRELIMINARY,
        "search_status": "complete_candidate" if finite else "no_complete_candidate",
        "reference": reference,
        "parameters": best_parameters,
        "active": list(ACTIVE[model]),
        "reference_loss": baseline.loss if math.isfinite(baseline.loss) else None,
        "best_loss": best_loss if finite else None,
        "evaluation_requests": actual,
        "max_evaluations": max_evaluations,
        "probe_requests": 2 * len(ACTIVE[model]),
        "fit_requests": fitted.nfev if fitted else 0,
        "cached_requests": sum(bool(row["cached"]) for row in trace),
        "budget_exhausted": actual == max_evaluations,
        "parameter_movements": movements,
        "elapsed_seconds": time.monotonic() - started,
        "target_hash": problem.target_hash,
        "expected_count": len(problem.observations),
        "scales": problem.scales,
        "scale_details": problem.scale_details,
        "fit": fitted.to_dict(include_trace=False) if fitted else None,
        "converged": bool(fitted and fitted.converged),
        "effective_refit": finite
        and any(abs(value["span_fraction"]) > 1.5e-7 for value in movements.values())
        and (not math.isfinite(baseline.loss) or best_loss < baseline.loss),
        "failed_candidates": _jsonable(
            [row for row in trace if not math.isfinite(row["loss"])]
        ),
        "observations": problem.observations,
        "baseline_predictions": baseline.predictions,
        "best_predictions": best.predictions,
        "trace": pd.DataFrame(trace),
        "starts": fitted.starts
        if fitted
        else pd.DataFrame(columns=["start", "status"]),
    }


def _metric_rmse_by_trait(
    problem: CalibrationProblem,
    predictions: pd.DataFrame,
    *,
    model: str,
    cultivar: str = "synthetic",
    scheme: str = "candidate",
) -> dict[str, dict[str, float]]:
    frame = _predictions(
        problem.observations,
        predictions,
        model=model,
        cultivar=cultivar,
        scheme=scheme,
    )
    metrics = trait_metrics(frame)
    return {
        str(row["variable"]): {"rmse": float(row["rmse"])}
        for row in metrics.to_dict("records")
        if np.isfinite(row["rmse"])
    }


def select_final_candidate(
    *,
    prior_loss: float,
    candidate_loss: float,
    prior_metrics: Mapping[str, Mapping[str, float]],
    candidate_metrics: Mapping[str, Mapping[str, float]],
) -> tuple[bool, str]:
    """Prespecified engineering replacement rule, not a significance test."""
    if not math.isfinite(candidate_loss):
        return False, "no_complete_candidate"
    if not math.isfinite(prior_loss) or candidate_loss > prior_loss * 0.99:
        return False, "insufficient_loss_improvement"
    flower_traits = [
        name for name in ("pollen_dap", "silk_dap") if name in prior_metrics
    ]
    yield_traits = [
        name for name in ("dry_yield_mg_ha",) if name in prior_metrics
    ]
    for traits, reason in (
        (flower_traits, "flower_rmse_degradation"),
        (yield_traits, "yield_rmse_degradation"),
    ):
        for name in traits:
            if name not in candidate_metrics:
                return False, reason
            prior_rmse = float(prior_metrics[name]["rmse"])
            candidate_rmse = float(candidate_metrics[name]["rmse"])
            if not math.isfinite(candidate_rmse) or candidate_rmse > prior_rmse * 1.02:
                return False, reason
    return True, "accepted"


def _final_parameters(
    specs: Sequence[ParameterSpec], parameters: Mapping[str, float]
) -> dict[str, float]:
    result = {spec.name: float(spec.prior) for spec in specs}
    for name, value in parameters.items():
        if name in result:
            result[name] = float(value)
    return result


def _best_trace_evaluation(
    problem: CalibrationProblem,
    trace: Sequence[Mapping[str, Any]],
) -> tuple[float, dict[str, float], pd.DataFrame]:
    finite = [row for row in trace if math.isfinite(float(row["loss"]))]
    if not finite:
        return math.inf, {}, pd.DataFrame()
    row = min(
        finite,
        key=lambda item: (float(item["loss"]), json.dumps(item["parameters"])),
    )
    return (
        float(row["loss"]),
        dict(row["parameters"]),
        problem.cache[row["evaluation_key"]].predictions,
    )


def final_search(
    problem: CalibrationProblem,
    specs: Sequence[ParameterSpec],
    *,
    model: str,
    prior: Mapping[str, Any],
    cultivar: str = "synthetic",
) -> dict[str, Any]:
    """One finite, precision-aware final round warm-started from the 96-request fit."""
    budget = FINAL_BUDGETS[model]
    started = time.monotonic()
    by_name = {spec.name: spec for spec in specs}
    if any(
        name not in by_name or by_name[name].role == "fixed"
        for name in ACTIVE[model]
    ):
        raise ValueError("final active set is incompatible with parameter specs")
    if problem.cache is None:
        problem.cache = {}
    prior_parameters = _final_parameters(specs, prior["parameters"])
    reference_parameters = _final_parameters(
        specs, prior.get("reference", prior["parameters"])
    )
    for name in ACTIVE[model]:
        spec = by_name[name]
        for label, value in (
            ("prior", prior_parameters),
            ("reference", reference_parameters),
        ):
            if not spec.lower <= value[name] <= spec.upper:
                raise ValueError(f"out-of-bound {label} final start: {name}")

    reference = problem.evaluate(
        reference_parameters, context="final/screen/reference"
    )
    problem.evaluate(prior_parameters, context="final/screen/prior")
    for name in PROBE_ORDER[model]:
        spec = by_name[name]
        span = spec.upper - spec.lower
        for direction in (-1, 1):
            candidate = prior_parameters.copy()
            candidate[name] = min(
                spec.upper,
                max(
                    spec.lower,
                    prior_parameters[name] + direction * 0.10 * span,
                ),
            )
            problem.evaluate(
                candidate, context=f"final/screen/probe/{name}/{direction:+d}"
            )
    lhs_count = FINAL_SCREENING_REQUESTS - len(problem.trace)
    if lhs_count < 0:
        raise RuntimeError("final screening budget exceeded")
    if lhs_count:
        active = ACTIVE[model]
        lower = np.array([by_name[name].lower for name in active], dtype=float)
        span = np.array(
            [by_name[name].upper - by_name[name].lower for name in active], dtype=float
        )
        draws = qmc.LatinHypercube(d=len(active), seed=FINAL_SEED).random(lhs_count)
        for index, draw in enumerate(draws):
            candidate = prior_parameters.copy()
            candidate.update(
                dict(zip(active, (lower + span * draw).tolist()))
            )
            problem.evaluate(candidate, context=f"final/screen/lhs/{index:03d}")
    if len(problem.trace) != FINAL_SCREENING_REQUESTS:
        raise RuntimeError("final screening request count mismatch")

    screening_trace = problem.trace[:FINAL_SCREENING_REQUESTS]
    distinct_candidates = []
    seen = {tuple(prior_parameters[name] for name in ACTIVE[model])}
    for row in screening_trace:
        if not math.isfinite(float(row["loss"])):
            continue
        identity = tuple(row["parameters"][name] for name in ACTIVE[model])
        if identity in seen:
            continue
        seen.add(identity)
        distinct_candidates.append((float(row["loss"]), identity, row["parameters"]))
    distinct_candidates.sort(key=lambda item: (item[0], item[1]))
    starts = [prior_parameters.copy()]
    for _, _, parameters in distinct_candidates:
        candidate = _final_parameters(specs, parameters)
        if candidate not in starts:
            starts.append(candidate.copy())
        if len(starts) == FINAL_START_COUNT:
            break

    start_frames = []
    for start_index, start_parameters in enumerate(starts):
        remaining = budget - len(problem.trace)
        starts_left = len(starts) - start_index
        allocated = (
            remaining
            if start_index == len(starts) - 1
            else max(0, remaining // starts_left)
        )
        order = tuple(
            PROBE_ORDER[model][(index + start_index) % len(PROBE_ORDER[model])]
            for index in range(len(PROBE_ORDER[model]))
        )
        trace_before_start = len(problem.trace)
        initial = problem.evaluate(
            start_parameters, context=f"final/start-{start_index}/initial"
        )
        local_best_loss, local_best = initial.loss, start_parameters.copy()
        for name in order:
            spec = by_name[name]
            span = spec.upper - spec.lower
            for direction in (-1, 1):
                candidate = start_parameters.copy()
                candidate[name] = min(
                    spec.upper,
                    max(
                        spec.lower,
                        start_parameters[name] + direction * 0.10 * span,
                    ),
                )
                evaluation = problem.evaluate(
                    candidate,
                    context=f"final/start-{start_index}/probe/{name}/{direction:+d}",
                )
                if math.isfinite(evaluation.loss) and evaluation.loss < local_best_loss:
                    local_best_loss, local_best = evaluation.loss, candidate.copy()
        used = len(problem.trace) - trace_before_start
        fitted = None
        if math.isfinite(local_best_loss) and allocated > used:
            fitted = fit(
                problem,
                specs,
                active=order,
                n_starts=1,
                seed=FINAL_SEED,
                initial=local_best,
                max_nfev=allocated - used,
                method="Powell",
                xtol=FINAL_XTOL,
                ftol=FINAL_FTOL,
                parameter_precision=FINAL_DSSAT_PRECISION
                if model == "dssat"
                else None,
                context=f"final/powell/start-{start_index}",
            )
            frame = fitted.starts.copy()
            frame["final_start"] = start_index
            frame["allocated_requests"] = allocated
            frame["probe_requests"] = used
            start_frames.append(frame)
        else:
            start_frames.append(
                pd.DataFrame(
                    [
                        {
                            "start": 0,
                            "loss": local_best_loss,
                            "converged": False,
                            "nfev": 0,
                            "budget_exhausted": allocated <= used,
                            "effective_refit": False,
                            "initial_only": math.isfinite(local_best_loss),
                            "initial_loss": initial.loss,
                            "initial_status": initial.status,
                            "status": (
                                "budget_exhausted"
                                if allocated <= used
                                else initial.status
                            ),
                            "parameters": local_best,
                            "message": "insufficient budget after start probes",
                            "final_start": start_index,
                            "allocated_requests": allocated,
                            "probe_requests": used,
                        }
                    ]
                )
            )
        if len(problem.trace) > budget:
            raise RuntimeError("final request budget exceeded")

    trace = problem.trace
    search_loss, search_parameters, search_predictions = _best_trace_evaluation(
        problem, trace
    )
    prior_predictions = prior["best_predictions"]
    prior_loss = problem.score_predictions(prior_predictions).loss
    prior_metrics = _metric_rmse_by_trait(
        problem, prior_predictions, model=model, cultivar=cultivar, scheme="prior_96"
    )
    search_metrics = (
        _metric_rmse_by_trait(
            problem,
            search_predictions,
            model=model,
            cultivar=cultivar,
            scheme="final_search",
        )
        if not search_predictions.empty
        else {}
    )
    accepted, reason = select_final_candidate(
        prior_loss=prior_loss,
        candidate_loss=search_loss,
        prior_metrics=prior_metrics,
        candidate_metrics=search_metrics,
    )
    if accepted:
        selected_parameters, selected_predictions, selected_loss = (
            search_parameters,
            search_predictions,
            search_loss,
        )
    else:
        selected_parameters, selected_predictions, selected_loss = (
            prior_parameters,
            prior_predictions,
            prior_loss,
        )
    movements = {
        name: {
            "prior": prior_parameters[name],
            "search": search_parameters.get(name),
            "selected": selected_parameters[name],
            "delta_from_prior": selected_parameters[name] - prior_parameters[name],
            "span_fraction": (selected_parameters[name] - prior_parameters[name])
            / (by_name[name].upper - by_name[name].lower),
        }
        for name in ACTIVE[model]
    }
    starts_frame = (
        pd.concat(start_frames, ignore_index=True)
        if start_frames
        else pd.DataFrame(columns=["final_start"])
    )
    return {
        **PRELIMINARY,
        "search_status": "complete_candidate"
        if math.isfinite(search_loss)
        else "no_complete_candidate",
        "selected_status": "accepted" if accepted else "retained_prior_96",
        "selection_reason": reason,
        "reference": reference_parameters,
        "prior_parameters": prior_parameters,
        "parameters": selected_parameters,
        "search_parameters": search_parameters,
        "active": list(ACTIVE[model]),
        "reference_loss": reference.loss if math.isfinite(reference.loss) else None,
        "prior_loss": prior_loss if math.isfinite(prior_loss) else None,
        "search_best_loss": search_loss if math.isfinite(search_loss) else None,
        "best_loss": selected_loss if math.isfinite(selected_loss) else None,
        "evaluation_requests": len(trace),
        "max_evaluations": budget,
        "screening_requests": FINAL_SCREENING_REQUESTS,
        "probe_requests": sum(
            2 * len(ACTIVE[model]) for _ in range(len(starts))
        ),
        "fit_requests": len(trace) - FINAL_SCREENING_REQUESTS,
        "cached_requests": sum(bool(row["cached"]) for row in trace),
        "budget_exhausted": len(trace) == budget,
        "parameter_movements": movements,
        "elapsed_seconds": time.monotonic() - started,
        "target_hash": problem.target_hash,
        "expected_count": len(problem.observations),
        "scales": problem.scales,
        "scale_details": problem.scale_details,
        "starts": starts_frame,
        "converged": bool(
            not starts_frame.empty and starts_frame["converged"].any()
        ),
        "effective_refit": accepted,
        "failed_candidates": _jsonable(
            [row for row in trace if not math.isfinite(float(row["loss"]))]
        ),
        "observations": problem.observations,
        "baseline_predictions": reference.predictions,
        "prior_predictions": prior_predictions,
        "search_best_predictions": search_predictions,
        "best_predictions": selected_predictions,
        "trace": pd.DataFrame(trace),
    }


def combination_identity(
    protocol: Mapping[str, Any],
    model: str,
    cultivar: str,
    target_hash: str,
    namespace: str,
) -> str:
    return _seal(
        {
            "quick_protocol_sha256": protocol["sha256"],
            "model": model,
            "cultivar_id": cultivar,
            "target_hash": target_hash,
            "native_namespace": namespace,
        }
    )["sha256"]


def _quick_directory(config: ExperimentConfig, name: str) -> Path:
    """Constrain extended quick rounds to one explicit experiment subdirectory."""
    if (
        not isinstance(name, str)
        or not name
        or Path(name).name != name
        or name in {".", ".."}
    ):
        raise ValueError("quick-directory must be a single safe directory name")
    return config.experiment_dir / name


def _artifact_path(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("artifact path escapes experiment")
    return path


def _verify_artifacts(root: Path, hashes: Mapping[str, Any]) -> None:
    for relative, expected in hashes.items():
        path = _artifact_path(root, relative)
        actual = sha256_file(path) if path.is_file() else None
        if actual != expected:
            raise ValueError(f"artifact digest mismatch: {relative}")


def resume_result(directory: Path, identity: str) -> dict[str, Any] | None:
    path = directory / "result.json"
    if not path.is_file():
        return None
    result = _verify_seal(_read_json(path))
    if result.get("identity") != identity:
        raise ValueError("quick result identity mismatch")
    binding = _seal(
        {
            key: value
            for key, value in result.items()
            if key not in {"sha256", "result_identity"}
        }
    )["sha256"]
    if result.get("result_identity") != binding:
        raise ValueError("quick parameter/artifact result identity mismatch")
    if any(result.get(key) != value for key, value in PRELIMINARY.items()):
        raise ValueError("quick preliminary scope identity mismatch")
    _verify_artifacts(directory, result["artifact_sha256"])
    return result


def _predictions(
    observations: pd.DataFrame,
    predictions: pd.DataFrame,
    *,
    model: str,
    cultivar: str,
    scheme: str,
) -> pd.DataFrame:
    """Pad missing predictions, preserving every frozen target and failure."""
    frame = observations.set_index("observation_id").copy()
    if not predictions.empty:
        predicted = predictions.set_index("observation_id").reindex(frame.index)
        for name in predicted:
            frame[name] = predicted[name]
    frame = frame.reset_index()
    if "variable" not in frame:
        frame["variable"] = frame["trait"]
    frame["observed_value"] = (
        observations.set_index("observation_id")["value"]
        .reindex(
            frame["observation_id"],
        )
        .to_numpy()
    )
    defaults = {
        "predicted_value": float("nan"),
        "status": "missing_prediction",
        "event_valid": False,
        "forced_maturity": False,
        "natural_maturity": False,
        "year": "unknown",
        "site_id": "unknown",
        "input_tier": "unknown",
        "irrigation_assumption": "unknown",
    }
    for name, default in defaults.items():
        if name not in frame:
            frame[name] = default
    frame["event_valid"] = frame["event_valid"].fillna(False)
    frame["model"], frame["cultivar_id"], frame["scheme"] = model, cultivar, scheme
    frame["primary_target"] = True
    return frame


def _append_attempt_trace(
    path: Path,
    rows: Iterable[Mapping[str, Any]],
    attempt_id: str,
    *,
    first_request: int = 1,
) -> None:
    # Preserve even an interrupted partial last line; never truncate old bytes.
    needs_newline = False
    if path.is_file() and path.stat().st_size:
        with path.open("rb") as previous:
            previous.seek(-1, os.SEEK_END)
            needs_newline = previous.read(1) != b"\n"
    with path.open("a", encoding="utf-8") as stream:
        if needs_newline:
            stream.write("\n")
        for index, row in enumerate(rows, first_request):
            stream.write(
                json.dumps(
                    _jsonable(
                        {
                            **row,
                            "attempt_id": attempt_id,
                            "request_index": index,
                        }
                    ),
                    allow_nan=False,
                )
                + "\n"
            )


def save_result(
    directory: Path,
    *,
    identity: str,
    protocol_sha256: str,
    model: str,
    cultivar: str,
    search: Mapping[str, Any],
) -> dict[str, Any]:
    previous = resume_result(directory, identity)
    if previous is not None:
        return previous
    directory.mkdir(parents=True, exist_ok=True)
    frames = []
    prediction_schemes = (
        (
            ("reference", "baseline_predictions"),
            ("prior_96", "prior_predictions"),
            ("final_search", "search_best_predictions"),
            ("final_selected", "best_predictions"),
        )
        if "prior_predictions" in search
        else (
            ("reference", "baseline_predictions"),
            ("quick_best", "best_predictions"),
        )
    )
    for scheme, key in prediction_schemes:
        frame = _predictions(
            search["observations"],
            search[key],
            model=model,
            cultivar=cultivar,
            scheme=scheme,
        )
        frames.append(frame)
        _write_table(directory / f"{key}.parquet", frame)
    metrics = trait_metrics(pd.concat(frames, ignore_index=True))
    _write_table(directory / "metrics.csv", metrics)
    _write_table(directory / "starts.csv", search["starts"])
    attempt_id = str(search.get("attempt_id", uuid.uuid4().hex))
    ledger = directory / "search.jsonl"
    if not search.get("trace_recorded", False):
        _append_attempt_trace(ledger, search["trace"].to_dict("records"), attempt_id)
    all_records, unparsed = [], 0
    for line in ledger.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
            if not isinstance(row, dict) or "evaluation_key" not in row:
                raise ValueError("not an evaluation record")
        except (ValueError, TypeError):
            unparsed += 1
        else:
            all_records.append(row)
    current_count = sum(row.get("attempt_id") == attempt_id for row in all_records)
    if current_count != search["evaluation_requests"]:
        raise ValueError("current attempt trace/request count mismatch")
    _write_table(directory / "trace.csv", pd.DataFrame(all_records))
    omitted = {
        "observations",
        "baseline_predictions",
        "prior_predictions",
        "search_best_predictions",
        "best_predictions",
        "trace",
        "starts",
        "trace_recorded",
    }
    body = {
        **{key: value for key, value in search.items() if key not in omitted},
        "schema": "quick_cultivar_result_v1",
        "identity": identity,
        "quick_protocol_sha256": protocol_sha256,
        "model": model,
        "cultivar_id": cultivar,
        "attempt_id": attempt_id,
        "attempt_count": len(
            {row.get("attempt_id", "legacy_interrupted_attempt") for row in all_records}
        ),
        "evaluation_requests_this_invocation": current_count,
        "cumulative_evaluation_requests": len(all_records),
        "prior_evaluation_requests": len(all_records) - current_count,
        "unparsed_ledger_lines": unparsed,
        "cumulative_request_count_complete": unparsed == 0,
        "failed_candidates_all_attempts": [
            row for row in all_records if row.get("status") != "valid"
        ],
        "effective_native_parameters": effective_native_parameters(
            model, search["parameters"]
        ),
        "reference_effective_native_parameters": effective_native_parameters(
            model, search["reference"]
        ),
        "metrics": _frame_records(metrics),
        "artifact_sha256": {
            name: sha256_file(directory / name)
            for name in (
                *(f"{key}.parquet" for _, key in prediction_schemes),
                "metrics.csv",
                "trace.csv",
                "starts.csv",
                "search.jsonl",
                *(
                    ("targets_and_weights.json",)
                    if (directory / "targets_and_weights.json").is_file()
                    else ()
                ),
            )
        },
    }
    result = _seal({**body, "result_identity": _seal(body)["sha256"]})
    _write_immutable_json(directory / "result.json", result)
    return result


def _native_prediction_cache_key(
    namespace: str, parameters: Mapping[str, float]
) -> str:
    payload = {"namespace": namespace, "parameters": dict(parameters)}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def _seed_predictions_from_ledger(
    problem: CalibrationProblem,
    ledger: Path,
    *,
    namespace: str,
    cache_root: Path,
) -> int:
    """Warm interrupted final points from the shared, identity-keyed cache."""
    if problem.cache is None:
        raise ValueError("cache seeding requires an enabled cache")
    seeded = 0
    for row in _read_prior_ledger(ledger):
        key = _native_prediction_cache_key(namespace, row["parameters"])
        prediction_path = cache_root / f"{key}.parquet"
        if not prediction_path.is_file():
            continue
        problem.seed_cache(row["parameters"], pd.read_parquet(prediction_path))
        seeded += 1
    return seeded


def _read_prior_ledger(path: Path) -> list[dict[str, Any]]:
    """Read legacy quick ledgers whose file digest is sealed by result.json."""
    rows = []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            try:
                row = json.loads(line)
                if (
                    not isinstance(row, dict)
                    or "evaluation_key" not in row
                    or "parameters" not in row
                    or "loss" not in row
                    or "status" not in row
                ):
                    raise ValueError("not an evaluation record")
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                raise ValueError(f"invalid prior evaluation record: {exc}") from exc
            rows.append(row)
    return rows


def _copy_prior_result(
    config: ExperimentConfig,
    *,
    prior_experiment_id: str,
    model: str,
    cultivar: str,
) -> dict[str, Any]:
    """Copy sealed 96-request outputs and their processed prediction cache."""
    source_root = config.experiment_dir.parent / prior_experiment_id
    source = source_root / "quick_calibration_96" / model / _safe_id(cultivar)
    result = resume_result(source, _read_json(source / "result.json")["identity"])
    task = _verify_seal(_read_json(source / "task.json"))
    if task["model"] != model or task["cultivar_id"] != cultivar:
        raise ValueError("prior task identity mismatch")
    destination = (
        config.experiment_dir / "prior_results" / model / _safe_id(cultivar)
    )
    destination.mkdir(parents=True, exist_ok=True)
    copied: dict[str, str | None] = {}
    for relative, expected in result["artifact_sha256"].items():
        source_path = source / relative
        destination_path = destination / relative
        if not destination_path.exists():
            shutil.copyfile(source_path, destination_path)
        if sha256_file(destination_path) != expected:
            raise ValueError(f"copied prior artifact digest mismatch: {relative}")
        copied[relative] = expected
    for name in ("result.json", "task.json"):
        destination_path = destination / name
        if not destination_path.exists():
            shutil.copyfile(source / name, destination_path)
        copied[name] = sha256_file(destination_path)

    cache_destination = (
        config.experiment_dir
        / "prior_prediction_cache"
        / model
        / _safe_id(cultivar)
    )
    cache_destination.mkdir(parents=True, exist_ok=True)
    cache_keys = []
    for row in _read_prior_ledger(destination / "search.jsonl"):
        key = _native_prediction_cache_key(task["namespace"], row["parameters"])
        source_prediction = source_root / "prediction_cache" / f"{key}.parquet"
        source_metadata = source_root / "prediction_cache" / f"{key}.json"
        if not source_prediction.is_file() or not source_metadata.is_file():
            continue
        metadata = _verify_seal(_read_json(source_metadata))
        prediction_destination = cache_destination / f"{key}.parquet"
        metadata_destination = cache_destination / f"{key}.json"
        if not prediction_destination.exists():
            shutil.copyfile(source_prediction, prediction_destination)
        if not metadata_destination.exists():
            shutil.copyfile(source_metadata, metadata_destination)
        if (
            sha256_file(prediction_destination)
            != metadata["parquet_sha256"]
            or _verify_seal(_read_json(metadata_destination)) != metadata
        ):
            raise ValueError("copied prior prediction cache identity mismatch")
        cache_keys.append(key)
    return _seal(
        {
            "source_experiment_id": prior_experiment_id,
            "source_result_sha256": result["sha256"],
            "source_task_sha256": task["sha256"],
            "source_quick_directory": "quick_calibration_96",
            "destination": str(destination.relative_to(config.experiment_dir)),
            "copied_artifact_sha256": copied,
            "prediction_cache_keys": sorted(set(cache_keys)),
        }
    )


def _seed_final_problem_from_prior(
    problem: CalibrationProblem,
    *,
    model: str,
    cultivar: str,
    config: ExperimentConfig,
) -> dict[str, Any]:
    """Warm verified old points; no trace/request is emitted during seeding."""
    directory = (
        config.experiment_dir / "prior_results" / model / _safe_id(cultivar)
    )
    result = resume_result(directory, _read_json(directory / "result.json")["identity"])
    task = _verify_seal(_read_json(directory / "task.json"))
    cache_root = (
        config.experiment_dir
        / "prior_prediction_cache"
        / model
        / _safe_id(cultivar)
    )
    seeded = 0
    for row in _read_prior_ledger(directory / "search.jsonl"):
        key = _native_prediction_cache_key(task["namespace"], row["parameters"])
        prediction_path = cache_root / f"{key}.parquet"
        if not prediction_path.is_file():
            continue
        problem.seed_cache(row["parameters"], pd.read_parquet(prediction_path))
        seeded += 1
    # These two sealed artifacts are authoritative even if a ledger row was absent.
    problem.seed_cache(
        result["parameters"], pd.read_parquet(directory / "best_predictions.parquet")
    )
    problem.seed_cache(
        result["reference"],
        pd.read_parquet(directory / "baseline_predictions.parquet"),
    )
    return {
        "prior_result_sha256": result["sha256"],
        "prior_task_sha256": task["sha256"],
        "seeded_prediction_cache_points": seeded,
    }


def _restore_baseline_from_prior(
    config: ExperimentConfig, prior_experiment_id: str
) -> dict[str, Any]:
    """Reuse verified reference predictions, then rebind them to this experiment."""
    source_root = config.experiment_dir.parent / prior_experiment_id
    source_baseline = _verify_seal(
        _read_json(source_root / "manifests/baseline.json")
    )
    _verify_artifacts(source_root, source_baseline["artifact_sha256"])
    root = config.experiment_dir
    restore_relatives = [
        *source_baseline["artifact_sha256"],
        "baseline/metrics.csv",
    ]
    for relative in restore_relatives:
        destination = root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            shutil.copyfile(source_root / relative, destination)
        expected = source_baseline["artifact_sha256"].get(relative)
        if expected is not None and sha256_file(destination) != expected:
            raise ValueError(f"restored baseline artifact digest mismatch: {relative}")
    protocol = _verify_seal(_read_json(root / "manifests/training_protocol.json"))
    tables = _training_tables(config, protocol)
    bindings = {}
    for cultivar in _selected(config)["cultivar_id"]:
        requests, observations = _requests(config, tables, cultivar, TRAINING_YEARS)
        for model in _models(config):
            evaluator = NativeEvaluator(
                config, model, requests, observations, label="baseline_reuse_binding"
            )
            relative = f"baseline/{model.name}/{_safe_id(cultivar)}.parquet"
            predictions = pd.read_parquet(root / relative)
            expected_ids = set(evaluator.observations["observation_id"])
            if (
                predictions["observation_id"].duplicated().any()
                or set(predictions["observation_id"]) != expected_ids
            ):
                raise ValueError(
                    "restored baseline prediction target identity mismatch: "
                    f"{model.name}/{cultivar}"
                )
            bindings[relative] = {
                "namespace": evaluator.namespace,
                "reference_parameters": _reference_parameters(model.name),
            }
    baseline = _seal(
        {
            "training_protocol_sha256": protocol["sha256"],
            "combinations": bindings,
            "artifact_sha256": {
                relative: sha256_file(root / relative)
                for relative in (
                    *bindings,
                    "baseline/predictions.parquet",
                    "baseline/metrics.csv",
                )
            },
            "restored_from": {
                "experiment_id": prior_experiment_id,
                "baseline_sha256": source_baseline["sha256"],
                "reason": (
                    "verified reference predictions reused; namespace rebound to "
                    "this experiment's output path and current processing identity"
                ),
            },
        }
    )
    _write_immutable_json(root / "manifests/baseline.json", baseline)
    freeze_training_eligibility(config, tables)
    return baseline


def _training_tables(
    config: ExperimentConfig, protocol: Mapping[str, Any]
) -> dict[str, pd.DataFrame]:
    """Filter training labels at read time, preserving native parquet precision."""
    frozen_units = pd.DataFrame(protocol["training_units"])
    frozen_observations = pd.DataFrame(protocol["training_observations"])
    units = pd.read_parquet(
        config.experiment_dir / "normalized/cultivar_units.parquet",
        filters=[("year", "in", list(TRAINING_YEARS))],
    )
    observations = pd.read_parquet(
        config.experiment_dir / "normalized/cultivar_observations.parquet",
        filters=[("year", "in", list(TRAINING_YEARS))],
    )
    unit_ids = frozen_units["management_unit_id"].tolist()
    observation_ids = frozen_observations["observation_id"].tolist()
    if (
        units["management_unit_id"].duplicated().any()
        or observations["observation_id"].duplicated().any()
    ):
        raise ValueError("prepared training IDs must be unique")
    try:
        units = units.set_index("management_unit_id").loc[unit_ids].reset_index()
        observations = (
            observations.set_index("observation_id").loc[observation_ids].reset_index()
        )
    except KeyError as exc:
        raise ValueError("frozen training IDs lack prepared inputs") from exc
    if (
        _frame_records(units) != protocol["training_units"]
        or _frame_records(observations) != protocol["training_observations"]
    ):
        raise ValueError("prepared training inputs differ from frozen protocol")
    if (
        units.empty
        or observations.empty
        or not units["year"].isin(TRAINING_YEARS).all()
    ):
        raise ValueError("prepared protocol must contain nonempty training-only inputs")
    if not observations["management_unit_id"].isin(
        units["management_unit_id"]
    ).all() or (
        "year" in observations and not observations["year"].isin(TRAINING_YEARS).all()
    ):
        raise ValueError("holdout labels are not allowed in quick training tasks")
    return {
        "units": units,
        "observations": observations,
        **{
            name: pd.read_parquet(
                config.experiment_dir / "normalized" / f"{stem}.parquet"
            )
            for name, stem in (
                ("environments", "environments"),
                ("weather", "weather"),
                ("soil", "soil_layers"),
            )
        },
    }


def prepare_tasks(
    config: ExperimentConfig,
    *,
    max_evaluations: int,
    core_only: bool,
    quick_directory: str = "quick_calibration",
    search_mode: str = "quick",
    prior_experiment_id: str = "",
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Read-only full preflight before publishing anything under quick_calibration."""
    root = config.experiment_dir
    if search_mode not in {"quick", "final"}:
        raise ValueError("search mode must be quick or final")
    if search_mode == "final" and not prior_experiment_id:
        raise ValueError("final search requires a verified prior experiment ID")
    if search_mode == "final" and not all(
        (root / "manifests" / f"{name}.json").is_file()
        for name in ("baseline", "training_eligibility")
    ):
        _restore_baseline_from_prior(config, prior_experiment_id)
    documents = {}
    for name in (
        "cultivar_prepare",
        "training_protocol",
        "baseline",
        "training_eligibility",
    ):
        path = root / "manifests" / f"{name}.json"
        if not path.is_file():
            raise ValueError(
                f"verified prepare/baseline/mask manifest required: {path}"
            )
        documents[name] = _verify_seal(_read_json(path))
    prepared, training, baseline, mask = (
        documents[name]
        for name in (
            "cultivar_prepare",
            "training_protocol",
            "baseline",
            "training_eligibility",
        )
    )
    settings = _settings(config)
    if (
        prepared["settings"] != _jsonable(settings)
        or training["settings"] != _jsonable(settings)
        or prepared["protocol_sha256"] != training["sha256"]
        or baseline["training_protocol_sha256"] != training["sha256"]
        or mask["training_protocol_sha256"] != training["sha256"]
        or mask["baseline_sha256"] != baseline["sha256"]
        or prepared["preparation_code"] != _preparation_code_fingerprints()
    ):
        raise ValueError("prepared/baseline/mask/config/code identity mismatch")
    if prepared["source_inventory"] != build_source_inventory(source_paths(config)):
        raise ValueError("prepared raw input fingerprints changed")
    snapshot = root / "config.yaml"
    if not snapshot.is_file() or _snapshot_document(
        load_config(snapshot)
    ) != _snapshot_document(config):
        raise ValueError("verified prepared config snapshot required")
    for document in (prepared, baseline):
        _verify_artifacts(root, document["artifact_sha256"])
    _verify_artifacts(root, prepared.get("external_input_sha256", {}))
    source = prepared.get("prepared_source")
    if source:
        historical = root.parent / source["experiment_id"]
        original = _verify_seal(
            _read_json(historical / "manifests/cultivar_prepare.json")
        )
        if original["sha256"] != source["sha256"]:
            raise ValueError("historical prepared identity changed")
        _verify_artifacts(historical, source["copied_artifact_sha256"])
    if mask["site_folds_sha256"] is not None:
        folds = _verify_seal(_read_json(root / "manifests/site_folds.json"))
        if folds["sha256"] != mask["site_folds_sha256"]:
            raise ValueError("training site fold identity changed")
    tables = _training_tables(config, training)
    selected = _selected(config)
    if (
        selected["selection_rank"].duplicated().any()
        or int(selected.iloc[0]["selection_rank"]) != 1
    ):
        raise ValueError("frozen cultivar ranks must be unique and start at 1")
    models = _models(config)
    for model in models:
        if search_mode == "quick":
            _budget(model.name, max_evaluations)
        elif max_evaluations != FINAL_BUDGETS[model.name]:
            # The final protocol is intentionally model-specific and immutable.
            pass
    specs = {
        model.name: final_round_parameter_catalog(model.name)
        if search_mode == "final"
        else _specs_and_candidates(model.name, pragmatic=True)[0]
        for model in models
    }
    prototypes = []
    for row in selected.to_dict("records"):
        cultivar = str(row["cultivar_id"])
        requests, observations = _requests(config, tables, cultivar, TRAINING_YEARS)
        for model in models:
            full = NativeEvaluator(
                config, model, requests, observations, label="quick_preflight"
            )
            relative = f"baseline/{model.name}/{_safe_id(cultivar)}.parquet"
            binding = baseline["combinations"][relative]
            if binding != {
                "namespace": full.namespace,
                "reference_parameters": _reference_parameters(model.name),
            }:
                raise ValueError(
                    "baseline native code/engine/input/reference identity changed"
                )
            expected_mask = training_eligibility(
                observations,
                pd.read_parquet(root / relative),
                model=model.name,
                cultivar=cultivar,
                provenance={
                    "baseline_sha256": baseline["sha256"],
                    "prediction_sha256": baseline["artifact_sha256"][relative],
                    **binding,
                },
            )
            matches = [
                item
                for item in mask["combinations"]
                if item["model"] == model.name and item["cultivar_id"] == cultivar
            ]
            if len(matches) != 1 or _verify_seal(matches[0]) != expected_mask:
                raise ValueError(
                    "frozen training mask differs from full native baseline"
                )
            retained_requests, targets = training_inputs(
                config, model, requests, observations
            )
            if targets.empty:
                raise ValueError(
                    f"no retained fixed targets for {model.name}/{cultivar}"
                )
            evaluator = NativeEvaluator(
                config, model, retained_requests, targets, label="quick"
            )
            targets = evaluator.observations.copy()
            targets["site"] = targets["site_id"].astype(str)
            problem = CalibrationProblem(
                targets, evaluator, cache={}, cache_namespace=evaluator.namespace
            )
            prototypes.append((row, model, problem, evaluator))
    prior_results = {}
    if search_mode == "final":
        for row in selected.to_dict("records"):
            cultivar = str(row["cultivar_id"])
            for model in models:
                prior_results[f"{model.name}/{cultivar}"] = _copy_prior_result(
                    config,
                    prior_experiment_id=prior_experiment_id,
                    model=model.name,
                    cultivar=cultivar,
                )
    code_root = Path(__file__).resolve().parents[1] / "src/snowwindow"
    protocol = _seal(
        {
            "schema": (
                "prespecified_final_bounded_training_protocol_v1"
                if search_mode == "final"
                else "prespecified_quick_training_protocol_v1"
            ),
            "quick_directory": quick_directory,
            **PRELIMINARY,
            "search_mode": search_mode,
            "max_evaluations": (
                FINAL_BUDGETS if search_mode == "final" else max_evaluations
            ),
            "algorithm": (
                "32-point screening from the sealed 96-request optimum; "
                "up to three valid starts; two +/-0.10-span probes per coordinate "
                "at every start; bounded Powell with native precision"
                if search_mode == "final"
                else "native reference; bounded +/-0.10 span coordinates; "
                "one-start bounded Powell"
            ),
            "probe_order": PROBE_ORDER,
            "active_parameters": ACTIVE,
            "priors_and_bounds": {
                name: [asdict(spec) for spec in values]
                for name, values in specs.items()
            },
            "reference_parameters": {
                model.name: _reference_parameters(model.name) for model in models
            },
            "seed": FINAL_SEED if search_mode == "final" else 20261111,
            "screening_requests": (
                FINAL_SCREENING_REQUESTS if search_mode == "final" else None
            ),
            "start_count": FINAL_START_COUNT if search_mode == "final" else 1,
            "xtol": FINAL_XTOL if search_mode == "final" else 1e-7,
            "ftol": FINAL_FTOL if search_mode == "final" else 1e-10,
            "dssat_parameter_precision": (
                FINAL_DSSAT_PRECISION if search_mode == "final" else None
            ),
            "replacement_rule": (
                {
                    "minimum_relative_loss_improvement": 0.01,
                    "maximum_relative_flower_rmse_degradation": 0.02,
                    "maximum_relative_yield_rmse_degradation": 0.02,
                    "otherwise": "retain_prior_96",
                }
                if search_mode == "final"
                else None
            ),
            "prior_experiment_id": (
                prior_experiment_id if search_mode == "final" else None
            ),
            "prior_results": prior_results if search_mode == "final" else None,
            "maxiter": 300,
            "budget_rule": (
                "final: 32 screening requests + up to three start probe/Powell "
                "requests; hard model-specific cap; cache hits count"
                if search_mode == "final"
                else "reference + two probes per coordinate + all fit requests; "
                "cache hits count"
            ),
            "target_rule": (
                "complete frozen primary targets; infinite loss for any failed target"
            ),
            "training_years": TRAINING_YEARS,
            "formal_config_sha256": _seal(_snapshot_document(config))["sha256"],
            "immutable_identities": {
                name: doc["sha256"] for name, doc in documents.items()
            },
            "site_folds_sha256": mask["site_folds_sha256"],
            "engines": {
                model.name: {
                    "version": model.version,
                    "sources": _engine_fingerprints(model),
                }
                for model in models
            },
            "code": {
                str(path.relative_to(code_root)): sha256_file(path)
                for path in sorted(code_root.rglob("*.py"))
            },
            "runner_sha256": sha256_file(Path(__file__)),
            # Core/parallel execution flags do not invalidate completed resumes.
            "cultivars": _frame_records(selected[["cultivar_id", "selection_rank"]]),
        }
    )
    quick = _quick_directory(config, quick_directory)
    _write_immutable_json(quick / "protocol.json", protocol)
    tasks = []
    for row, model, problem, evaluator in prototypes:
        if core_only and int(row["selection_rank"]) != 1:
            continue
        cultivar = str(row["cultivar_id"])
        directory = quick / model.name / _safe_id(cultivar)
        task = _seal(
            {
                "model": model.name,
                "cultivar_id": cultivar,
                "selection_rank": int(row["selection_rank"]),
                "directory": str(directory),
                "identity": combination_identity(
                    protocol,
                    model.name,
                    cultivar,
                    problem.target_hash,
                    evaluator.namespace,
                ),
                "protocol_sha256": protocol["sha256"],
                "target_hash": problem.target_hash,
                "namespace": evaluator.namespace,
            }
        )
        resume_result(directory, task["identity"])
        _write_immutable_json(
            directory / "targets_and_weights.json",
            _seal(
                {
                    "target_hash": problem.target_hash,
                    "scales": problem.scales,
                    "scale_details": problem.scale_details,
                    "trait_weights": {name: 1.0 for name in problem.scales},
                    "targets": _frame_records(problem.observations),
                }
            ),
        )
        _write_immutable_json(directory / "task.json", task)
        tasks.append(task)
    return protocol, tasks


def schedule(
    tasks: Sequence[dict[str, Any]],
    run_batch: Callable[[list[dict[str, Any]]], Iterable[dict[str, Any]]],
    *,
    completed: set[str],
    on_complete: Callable,
    parallel_models: int,
    rank_barrier: bool = True,
) -> None:
    """A rank barrier, not a free-running pool: core combinations finish first."""
    phases = (
        [
            [
                task
                for task in tasks
                if task["selection_rank"] == rank
                and task["identity"] not in completed
            ]
            for rank in sorted({task["selection_rank"] for task in tasks})
        ]
        if rank_barrier
        else [
            [
                task
                for task in tasks
                if task["identity"] not in completed
            ]
        ]
    )
    for pending in phases:
        if not pending:
            continue
        for offset in range(0, len(pending), parallel_models):
            batch = pending[offset : offset + parallel_models]
            by_identity = {task["identity"]: task for task in batch}
            seen = set()
            for result in run_batch(batch):
                identity = result["identity"]
                if identity not in by_identity or identity in seen:
                    raise ValueError("worker result identity mismatch")
                on_complete(by_identity[identity], result)
                completed.add(identity)
                seen.add(identity)
            if seen != set(by_identity):
                raise ValueError("worker did not complete the fixed cultivar phase")


def _refresh(
    root: Path,
    tasks: Sequence[dict[str, Any]],
    results: Mapping[str, dict[str, Any]],
    *,
    status: str,
    error: str = "",
) -> None:
    rows = []
    for task in tasks:
        result = results.get(task["identity"], {})
        rows.append(
            {
                "model": task["model"],
                "cultivar_id": task["cultivar_id"],
                "selection_rank": task["selection_rank"],
                "status": result.get("status", "pending"),
                "search_status": result.get("search_status", ""),
                "reference_loss": result.get("reference_loss"),
                "best_loss": result.get("best_loss"),
                "evaluation_requests": result.get("evaluation_requests", 0),
                "converged": result.get("converged", False),
                "effective_refit": result.get("effective_refit", False),
            }
        )
    _write_table(root / "summary.csv", pd.DataFrame(rows))
    _write_json(
        root / "progress.json",
        {
            **PRELIMINARY,
            "execution_status": status,
            "pid": os.getpid(),
            "completed_count": len(results),
            "planned_count": len(tasks),
            "error": error,
            "combinations": rows,
        },
    )
    text = [
        "# Preliminary training-only quick calibration",
        "",
        "No scientific improvement established. Identifiability unconfirmed.",
        "Independent validation / CV / bootstrap: not performed; holdout not used.",
        CONDITIONAL_SCOPE,
        "",
        "| Model | Cultivar | Status | Reference loss | Best loss | Requests |",
        "| --- | --- | --- | --- | --- | --- |",
        *[
            f"| {row['model']} | {row['cultivar_id'].replace('|', '/')} "
            f"| {row['status']} | {row['reference_loss']} | {row['best_loss']} "
            f"| {row['evaluation_requests']} |"
            for row in rows
        ],
        "",
        "Per-trait MAE/RMSE/bias/count/coverage and failed native candidates are "
        "in each combination's metrics.csv and search.jsonl.",
    ]
    from snowwindow.catalog import _atomic_text

    _atomic_text(root / "summary.md", "\n".join(text) + "\n")


def _set_child_subreaper(value: int = 1) -> int:
    """Adopt orphaned native children so group teardown can actually reap them."""
    if sys.platform != "linux":
        raise ValueError("quick native worker cleanup requires Linux child subreaping")
    libc = ctypes.CDLL(None, use_errno=True)
    previous = ctypes.c_int()
    if libc.prctl(37, ctypes.byref(previous), 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "cannot inspect child subreaper")
    if libc.prctl(36, value, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "cannot configure child subreaper")
    return previous.value


def _stop_worker_groups(processes: Iterable[subprocess.Popen]) -> None:
    """Never return to the lock owner while a managed native group survives."""
    processes = list(processes)
    previous_interrupt = signal.signal(signal.SIGINT, signal.SIG_IGN)
    try:
        groups = {process.pid for process in processes}
        for process in processes:
            if process.stdin:
                process.stdin.close()
        for group in groups:
            try:
                os.killpg(group, signal.SIGTERM)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 1.0
        while groups:
            for process in processes:
                process.poll()
            for group in tuple(groups):
                # Negative PID waits only for this owned group, not unrelated jobs.
                while True:
                    try:
                        pid, status = os.waitpid(-group, os.WNOHANG)
                    except ChildProcessError:
                        break
                    if pid == 0:
                        break
                    for process in processes:
                        if pid == process.pid:
                            process.returncode = os.waitstatus_to_exitcode(status)
                try:
                    os.killpg(group, 0)
                    if time.monotonic() >= deadline:
                        os.killpg(group, signal.SIGKILL)
                except ProcessLookupError:
                    groups.remove(group)
            if groups:
                # Keep the experiment lock, even for delayed kernel-side exit.
                time.sleep(0.01)
    finally:
        signal.signal(signal.SIGINT, previous_interrupt)


@contextmanager
def workers(
    config: ExperimentConfig,
    protocol: Mapping[str, Any],
    tasks: Sequence[dict[str, Any]],
    lock_fd: int,
):
    """One subprocess per task so same-model fits can also run concurrently."""
    processes: list[subprocess.Popen] = []
    replies: list[object] = []
    logs = []
    quick_root = _quick_directory(
        config, protocol.get("quick_directory", "quick_calibration")
    )
    previous_subreaper = _set_child_subreaper()
    try:
        def start_worker(task: Mapping[str, Any]):
            model = str(task["model"])
            read_fd, write_fd = os.pipe()
            worker_name = _safe_id(
                str(task.get("cultivar_id") or task.get("identity") or model)
            )
            log = (quick_root / f"{model}_{worker_name}_worker.log").open("a")
            logs.append(log)
            process = subprocess.Popen(
                [
                    sys.executable,
                    str(Path(__file__).resolve()),
                    "--config",
                    str(config.source_path),
                    "--worker",
                    model,
                    "--reply-fd",
                    str(write_fd),
                    "--lock-fd",
                    str(lock_fd),
                    "--quick-directory",
                    protocol.get("quick_directory", "quick_calibration"),
                    "--search-mode",
                    str(protocol.get("search_mode", "quick")),
                    "--prior-experiment-id",
                    str(protocol.get("prior_experiment_id") or ""),
                ],
                stdin=subprocess.PIPE,
                stdout=log,
                stderr=log,
                text=True,
                pass_fds=(write_fd, lock_fd),
                start_new_session=True,
            )
            os.close(write_fd)
            reply = os.fdopen(read_fd, "r")
            processes.append(process)
            replies.append(reply)
            assert process.stdin is not None
            process.stdin.write(json.dumps(task) + "\n")
            process.stdin.flush()
            process.stdin.close()
            return process, reply

        def run_batch(batch):
            started = []
            with selectors.DefaultSelector() as selector:
                for task in batch:
                    process, reply = start_worker(task)
                    started.append((process, reply))
                    selector.register(reply, selectors.EVENT_READ, task)
                while selector.get_map():
                    for key, _ in selector.select(timeout=1):
                        message = key.fileobj.readline()
                        selector.unregister(key.fileobj)
                        if not message:
                            raise ValueError(
                                f"{key.data['model']} worker exited; inspect worker log"
                            )
                        reply = json.loads(message)
                        if "error" in reply:
                            raise ValueError(reply["error"])
                        result = resume_result(
                            Path(key.data["directory"]), key.data["identity"]
                        )
                        if result is None:
                            raise ValueError("worker did not seal result")
                        yield result

                for process, _ in started:
                    process.wait()

        yield run_batch
    finally:
        _stop_worker_groups(processes)
        try:
            for stream in (*replies, *logs):
                stream.close()
        finally:
            _set_child_subreaper(previous_subreaper)


def _worker(
    config: ExperimentConfig,
    model_name: str,
    reply_fd: int,
    lock_fd: int,
    quick_directory: str,
    search_mode: str = "quick",
    prior_experiment_id: str = "",
) -> int:
    # Inherited lock remains held even if the parent disappears during native work.
    os.fstat(lock_fd)
    root = _quick_directory(config, quick_directory)
    protocol = _verify_seal(_read_json(root / "protocol.json"))
    training = _verify_seal(
        _read_json(config.experiment_dir / "manifests/training_protocol.json")
    )
    tables = _training_tables(config, training)
    model = next(model for model in _models(config) if model.name == model_name)
    if protocol.get("search_mode", "quick") != search_mode:
        raise ValueError("worker search mode/protocol mismatch")
    specs = (
        final_round_parameter_catalog(model_name)
        if search_mode == "final"
        else _specs_and_candidates(model_name, pragmatic=True)[0]
    )
    with os.fdopen(reply_fd, "w", buffering=1) as reply:
        for message in sys.stdin:
            try:
                task = _verify_seal(json.loads(message))
                directory = Path(task["directory"])
                if (
                    task["model"] != model_name
                    or task["protocol_sha256"] != protocol["sha256"]
                    or not directory.resolve().is_relative_to(root.resolve())
                    or _verify_seal(_read_json(directory / "task.json")) != task
                ):
                    raise ValueError("worker task/protocol identity mismatch")
                if resume_result(directory, task["identity"]) is not None:
                    reply.write(json.dumps({"identity": task["identity"]}) + "\n")
                    continue
                requests, observations = _requests(
                    config, tables, task["cultivar_id"], TRAINING_YEARS
                )
                requests, observations = training_inputs(
                    config, model, requests, observations
                )
                evaluator = NativeEvaluator(
                    config, model, requests, observations, label="quick"
                )
                targets = _verify_seal(
                    _read_json(directory / "targets_and_weights.json")
                )
                native_targets = evaluator.observations.copy()
                native_targets["site"] = native_targets["site_id"].astype(str)
                problem = CalibrationProblem(
                    native_targets,
                    evaluator,
                    cache={},
                    cache_namespace=evaluator.namespace,
                )
                if (
                    problem.target_hash != task["target_hash"]
                    or evaluator.namespace != task["namespace"]
                    or problem.scales != targets["scales"]
                ):
                    raise ValueError("worker training target/native identity mismatch")

                # Each new invocation appends its own identified request ledger.
                attempt_id = uuid.uuid4().hex
                requests_recorded = 0

                def record(row):
                    nonlocal requests_recorded
                    requests_recorded += 1
                    _append_attempt_trace(
                        directory / "search.jsonl",
                        [row],
                        attempt_id,
                        first_request=requests_recorded,
                    )

                problem.record_callback = record
                if search_mode == "final":
                    prior_directory = (
                        config.experiment_dir
                        / "prior_results"
                        / model_name
                        / _safe_id(task["cultivar_id"])
                    )
                    prior_result = resume_result(
                        prior_directory,
                        _read_json(prior_directory / "result.json")["identity"],
                    )
                    seeding = _seed_final_problem_from_prior(
                        problem,
                        model=model_name,
                        cultivar=task["cultivar_id"],
                        config=config,
                    )
                    interrupted_directory = "final_calibration"
                    interrupted_ledger = (
                        config.experiment_dir
                        / interrupted_directory
                        / model_name
                        / _safe_id(task["cultivar_id"])
                        / "search.jsonl"
                    )
                    interrupted_seeded = 0
                    if (
                        protocol.get("quick_directory")
                        != interrupted_directory
                        and interrupted_ledger.is_file()
                    ):
                        interrupted_seeded = _seed_predictions_from_ledger(
                            problem,
                            interrupted_ledger,
                            namespace=evaluator.namespace,
                            cache_root=config.experiment_dir / "prediction_cache",
                        )
                    prior = {
                        "parameters": prior_result["parameters"],
                        "reference": prior_result["reference"],
                        "best_loss": prior_result["best_loss"],
                        "best_predictions": pd.read_parquet(
                            prior_directory / "best_predictions.parquet"
                        ),
                    }
                    search = final_search(
                        problem,
                        specs,
                        model=model_name,
                        prior=prior,
                        cultivar=task["cultivar_id"],
                    )
                    search["prior_cache_seeding"] = seeding
                    search["interrupted_cache_seeding"] = {
                        "ledger": str(
                            interrupted_ledger.relative_to(config.experiment_dir)
                        ),
                        "seeded_prediction_cache_points": interrupted_seeded,
                    }
                else:
                    search = quick_search(
                        problem,
                        specs,
                        model=model_name,
                        max_evaluations=protocol["max_evaluations"],
                    )
                search.update(attempt_id=attempt_id, trace_recorded=True)
                save_result(
                    directory,
                    identity=task["identity"],
                    protocol_sha256=protocol["sha256"],
                    model=model_name,
                    cultivar=task["cultivar_id"],
                    search=search,
                )
                reply.write(json.dumps({"identity": task["identity"]}) + "\n")
            except BaseException as exc:
                traceback.print_exc()
                reply.write(json.dumps({"error": f"{model_name}: {exc}"}) + "\n")
                return 1
    return 0


def _freeze_and_validate_final(
    config: ExperimentConfig,
    protocol: Mapping[str, Any],
    tasks: Sequence[dict[str, Any]],
    results: Mapping[str, dict[str, Any]],
) -> None:
    """Freeze all 15 candidates first, then open independent labels exactly once."""
    expected = {task["identity"] for task in tasks}
    if set(results) != expected:
        raise ValueError("final freeze requires every model/cultivar result")
    combinations = []
    for task in tasks:
        result = results[task["identity"]]
        combination = {
            "model": task["model"],
            "cultivar_id": task["cultivar_id"],
            "identity": task["identity"],
            "result_sha256": result["sha256"],
            "target_hash": task["target_hash"],
            "request_namespace": task["namespace"],
            "selected_status": result["selected_status"],
            "selection_reason": result["selection_reason"],
            "parameters": result["parameters"],
            "prior_parameters": result["prior_parameters"],
            "reference": result["reference"],
            "evaluation_requests": result["evaluation_requests"],
            "budget_exhausted": result["budget_exhausted"],
            "converged": result["converged"],
        }
        combinations.append(_seal(combination))
    freeze = _seal(
        {
            "schema": "final_bounded_calibration_freeze_v1",
            "final_protocol_sha256": protocol["sha256"],
            "combinations": combinations,
            "models": {
                model.name: {
                    "version": model.version,
                    "sources": _engine_fingerprints(model),
                }
                for model in _models(config)
            },
            "independent_years": [2023],
            "extra_yield_years": [2024],
            "training_years": TRAINING_YEARS,
            "holdout_traits_opened_after_freeze": True,
            "no_retuning_after_validation": True,
        }
    )
    _write_immutable_json(
        config.experiment_dir / "manifests/final_calibration_freeze.json", freeze
    )

    tables = _tables(config)
    models = {model.name: model for model in _models(config)}
    frames, statuses = [], []
    for combination in combinations:
        model_name, cultivar = combination["model"], combination["cultivar_id"]
        requests, observations = _requests(config, tables, cultivar, (2023, 2024))
        if not requests or observations.empty:
            statuses.append(
                {
                    "model": model_name,
                    "cultivar_id": cultivar,
                    "status": "no_qualified_independent_inputs",
                    "n_targets": 0,
                }
            )
            continue
        evaluator = NativeEvaluator(
            config,
            models[model_name],
            requests,
            observations,
            label="final_independent",
        )
        schemes = {
            "reference": combination["reference"],
            "prior_96": combination["prior_parameters"],
            "final_selected": combination["parameters"],
        }
        for scheme, parameters in schemes.items():
            predictions = evaluator(parameters)
            predictions["scheme"] = scheme
            frames.append(predictions)
        statuses.append(
            {
                "model": model_name,
                "cultivar_id": cultivar,
                "status": "evaluated",
                "n_targets": len(observations),
                "n_native_targets": len(evaluator.observations),
            }
        )
    validation = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    root = config.experiment_dir
    _write_table(root / "validation/predictions.parquet", validation)
    _write_table(root / "validation/metrics.csv", trait_metrics(validation))
    _write_table(
        root / "validation/paired_differences.csv",
        paired_error_differences(
            validation,
            seed=int(_settings(config).get("seed", 20261111)),
        ),
    )
    selected_ids = set(_selected(config)["cultivar_id"])
    skipped = tables["units"].loc[
        tables["units"]["year"].isin([2023, 2024])
        & tables["units"]["cultivar_id"].isin(selected_ids)
        & ~tables["units"]["final_eligible"].astype(bool)
    ]
    _write_table(root / "validation/excluded_units.csv", skipped)
    _write_immutable_json(
        root / "manifests/final_independent_validation.json",
        _seal(
            {
                "final_calibration_freeze_sha256": freeze["sha256"],
                "combinations": statuses,
                "scheme_not_retuned_after_validation": True,
                "all_input_qualified_targets_required": True,
            }
        ),
    )
    rows = []
    for task in tasks:
        result = results[task["identity"]]
        rows.append(
            {
                "model": task["model"],
                "cultivar_id": task["cultivar_id"],
                "selected_status": result["selected_status"],
                "requests": result["evaluation_requests"],
                "budget_exhausted": result["budget_exhausted"],
                "converged": result["converged"],
            }
        )
    text = [
        "# 最终一轮有界校准报告",
        "",
        "15 个组合已按冻结协议完成训练搜索，并在冻结后一次性打开 2023/2024 "
        "输入合格独立目标。验证后未返回调参。",
        "",
        "交叉验证、100 次重采样和输入不确定性传播未在本轮执行；不能宣称完整 "
        "科学验收已通过。",
        "",
        "| Model | Cultivar | Selection | Requests | Budget exhausted | Converged |",
        "| --- | --- | --- | ---: | --- | --- |",
        *[
            f"| {row['model']} | {row['cultivar_id']} | {row['selected_status']} "
            f"| {row['requests']} | {row['budget_exhausted']} | {row['converged']} |"
            for row in rows
        ],
        "",
        "独立验证逐性状指标见 `validation/metrics.csv`；配对差异见 "
        "`validation/paired_differences.csv`。失败候选和完整搜索轨迹见各组合目录。",
    ]
    from snowwindow.catalog import _atomic_text

    _atomic_text(root / "final_calibration_report.md", "\n".join(text) + "\n")


def execute(
    config: ExperimentConfig,
    *,
    max_evaluations: int = 24,
    parallel_models: int = 3,
    core_only: bool = False,
    quick_directory: str = "quick_calibration",
    search_mode: str = "quick",
    prior_experiment_id: str = "",
) -> None:
    if not is_cultivar_mode(config) or not _settings(config).get("pragmatic", False):
        raise ValueError("quick runner requires pragmatic cultivar mode")
    if (
        isinstance(parallel_models, bool)
        or not isinstance(parallel_models, int)
        or parallel_models < 1
    ):
        raise ValueError("parallel-models must be a positive integer")
    if not config.experiment_dir.is_dir():
        raise ValueError("verified prepare/baseline/mask experiment is required")
    with (config.experiment_dir / ".execution.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ValueError(
                "a cultivar calibration runner is already running"
            ) from exc
        protocol, tasks = prepare_tasks(
            config,
            max_evaluations=max_evaluations,
            core_only=core_only,
            quick_directory=quick_directory,
            search_mode=search_mode,
            prior_experiment_id=prior_experiment_id,
        )
        root = _quick_directory(
            config, protocol.get("quick_directory", quick_directory)
        )
        _write_immutable_json(root / "protocol.json", protocol)
        results = {}
        for task in tasks:
            result = resume_result(Path(task["directory"]), task["identity"])
            if result is not None:
                results[task["identity"]] = result
        _refresh(root, tasks, results, status="running")

        def complete(task, result):
            results[task["identity"]] = result
            _refresh(root, tasks, results, status="running")
            print(
                f"{search_mode} completed {task['model']}/{task['cultivar_id']}: "
                f"{result['evaluation_requests']} requests",
                flush=True,
            )

        try:
            pending = [task for task in tasks if task["identity"] not in results]
            if pending:
                with workers(config, protocol, pending, lock.fileno()) as run_batch:
                    schedule(
                        tasks,
                        run_batch,
                        completed=set(results),
                        on_complete=complete,
                        parallel_models=parallel_models,
                        rank_barrier=search_mode == "quick",
                    )
        except BaseException as exc:
            _refresh(
                root,
                tasks,
                results,
                status="interrupted"
                if isinstance(exc, KeyboardInterrupt)
                else "failed",
                error=str(exc),
            )
            raise
        if search_mode == "final":
            _freeze_and_validate_final(config, protocol, tasks, results)
        _refresh(
            root,
            tasks,
            results,
            status="finished_final_and_validated"
            if search_mode == "final"
            else "finished_preliminary_only",
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--max-evaluations", type=int, default=24)
    parser.add_argument("--parallel-models", type=int, default=3)
    parser.add_argument("--core-only", action="store_true")
    parser.add_argument(
        "--quick-directory",
        default="quick_calibration",
        help="isolated quick-round directory; use a new name for a larger budget",
    )
    parser.add_argument(
        "--search-mode",
        choices=("quick", "final"),
        default="quick",
    )
    parser.add_argument(
        "--prior-experiment-id",
        default="",
        help="experiment containing verified quick_calibration_96 results",
    )
    parser.add_argument("--worker", choices=tuple(ACTIVE), help=argparse.SUPPRESS)
    parser.add_argument("--reply-fd", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--lock-fd", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        config = load_config(args.config.resolve())
        if args.worker:
            if args.reply_fd is None or args.lock_fd is None:
                raise ValueError(
                    "worker requires parent-owned reply and lock descriptors"
                )
            return _worker(
                config,
                args.worker,
                args.reply_fd,
                args.lock_fd,
                args.quick_directory,
                args.search_mode,
                args.prior_experiment_id,
            )
        execute(
            config,
            max_evaluations=args.max_evaluations,
            parallel_models=args.parallel_models,
            core_only=args.core_only,
            quick_directory=args.quick_directory,
            search_mode=args.search_mode,
            prior_experiment_id=args.prior_experiment_id,
        )
    except Exception:
        traceback.print_exc(file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
