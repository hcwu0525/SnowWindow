"""Explicit, user-authorized approximation of next-year scan weather."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import replace
from datetime import date, timedelta
from typing import Any

import numpy as np
import pandas as pd

from snowwindow.domain import SimulationRequest, WeatherRecord
from snowwindow.experiment import WEATHER_COLUMNS

WEATHER_APPROXIMATION_POLICY = (
    "Preserve valid G2F cells; interpolate <=3-day internal non-rain gaps; "
    "missing rain uses INH1 2014-2023 same-calendar-day mean; remaining non-rain "
    "uses historical calendar median. Approximations are not observations."
)


def complete_next_year_weather(
    observed: pd.DataFrame,
    historical: pd.DataFrame,
    *,
    year: int,
) -> pd.DataFrame:
    """Complete a calendar without replacing any finite observed input cell."""
    history = historical.copy()
    history["date"] = pd.to_datetime(history["date"])
    history = history.loc[history.date.dt.year.lt(year)].copy()
    if history.empty:
        raise ValueError("historical weather before the target year is required")
    history["calendar_day"] = history.date.dt.strftime("%m-%d")
    numeric = history[list(WEATHER_COLUMNS)].apply(pd.to_numeric, errors="coerce")
    history[list(WEATHER_COLUMNS)] = numeric.where(np.isfinite(numeric))
    climatology = history.groupby("calendar_day")[list(WEATHER_COLUMNS)].median()
    climatology["PRECTOTCORR"] = history.groupby("calendar_day").PRECTOTCORR.mean()
    if "02-29" not in climatology.index:
        climatology.loc["02-29"] = climatology.loc[["02-28", "03-01"]].mean()
    frame = observed.copy()
    frame["date"] = pd.to_datetime(frame["date"])
    frame = frame.loc[frame.date.dt.year.eq(year)].set_index("date")
    if frame.index.duplicated().any():
        raise ValueError("duplicate next-year weather dates")
    frame = frame.reindex(pd.date_range(f"{year}-01-01", f"{year}-12-31"))
    frame.index.name = "date"
    frame["environment_id"] = f"INH1_{year}"
    methods = {day: [] for day in frame.index}
    filled = {day: [] for day in frame.index}
    for column in WEATHER_COLUMNS:
        values = pd.to_numeric(frame[column], errors="coerce")
        values = values.where(np.isfinite(values))
        original_missing = values.isna()
        if column != "PRECTOTCORR":
            groups = original_missing.ne(original_missing.shift()).cumsum()
            lengths = original_missing.groupby(groups).transform("sum")
            interpolated = values.interpolate(method="time", limit_area="inside")
            mask = original_missing & lengths.le(3) & interpolated.notna()
            values.loc[mask] = interpolated.loc[mask]
            for day in frame.index[mask]:
                methods[day].append(f"{column}:short_gap_linear")
        missing = values.isna()
        estimates = pd.Series(
            frame.index.strftime("%m-%d").map(climatology[column]),
            index=frame.index,
            dtype=float,
        )
        if estimates.loc[missing].isna().any():
            raise ValueError(f"no historical calendar estimates for {column}")
        values.loc[missing] = estimates.loc[missing]
        for day in frame.index[missing]:
            kind = "calendar_mean" if column == "PRECTOTCORR" else "calendar_median"
            methods[day].append(f"{column}:{kind}")
        for day in frame.index[original_missing]:
            filled[day].append(column)
        frame[column] = values
    if frame.T2M_MIN.gt(frame.T2M_MAX).any():
        raise ValueError("completed weather has Tmin greater than Tmax")
    frame["approximate_columns"] = [";".join(filled[day]) for day in frame.index]
    frame["approximation_method"] = [";".join(methods[day]) for day in frame.index]
    frame["approximate_weather"] = frame.approximate_columns.ne("")
    frame["source_filename"] = frame.source_filename.fillna("historical_INH1_calendar")
    frame["core_weather_valid"] = True
    frame["year"] = year
    return frame.reset_index()


def extend_request(
    request: SimulationRequest,
    next_year_weather: pd.DataFrame,
) -> SimulationRequest:
    """Longer-window rerun: same initial state, soil, cultivar and single sowing."""
    year = request.environment.year + 1
    future = next_year_weather.copy()
    future["date"] = pd.to_datetime(future["date"]).dt.date
    expected = tuple(
        day.date()
        for day in pd.date_range(
            f"{year}-01-01",
            f"{year}-12-31",
        )
    )
    future = future.sort_values("date")
    if tuple(future.date) != expected:
        raise ValueError("next-year extension requires one complete dated calendar")
    values = future[list(WEATHER_COLUMNS)].apply(pd.to_numeric, errors="raise")
    if not np.isfinite(values).all().all():
        raise ValueError("next-year extension contains invalid weather")
    end = date(
        year,
        request.management.planting_date.month,
        request.management.planting_date.day,
    ) - timedelta(days=1)
    future = future.loc[future.date.le(end)]
    records = tuple(
        WeatherRecord(
            request.environment.environment_id,
            row["date"],
            {column: float(row[column]) for column in WEATHER_COLUMNS},
            str(row.get("source_filename", "G2F"))
            + (
                f";approximate:{row.get('approximation_method', 'calendar_estimate')}"
                if row.get("approximate_weather", False)
                else ""
            ),
        )
        for row in future.to_dict("records")
    )
    original_means = [
        (row.values["T2M_MIN"] + row.values["T2M_MAX"]) / 2
        for row in request.environment.weather
    ]
    metadata = {
        **request.environment.metadata,
        "scan_met_header": {
            "tav": sum(original_means) / len(original_means),
            "amp": max(original_means) - min(original_means),
            "source": "frozen original-year weather window",
        },
        "scan_approximate_weather_dates": [
            row["date"].isoformat()
            for row in future.to_dict("records")
            if row.get("approximate_weather", False)
        ],
        "scan_weather_approximation_policy": WEATHER_APPROXIMATION_POLICY,
    }
    return replace(
        request,
        end_date=end,
        output_dir=request.output_dir / "cross_year",
        environment=replace(
            request.environment,
            weather=(*request.environment.weather, *records),
            metadata=metadata,
        ),
    )


@contextmanager
def met_header_context(model: str):
    """Process-local scan translation; never modify the frozen adapter files."""
    if model == "aquacrop":
        from snowwindow.models.aquacrop import adapter as aquacrop

        original_end = aquacrop.simulation_end_for_planting

        def one_crop_end(planting: date) -> tuple[date, bool]:
            return date(planting.year + 1, planting.month, planting.day) - timedelta(
                days=1
            ), False

        aquacrop.simulation_end_for_planting = one_crop_end
        try:
            yield
        finally:
            aquacrop.simulation_end_for_planting = original_end
        return
    if model != "apsim":
        yield
        return
    from snowwindow.models.apsim import adapter as apsim

    original = apsim.render_met

    def render_scan_met(request: SimulationRequest) -> str:
        text = original(request)
        header: Any = request.environment.metadata.get("scan_met_header")
        if not header:
            return text
        lines = text.splitlines()
        lines = [
            f"tav = {header['tav']:.3f}"
            if line.startswith("tav = ")
            else f"amp = {header['amp']:.3f}"
            if line.startswith("amp = ")
            else line
            for line in lines
        ]
        return "\n".join(lines) + "\n"

    apsim.render_met = render_scan_met
    try:
        yield
    finally:
        apsim.render_met = original


def approximation_days(request: SimulationRequest, maturity: date | None) -> int:
    cutoff = maturity or request.end_date
    return sum(
        request.management.planting_date <= date.fromisoformat(day) <= cutoff
        for day in request.environment.metadata.get(
            "scan_approximate_weather_dates", ()
        )
    )
