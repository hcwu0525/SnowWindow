"""Frozen-parameter PHG29/PHG47 scan across the complete Stage 1 environments."""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Any

import pandas as pd

from snowwindow.cultivar_scan import (
    CULTIVAR,
    MODELS,
    _native_batch,
    _record_result,
    continuation_needed,
    frozen_parameters,
    pilot_dates,
    planting_dates,
    read_checkpoint,
    result_record,
    scan_request,
    select_scenario_requests,
    write_checkpoint,
)
from snowwindow.cultivar_scan_weather import approximation_days, extend_request
from snowwindow.cultivar_workflow import (
    _engine_fingerprints,
    _models,
    _read_json,
    _requests,
    _seal,
    _verify_seal,
    _write_immutable_json,
    _write_json,
    _write_table,
)
from snowwindow.data.sources import sha256_file
from snowwindow.experiment import WEATHER_COLUMNS

SCHEMA = "cultivar_stage1_calendar_scan_v1"
DEFAULT_EXPERIMENT_ID = "g2f_phg29_stage1_scan_20261113_v1"

# These are the 34 final-eligible PHG29/PHG47 environments whose current and
# next calendars are both complete for all seven model weather variables.
STAGE1_ENVIRONMENTS = (
    "DEH1_2016",
    "DEH1_2017",
    "GAH1_2016",
    "GAH1_2017",
    "GAH2_2017",
    "IAH4_2017",
    "IAH4_2022",
    "INH1_2016",
    "INH1_2020",
    "INH1_2021",
    "INH1_2022",
    "MIH1_2016",
    "MIH1_2017",
    "MIH1_2020",
    "MNH1_2016",
    "MOH1_2016",
    "MOH2_2022",
    "NEH1_2022",
    "NYH1_2017",
    "NYH2_2016",
    "NYH2_2017",
    "NYH2_2022",
    "NYH3_2022",
    "NYS1_2020",
    "OHH1_2022",
    "ONH1_2016",
    "SCH1_2021",
    "WIH1_2016",
    "WIH1_2017",
    "WIH1_2022",
    "WIH2_2017",
    "WIH2_2021",
    "WIH2_2022",
    "WIH3_2021",
)
PILOT_POINTS_PER_ENV = 10


def environment_years() -> tuple[int, ...]:
    return tuple(sorted({int(env.rsplit("_", 1)[1]) for env in STAGE1_ENVIRONMENTS}))


def expected_scan_points() -> int:
    return sum(
        len(planting_dates(int(env.rsplit("_", 1)[1])))
        for env in STAGE1_ENVIRONMENTS
    ) * len(MODELS)


def expected_pilot_points() -> int:
    return len(STAGE1_ENVIRONMENTS) * len(MODELS) * PILOT_POINTS_PER_ENV


def implementation_fingerprints() -> dict[str, str]:
    package = Path(__file__).resolve().parent
    paths = [
        package / name
        for name in (
            "cultivar_stage1_scan.py",
            "cultivar_scan.py",
            "cultivar_scan_weather.py",
            "cultivar_workflow.py",
            "cultivar_inputs.py",
            "cultivar_pragmatic.py",
            "config.py",
            "domain.py",
            "experiment.py",
        )
    ]
    paths.append(package.parents[1] / "scripts/run_cultivar_stage1_scan.py")
    return {str(path): sha256_file(path) for path in paths}


def _next_environment_id(environment_id: str) -> str:
    site, year = environment_id.rsplit("_", 1)
    return f"{site}_{int(year) + 1}"


def _validated_weather(
    frame: pd.DataFrame, environment_id: str, year: int
) -> pd.DataFrame:
    expected = tuple(
        day.date() for day in pd.date_range(f"{year}-01-01", f"{year}-12-31")
    )
    dates = pd.to_datetime(frame["date"], errors="raise").dt.date
    if dates.duplicated().any() or tuple(sorted(dates)) != expected:
        raise ValueError(f"{environment_id}: weather must be one complete calendar")
    values = frame[list(WEATHER_COLUMNS)].apply(pd.to_numeric, errors="coerce")
    if not values.notna().all().all():
        missing = values.isna().sum()
        raise ValueError(
            f"{environment_id}: incomplete weather columns: {missing.to_dict()}"
        )
    if frame["T2M_MIN"].gt(frame["T2M_MAX"]).any():
        raise ValueError(f"{environment_id}: minimum temperature exceeds maximum")
    return frame


def _input_tables(root: Path) -> dict[str, pd.DataFrame]:
    names = {
        "units": "units",
        "observations": "observations",
        "environments": "environments",
        "soil": "soil",
        "weather": "weather",
    }
    return {
        name: pd.read_parquet(root / "inputs" / f"{filename}.parquet")
        for name, filename in names.items()
    }


def prepare_scan(config: Any, root: Path) -> dict[str, Any]:
    """Snapshot only Stage 1 inputs and their complete next-year calendars."""
    source = config.experiment_dir
    if root.resolve() == source.resolve():
        raise ValueError("scan must use a new experiment, not the frozen source")
    freeze = _verify_seal(
        _read_json(source / "manifests/final_calibration_freeze.json")
    )
    preparation = _verify_seal(
        _read_json(source / "manifests/cultivar_prepare.json")
    )
    models = {model.name: model for model in _models(config)}
    if set(models) != set(MODELS):
        raise ValueError("scan requires the three frozen native engines")
    for name, model in models.items():
        expected = freeze["models"][name]
        if (
            model.version != expected["version"]
            or _engine_fingerprints(model) != expected["sources"]
        ):
            raise ValueError(f"{name}: engine/adapter differs from frozen calibration")

    files = {
        "units": "cultivar_units",
        "observations": "cultivar_observations",
        "environments": "environments",
        "soil": "soil_layers",
        "weather": "weather",
    }
    tables: dict[str, pd.DataFrame] = {}
    source_hashes: dict[str, str] = {}
    for name, filename in files.items():
        relative = f"normalized/{filename}.parquet"
        path = source / relative
        actual = sha256_file(path)
        if actual != preparation["artifact_sha256"][relative]:
            raise ValueError(f"frozen prepared input changed: {relative}")
        source_hashes[relative] = actual
        filters = [("environment_id", "in", list(STAGE1_ENVIRONMENTS))]
        if name in {"units", "observations"}:
            filters.append(("cultivar_id", "==", CULTIVAR))
        tables[name] = pd.read_parquet(path, filters=filters)

    tables["units"] = tables["units"].loc[
        tables["units"]["final_eligible"].astype(bool)
    ].copy()
    if tables["units"]["environment_id"].nunique() != len(STAGE1_ENVIRONMENTS):
        raise ValueError("Stage 1 selected units do not cover every environment")
    tables["observations"] = tables["observations"].loc[
        tables["observations"]["unit_id"].isin(tables["units"]["unit_id"])
    ].copy()

    source_weather_path = source / "normalized/weather.parquet"
    next_frames = []
    next_environment_ids: dict[str, str] = {}
    for env in STAGE1_ENVIRONMENTS:
        year = int(env.rsplit("_", 1)[1])
        current = pd.read_parquet(
            source_weather_path, filters=[("environment_id", "==", env)]
        )
        current = _validated_weather(current, env, year)
        next_id = _next_environment_id(env)
        future = pd.read_parquet(
            source_weather_path, filters=[("environment_id", "==", next_id)]
        )
        future = _validated_weather(future, next_id, year + 1)
        next_environment_ids[env] = next_id
        future = future.copy()
        future["source_environment_id"] = env
        next_frames.append(future)
    next_weather = pd.concat(next_frames, ignore_index=True)

    parameters = {name: frozen_parameters(freeze, name) for name in MODELS}
    representatives: dict[str, dict[str, str]] = {}
    for name in MODELS:
        requests, _ = _requests(config, tables, CULTIVAR, environment_years())
        selected = select_scenario_requests(requests)
        if set(selected) != set(STAGE1_ENVIRONMENTS):
            raise ValueError(f"{name}: Stage 1 request coverage is incomplete")
        representatives[name] = {
            env: request.management.management_unit_id
            for env, request in selected.items()
        }

    expected_frames = []
    for model in MODELS:
        path = (
            source
            / "final_calibration_parallel"
            / model
            / "PHG29_PHG47_1a8a437e"
            / "best_predictions.parquet"
        )
        relative = str(path.relative_to(source))
        source_hashes[relative] = sha256_file(path)
        expected_frames.append(
            pd.read_parquet(
                path,
                filters=[
                    ("cultivar_id", "==", CULTIVAR),
                    ("environment_id", "in", list(STAGE1_ENVIRONMENTS)),
                    ("scheme", "==", "final_selected"),
                    (
                        "variable",
                        "in",
                        ["dry_yield_mg_ha", "pollen_dap", "silk_dap"],
                    ),
                ],
            )
        )
    expected = pd.concat(expected_frames, ignore_index=True)
    if expected.duplicated(["model", "environment_id", "unit_id", "variable"]).any():
        raise ValueError("Stage 1 actual predictions contain duplicate traits")
    if set(expected["environment_id"]) != set(STAGE1_ENVIRONMENTS):
        raise ValueError("Stage 1 actual predictions do not cover every environment")

    settings = {"assumptions": dict(config.calibration.options["assumptions"])}
    body = {
        "schema": SCHEMA,
        "cultivar_id": CULTIVAR,
        "environments": list(STAGE1_ENVIRONMENTS),
        "models": freeze["models"],
        "source_experiment": str(source),
        "source_freeze_sha256": freeze["sha256"],
        "source_prepare_sha256": preparation["sha256"],
        "source_config_sha256": sha256_file(config.source_path),
        "source_artifact_sha256": source_hashes,
        "parameters": parameters,
        "assumptions": settings["assumptions"],
        "representative_units": representatives,
        "next_environment_ids": next_environment_ids,
        "scan_horizon": "same_year_then_single_crop_cross_year",
        "expected_count": expected_scan_points(),
        "pilot_count": expected_pilot_points(),
        "requested_end": "next sowing anniversary minus one day for unfinished crops",
        "weather_policy": (
            "Only current and next calendars complete for all seven model variables; "
            "no weather gap filling is used in Stage 1"
        ),
        "continuation_method": (
            "same-initial-state longer-window rerun; no second sowing"
        ),
        "fertilizer_timing": "assumed sowing N follows planting; verified dates fixed",
        "technical_retries": 1,
        "scan_code_sha256": sha256_file(Path(__file__)),
        "implementation_sha256": implementation_fingerprints(),
        "limitations": [
            "Counterfactual planting dates have no independent yield observations.",
            "All soil inputs are unmeasured texture priors or matched profiles.",
            "No parameter retuning, forced maturity acceptance, or uncertainty refits.",
            "Cross-year continuations use a complete observed G2F calendar.",
        ],
    }
    for name, table in tables.items():
        _write_table(root / "inputs" / f"{name}.parquet", table)
    _write_table(root / "inputs/weather_next_year.parquet", next_weather)
    _write_table(root / "inputs/expected_actual_predictions.parquet", expected)
    _write_json(root / "inputs/parameters.json", parameters)
    _write_json(root / "inputs/assumptions.json", settings)
    input_hashes = {
        path.name: sha256_file(path)
        for path in (root / "inputs").iterdir()
        if path.is_file()
    }
    _write_immutable_json(root / "inputs/manifest.json", _seal(input_hashes))
    _write_immutable_json(root / "manifest.json", _seal(body))
    return _read_json(root / "manifest.json")


def verify_scan_inputs(config: Any, root: Path, model: Any) -> dict[str, Any]:
    manifest = _verify_seal(_read_json(root / "manifest.json"))
    if manifest["schema"] != SCHEMA:
        raise ValueError("foreign scan manifest")
    if sha256_file(Path(__file__)) != manifest["scan_code_sha256"]:
        raise ValueError("scan code changed after snapshot; use a new experiment ID")
    if sha256_file(config.source_path) != manifest["source_config_sha256"]:
        raise ValueError("source configuration changed after scan freeze")
    for filename, expected_hash in manifest["implementation_sha256"].items():
        if sha256_file(Path(filename)) != expected_hash:
            raise ValueError(
                "request/pipeline implementation changed after scan freeze"
            )
    inputs = _verify_seal(_read_json(root / "inputs/manifest.json"))
    for name, expected in inputs.items():
        if name != "sha256" and sha256_file(root / "inputs" / name) != expected:
            raise ValueError(f"scan input snapshot changed: {name}")
    if config.experiment_dir.resolve() != Path(manifest["source_experiment"]).resolve():
        raise ValueError("source experiment changed")
    expected_model = manifest["models"][model.name]
    if (
        model.version != expected_model["version"]
        or _engine_fingerprints(model) != expected_model["sources"]
    ):
        raise ValueError("native engine lineage changed")
    return manifest


def scenario_bases(config: Any, root: Path, model: str) -> dict[str, Any]:
    tables = _input_tables(root)
    requests, _ = _requests(config, tables, CULTIVAR, environment_years())
    parameters = _read_json(root / "inputs/parameters.json")[model]
    requests = {
        unit_id: replace_request(request, parameters, root, model)
        for unit_id, request in requests.items()
    }
    selected = select_scenario_requests(requests)
    if set(selected) != set(STAGE1_ENVIRONMENTS):
        raise ValueError("input snapshot does not cover the Stage 1 environment grid")
    return selected


def replace_request(request: Any, parameters: dict[str, float], root: Path, model: str):
    from dataclasses import replace

    return replace(
        request,
        model_parameters={**request.model_parameters, **parameters},
        parameter_set_id="final_selected",
        output_dir=root / "model_cache" / model,
    )


def next_year_weather(root: Path, environment_id: str) -> pd.DataFrame:
    return pd.read_parquet(
        root / "inputs/weather_next_year.parquet",
        filters=[("source_environment_id", "==", environment_id)],
    )


def scan_worker(config: Any, root: Path, model: str, env: str, phase: str) -> None:
    import time
    adapter = next(item for item in _models(config) if item.name == model)
    manifest = verify_scan_inputs(config, root, adapter)
    base = scenario_bases(config, root, model)[env]
    future_weather = next_year_weather(root, env)
    dates = (
        pilot_dates(base) if phase == "pilot" else planting_dates(base.environment.year)
    )
    directory = root / "scan" / model / env
    namespace = manifest["sha256"]
    requests = [scan_request(base, day) for day in dates]
    records, pending = [], []
    for request in requests:
        path = directory / "points" / f"{request.management.planting_date}.json"
        cached = read_checkpoint(path, request, namespace=namespace)
        if cached is None:
            pending.append(request)
        else:
            records.append(cached)

    def checkpoint() -> None:
        frame = (
            pd.DataFrame(records).sort_values("planting_date")
            if records
            else pd.DataFrame()
        )
        _write_table(directory / "results.parquet", frame)
        _write_json(
            directory / "progress.json",
            {
                "model": model,
                "environment_id": env,
                "phase": phase,
                "completed": len(records),
                "expected": len(dates),
                "status": "complete" if len(records) == len(dates) else "running",
            },
        )

    checkpoint()
    chunk_size = 16 if model == "apsim" else 1
    for offset in range(0, len(pending), chunk_size):
        batch = pending[offset : offset + chunk_size]
        started = time.monotonic()
        first_records = {}
        for request in batch:
            cached = read_checkpoint(
                directory / "first_pass" / f"{request.management.planting_date}.json",
                request,
                namespace=namespace,
            )
            if cached is not None:
                first_records[request.request_id] = cached
        evaluated = _native_batch(
            adapter,
            [request for request in batch if request.request_id not in first_records],
        )
        for request in batch:
            if request.request_id not in first_records:
                result, attempts = evaluated[request.request_id]
                record = result_record(request, result, namespace=namespace)
                record["attempts"] = attempts
                write_checkpoint(
                    directory
                    / "first_pass"
                    / f"{request.management.planting_date}.json",
                    request,
                    record,
                    namespace=namespace,
                )
                first_records[request.request_id] = record
        extended = {
            request.request_id: extend_request(request, future_weather)
            for request in batch
            if continuation_needed(
                _record_result(first_records[request.request_id]),
                request=request,
            )
        }
        extended_results = _native_batch(adapter, list(extended.values()))
        for request in batch:
            first = first_records[request.request_id]
            record = dict(first)
            if request.request_id in extended_results:
                current = extended[request.request_id]
                result, attempts = extended_results[request.request_id]
                record = result_record(current, result, namespace=namespace)
                record["continuation_request_fingerprint"] = current.content_hash()
                record["request_fingerprint"] = request.content_hash()
                record["attempts"] = first["attempts"] + attempts
                record["first_pass_record"] = first
                maturity = pd.to_datetime(record["maturity_date"], errors="coerce")
                record["approximate_weather_days_used"] = approximation_days(
                    current,
                    maturity.date() if pd.notna(maturity) else None,
                )
            else:
                record["continuation_request_fingerprint"] = None
                record["first_pass_record"] = None
                record["approximate_weather_days_used"] = 0
            record["first_pass_status"] = first["status"]
            record["first_pass_end_date"] = request.end_date.isoformat()
            record["cross_year_extended"] = request.request_id in extended
            record["continuation_recovered"] = bool(
                record["cross_year_extended"]
                and record["natural_maturity"]
                and record["dry_yield_mg_ha"] is not None
            )
            record["elapsed_seconds_batch_per_request"] = (
                time.monotonic() - started
            ) / len(batch)
            write_checkpoint(
                directory / "points" / f"{request.management.planting_date}.json",
                request,
                record,
                namespace=namespace,
            )
            records.append(record)
        checkpoint()
        print(f"{model}/{env}: {len(records)}/{len(dates)}", flush=True)


def collect_scan(root: Path, *, config: Any) -> pd.DataFrame:
    manifest = _verify_seal(_read_json(root / "manifest.json"))
    records = []
    for model in MODELS:
        for env, base in scenario_bases(config, root, model).items():
            directory = root / "scan" / model / env / "points"
            for path in sorted(directory.glob("*.json")):
                planting = date.fromisoformat(path.stem)
                request = scan_request(base, planting)
                record = read_checkpoint(path, request, namespace=manifest["sha256"])
                if record is None or any(
                    (
                        record["request_id"] != request.request_id,
                        record["request_fingerprint"] != request.content_hash(),
                        record["namespace"] != manifest["sha256"],
                        record["model"] != model,
                        record["cultivar_id"] != CULTIVAR,
                        record["environment_id"] != env,
                        record["planting_date"] != planting.isoformat(),
                        record["year"] != base.environment.year,
                    )
                ):
                    raise ValueError("point record identity changed")
                records.append(record)
    result = pd.DataFrame(records)
    if result.empty or result.duplicated(
        ["model", "environment_id", "planting_date"]
    ).any():
        raise ValueError("Stage 1 scan collection is empty or duplicated")
    result = result.sort_values(["model", "environment_id", "planting_date"])
    _write_table(root / "scan/results.parquet", result)
    _write_table(
        root / "scan/results.csv",
        result.drop(
            columns=["native_summary", "native_diagnostics", "artifacts"],
            errors="ignore",
        ),
    )
    return result


def verify_complete_scan(results: pd.DataFrame) -> None:
    keys = ["model", "cultivar_id", "environment_id", "year", "planting_date"]
    expected = {
        (model, CULTIVAR, env, int(env.rsplit("_", 1)[1]), day.isoformat())
        for model in MODELS
        for env in STAGE1_ENVIRONMENTS
        for day in planting_dates(int(env.rsplit("_", 1)[1]))
    }
    if (
        not set(keys).issubset(results)
        or len(results) != len(expected)
        or results.duplicated(keys).any()
        or set(results[keys].itertuples(index=False, name=None)) != expected
    ):
        raise ValueError("scan does not contain the exact Stage 1 full-calendar grid")
