# 核心字段与有效性

## 身份和日期

| 字段 | 含义 | 使用方式 |
|---|---|---|
| `cultivar_id` | 品种 PHG29/PHG47 | 与其他品种合并后纳入唯一键 |
| `model`, `model_version` | 模型及版本 | 保留模型维度，勿直接混合成一个响应曲线 |
| `environment_id` | 站点的年度环境，如 DEH1_2016 | 与环境表、来源天气关联 |
| `site_id` | 站点，如 DEH1 | 跨年分组；使用包内映射，不依赖字符串截断 |
| `year` | 环境/播种所属年 | 跨年成熟后仍为原年，不是成熟年份 |
| `planting_date` | 本行模拟播种日期 | 通常为反事实；实际播期见管理单元表 |
| `simulation_start_date`, `simulation_end_date` | 请求的模拟窗口 | 区分日历窗口和作物实际生育期 |
| `days_available_after_sowing` | 从播期至请求终点的可用日数，含首尾 | 不是实际成熟所需天数 |

## 产量和物候

| 字段 | 含义 | 有效性/限制 |
|---|---|---|
| `dry_yield_mg_ha` | 自然成熟筛选后的模拟干产量，Mg/ha=吨/公顷 | 产量分析优先使用；空值不是零 |
| `native_yield_mg_ha` | 适配器报告的干产量，未做自然成熟筛选 | 死亡/未成熟时可能有中间产量，只作诊断 |
| `pollen_dap` | 播种后至模型物候代理事件的天数 | 本包 APSIM/AquaCrop 填此列，DSSAT 不填 |
| `silk_dap` | 播种后至模型物候代理事件的天数 | 本包 DSSAT 填此列，另外两模型不填 |
| `flowering_date` | 对应模型物候代理日期 | 三模型并非同一生理事件；仅日期非空不能确认事件有效 |
| `maturity_date` | 模型报告的成熟日期 | 结合 status/natural_maturity，不单独判定产量有效 |

AquaCrop 的代理是萌发延迟修正后原生 HIstart 的首次日末跨越，不是独立模拟的
散粉或吐丝事件；APSIM 的代理来自其物候开花事件，与观测 pollen DAP 比较；
DSSAT CERES-Maize ADAT 是 75% 吐丝日期，与观测 silk DAP 比较。
因此 `pollen_dap`/`silk_dap` 的非空差异主要来自模型接口适用性，不能自动填补，
也不能将两个性状简单拼接成统一的真实开花天数。

物候分析建议分别使用各模型对应 DAP 非空的记录，排除技术失败，
并检查播期 + DAP 是否在模拟窗口内。
死亡或未成熟记录可用于研究已经发生的较早事件，但不能解释成完成整个生育期。
包内 DAP 已有基本事件有效性筛选；裸 `flowering_date` 保留原模型报告，筛选更弱。

例如分析 DSSAT 吐丝代理：

```python
dap = df["silk_dap"]
event_date = pd.to_datetime(df["planting_date"]) + pd.to_timedelta(dap, unit="D")
mask = (
    df["model"].eq("dssat")
    & dap.notna()
    & df["status"].isin(["matured", "crop_died", "not_matured"])
    & event_date.ge(pd.to_datetime(df["simulation_start_date"]))
    & event_date.le(pd.to_datetime(df["simulation_end_date"]))
)
```

若进一步核对实际执行/终止时点，查看有值的
native_summary_actual_simulation_end_date、native_summary_last_simulated_date
和 native_summary_termination_date。并非每模型都有这些字段；本包没有逐日死亡
时点，不能统一验证事件发生在死亡前。窗口筛选本身不提供这一额外证据。

## 状态、跨年和输入证据

| 字段 | 含义 | 使用方式 |
|---|---|---|
| `status` | matured / crop_died / not_matured / execution_failed | 四类都保留；分别代表成熟、死亡、未成熟、执行失败 |
| `natural_maturity` | 成熟且未标记强制成熟的统一判定 | 当前 33,149 行为 True，仍有 24 行产量缺失 |
| `forced_maturity` | 发现/排除/拒绝强制成熟相关事件的诊断标识 | 当前全 False；不要用强制事件认定自然成熟 |
| `failure_reason` | 模型/执行失败原因 | 某些缺失产量行没有单独原因，不据此推定成功 |
| `cross_year_extended` | 曾从相同初始状态使用更长天气窗口重跑 | 不是追加第二次播种；共 15,408 行 |
| `continuation_recovered` | 延长后自然成熟且产量非空 | 共 14,487 行 |
| `horizon_limited` | 当前实现等同于 not_matured | 只表示窗口内未成熟，不证明更长窗口必能成熟 |
| `first_pass_status` | 跨年处理前的初次运行状态 | 用于区分初次未完成与最终结局 |
| `irrigation_assumption` | assumed_rainfed / rainfed_confirmed | 假设雨养 27,411 行，确认雨养 9,855 行 |
| `soil_input_tier` | 土壤证据等级 | 全部 texture_prior_not_measured，非现场实测剖面 |
| `approximate_weather_days_used` | 当前运行使用近似天气的日数 | 本包全 0；不代表管理、土壤等没有近似 |
| `request_id`, `request_fingerprint`, `namespace` | 请求身份、输入内容指纹、冻结实验命名空间 | 用于追溯；不是 G2F 原始数据标识 |

12 条执行失败全部是 AquaCrop 的 2016-02-29 或 2020-02-29 播期。
它们属于技术失败，应保留其存在信息，不能解释为玉米生物学死亡。

## 推荐产量筛选

```python
valid = (
    df["status"].eq("matured")
    & df["natural_maturity"].eq(True)
    & df["forced_maturity"].eq(False)
    & df["dry_yield_mg_ha"].notna()
)
yield_results = df.loc[valid]
assert len(yield_results) == 33125
```

不增加 `yield > 0` 条件，以保留有效零产量。不用 `fillna(0)`。
跨模型比较时可按唯一键去除 model 后配对，但先明确采用各模型各自有效集，
还是三个模型共同有效的播期交集；两者样本覆盖不同。

`native_summary_*` 是原生摘要展开列；如 seasonal_et_mm 等水量字段在本包
主要来自 AquaCrop，缺失并不等于其他模型没有水分过程。使用之前查看完整字典的
模型非空数量。季节汇总需检查各模型统计起止范围，不能凭列名直接做三模型对比。
