# 校准数据、流程和验证

仅整理 PHG29/PHG47。参数在打开独立验证前冻结，验证后不回调参数。最终训练从已封存的前轮 96 请求校准结果开始；最终轮筛选 32 个候选，包含参考/前轮参数、坐标 ±10% 范围探针与 Latin Hypercube，最多三个起点，再进行有界 Powell 搜索。随机种子 20261112。模型请求上限 AquaCrop=240、APSIM=640、DSSAT=400；缓存命中也计数。

目标是按性状尺度标准化、按权重平方根缩放的残差平方和：`sum_i [sqrt(w_trait) * (pred_i - obs_i) / scale_trait]^2`。每个固定主目标必须有有效事件和预测；任一缺失或失败则该候选损失为无穷。尺度来自目标文档记录的重复观测均值合并方差，具体数值、公式、来源行见各模型 targets_and_weights.json，不能比较不同模型的裸损失大小。

替换前轮参数须总损失至少改善 1%，且物候、产量各自 RMSE 恶化不超过 2%；这是预先规定的工程选择规则，不是显著性检验。AquaCrop 接受本轮结果；APSIM/DSSAT 因 yield_rmse_degradation 保留前轮参数。converged 与 accepted 不等价，预算耗尽也不自动判定参数不可用。

## 实际训练目标

| model | selected_status | selection_reason | target_records | target_environments | target_sites | target_years | yield_targets | pollen_targets | silk_targets | requests | budget_exhausted | converged |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| apsim | retained_prior_96 | yield_rmse_degradation | 56 | 38 | 20 | 2016,2017,2020,2021,2022 | 17 | 39 | 0 | 472 | False | True |
| aquacrop | accepted | accepted | 54 | 31 | 19 | 2016,2017,2020,2021,2022 | 22 | 32 | 0 | 240 | True | False |
| dssat | retained_prior_96 | yield_rmse_degradation | 75 | 38 | 20 | 2016,2017,2020,2021,2022 | 36 | 0 | 39 | 386 | False | True |

训练实际年份是 2016、2017、2020、2021、2022。目标是模型/性状特定的固定观测集，而不是所有 G2F 观测。final_eligible 输入筛选后扫描环境数可少于训练目标环境数；AquaCrop 的有效原生日历由耦合参数化产生，名义参数并非独立实测常数。精确范围、活动参数及有效值见 parameter_bounds.csv 和各模型 result.json。

## 冻结后的独立验证

本品种实际可用的独立验证来自 2023 年。以下只展示 final_selected / overall，每模型 15 项产量、13 项相应物候目标；其他方案和分组指标另表保留。

| model | variable | n | expected_count | coverage | mae | rmse | bias |
| --- | --- | --- | --- | --- | --- | --- | --- |
| apsim | dry_yield_mg_ha | 15 | 15 | 1.0 | 2.0746324226310278 | 2.442326283547706 | -1.8600328559013604 |
| apsim | pollen_dap | 13 | 13 | 1.0 | 2.506410256410256 | 3.0192579888805136 | -1.66025641025641 |
| aquacrop | dry_yield_mg_ha | 15 | 15 | 1.0 | 1.91075401369006 | 2.135499424212673 | -1.603768244905992 |
| aquacrop | pollen_dap | 13 | 13 | 1.0 | 2.0448717948717947 | 2.5116183021563 | -1.275641025641025 |
| dssat | dry_yield_mg_ha | 15 | 15 | 1.0 | 3.498228349956693 | 4.0974629384664025 | -2.792318189234693 |
| dssat | silk_dap | 13 | 13 | 1.0 | 4.038461538461538 | 4.729205495152924 | -4.038461538461538 |

以上是模型对观测的误差指标。actual_planting_replay.csv 中 169 项 matched=True是保存预测和重跑预测的一致性（70 项产量、64 项 pollen、35 项 silk），不是与观测完全相等。训练重放也不是新增独立验证。

本轮没有执行交叉验证、bootstrap、输入不确定性传播；配置中的计划不能写成已完成。早期训练 result.json 保留当时 training_only 状态，之后独立验证的证据来自 independent_* 文件与原冻结/验证清单。这些估计不是全局最优或已证实的生理辨识结果。
