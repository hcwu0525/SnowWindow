# 完整字段字典

非空统计来自全部状态，不是有效样本数量。models_with_values 只说明本数据有值的模型；三个模型都缺失的列不推断适用性。布尔/日期列可能以原生浮点或字符串存储，类型一栏保留实际 Parquet 类型。原生参数单位来自冻结最终协议。

| field | description | type | unit | source_kind | models_with_values | non_null_total | non_null_apsim | non_null_aquacrop | non_null_dssat | validity |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| approximate_weather_days_used | 使用近似天气的日数，当前全部为零 | int64 | day | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| artifacts | 原运行产物路径的 JSON；所指缓存/逐日文件未随包分发 | string | JSON | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| attempts | 执行尝试次数，延长时合计初次与延长运行的尝试 | int64 | count | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| continuation_recovered | 跨年重跑后达到自然成熟且产量非空 | bool | boolean | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| continuation_request_fingerprint | 跨年延长请求内容的 SHA-256；未延长时为空 | string | SHA-256 | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 15408 | 6609 | 6186 | 2613 | 仅跨年重跑记录适用 |
| cross_year_extended | 是否使用同初始状态的更长窗口重跑 | bool | boolean | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| cultivar_id | 玉米品种身份，固定为 PHG29/PHG47 | string | identifier | G2F 身份元数据/派生环境映射 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| days_available_after_sowing | 播期至请求模拟终点的日数，含首尾 | int64 | day | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| dry_yield_mg_ha | 经过自然成熟筛选的模型干产量；有效零值保留 | double | Mg/ha | 仿真输出/模型物候代理 | apsim,aquacrop,dssat | 33125 | 12398 | 11962 | 8765 | status=matured 且 natural_maturity=True、forced_maturity=False、值非空；保留零 |
| elapsed_seconds_batch_per_request | 批运行时间除以请求数，不是逐请求独立计时 | double | second | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| environment_id | 年度环境身份，关联环境表 | string | identifier | G2F 身份元数据/派生环境映射 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| failure_reason | 原模型/执行失败原因；空原因不保证所有字段有效 | string | text | 运行状态、溯源或派生诊断 | aquacrop,dssat | 3669 | 0 | 12 | 3657 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| first_pass_end_date | 初次同年请求终点 | string | ISO date | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| first_pass_record | 延长前完整记录的 JSON；未延长时为空 | struct<artifacts: string, attempts: double, cultivar_id: string, days_available_after_sowing: double, dry_yield_mg_ha: null, environment_id: string, failure_reason: string, flowering_date: string, forced_maturity: bool, horizon_limited: bool, irrigation_assumption: string, maturity_date: null, model: string, model_version: string, namespace: string, native_diagnostics: string, native_summary: string, native_yield_mg_ha: double, natural_maturity: bool, planting_date: string, pollen_dap: double, request_fingerprint: string, request_id: string, silk_dap: double, simulation_end_date: string, simulation_start_date: string, soil_input_tier: string, status: string, thermal_time_initialization_limited: bool, year: double> | JSON | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 15408 | 6609 | 6186 | 2613 | 仅跨年重跑记录适用 |
| first_pass_status | 跨年处理前的第一次运行结局 | string | category | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| flowering_date | 模型报告的物候代理日期，跨模型事件定义不同 | string | ISO date | 仿真输出/模型物候代理 | apsim,aquacrop,dssat | 34268 | 12422 | 12410 | 9436 | 日期非空不是有效性证明；结合对应 DAP、status、natural_maturity 与模拟窗口 |
| forced_maturity | 检测、排除或拒绝强制成熟相关事件的诊断标识 | bool | boolean | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| horizon_limited | 当前实现中为 status=not_matured，不保证延长后可成熟 | bool | boolean | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| irrigation_assumption | assumed_rainfed 或 rainfed_confirmed 的证据分类 | string | category | 输入证据分类，可能为假设/先验 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| maturity_date | 模型报告的成熟日期，须结合自然成熟判定 | string | ISO date | 仿真输出/模型物候代理 | apsim,aquacrop,dssat | 33149 | 12422 | 11962 | 8765 | 日期非空不是有效性证明；结合对应 DAP、status、natural_maturity 与模拟窗口 |
| model | 模型标识 apsim/aquacrop/dssat | string | identifier | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| model_version | 执行模型的版本 | string | text | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| namespace | 冻结实验命名空间/清单指纹 | string | SHA-256 | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| native_diagnostics | 原生状态、输入和执行诊断的 JSON | string | JSON | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| native_summary | 完整原生摘要 JSON，展开列由此派生 | string | JSON | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| native_yield_mg_ha | 适配器报告的干产量，未按自然成熟筛选 | double | Mg/ha | 仿真输出/模型物候代理 | apsim,aquacrop,dssat | 33573 | 12398 | 12410 | 8765 | 未按自然成熟筛选；诊断使用，不能替代 dry_yield_mg_ha |
| natural_maturity | 成熟且无强制成熟标识的统一判定，不保证产量非空 | bool | boolean | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| planting_date | 本行模拟播期，通常为反事实日期 | string | ISO date | 模拟设计/请求 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| pollen_dap | APSIM/AquaCrop 物候代理 DAP，非独立实测散粉 | double | day after planting | 仿真输出/模型物候代理 | apsim,aquacrop | 24832 | 12422 | 12410 | 0 | 相应模型列非空；检查事件与终止时间；不要求较早物候事件之后一定成熟 |
| request_fingerprint | 原播期请求输入内容的 SHA-256，延长后仍保留原请求值 | string | SHA-256 | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| request_id | 派生模拟请求标识，不是 G2F 原生键 | string | identifier | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| silk_dap | DSSAT 75% 吐丝代理 DAP，不是散粉日期 | double | day after planting | 仿真输出/模型物候代理 | dssat | 9436 | 0 | 0 | 9436 | 相应模型列非空；检查事件与终止时间；不要求较早物候事件之后一定成熟 |
| simulation_end_date | 最终请求模拟终点，可能为跨年延长终点 | string | ISO date | 模拟设计/请求 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| simulation_start_date | 最终请求模拟起点，不等于实际出苗日期 | string | ISO date | 模拟设计/请求 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| soil_input_tier | 土壤证据分类，当前全部 texture_prior_not_measured | string | category | 输入证据分类，可能为假设/先验 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| status | 最终运行结局：成熟/死亡/未成熟/执行失败 | string | category | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| thermal_time_initialization_limited | 是否报告初始化积温不足结局，当前全假 | bool | boolean | 运行状态、溯源或派生诊断 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| year | 环境及播种所属年，不随跨年成熟改变 | int64 | year | G2F 身份元数据/派生环境映射 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| native_summary_actual_simulation_dates_source | 实际模拟日期的证据来源 | string | text | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_actual_simulation_end_date | 引擎实际执行终点 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_actual_simulation_start_date | 引擎实际执行起点 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_biomass_mg_ha | 模型生物量摘要，需核对统计时点 | double | Mg/ha | 模型原生摘要展开（含输入与过程诊断） | apsim,aquacrop,dssat | 37230 | 12398 | 12410 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_clock_completed | 模型时钟执行完成，不等于作物自然成熟 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_dry_yield_mg_ha | 原生干产量摘要，尚未经过统一自然成熟筛选 | double | Mg/ha | 模型原生摘要展开（含输入与过程诊断） | apsim,aquacrop,dssat | 33573 | 12398 | 12410 | 8765 | 未按自然成熟筛选；诊断使用，不能替代 dry_yield_mg_ha |
| native_summary_flag_leaf_tt | 旗叶阶段积温目标，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_flowering_date | 原模型开花/物候事件报告日期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | apsim,dssat | 21858 | 12422 | 0 | 9436 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_flowering_proxy_dap | 模型特定物候代理的播后日数 | double | day after planting | 模型原生摘要展开（含输入与过程诊断） | apsim,aquacrop,dssat | 34268 | 12422 | 12410 | 9436 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_flowering_to_grain_fill_tt | 开花至灌浆积温目标，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_grain_fill_tt | 灌浆阶段积温目标，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_grain_number_scale | APSIM 籽粒数缩放参数 | double | dimensionless | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_harvest_date | 模型收获日期，不等同于生理成熟 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | apsim | 12398 | 12398 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_harvest_ripe_date | 模型可收获成熟阶段日期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | apsim | 12400 | 12400 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_juvenile_tt | 幼年阶段积温目标，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_maturity_date | 原模型成熟日期报告 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | apsim,aquacrop,dssat | 33149 | 12422 | 11962 | 8765 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_maturity_date_quality | 成熟日期的事件质量标记 | string | category | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_maturity_date_source | 成熟日期证据来源 | string | text | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_maximum_grain_size_g | 最大单粒质量参数，估计/参考值而非实测常数 | double | g/kernel | 校准估计/参考先验/耦合参数化或管理假设 | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_photoperiod_sensitivity | 模型光周期敏感性参数，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_planting_date | 原生摘要中的播期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | apsim,dssat | 24844 | 12422 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_potential_grain_number | 潜在籽粒数参数，估计/参考值而非实测常数 | double | kernels/cob | 校准估计/参考先验/耦合参数化或管理假设 | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_termination_rule | 原模型终止规则；clock_end 不代表自然成熟 | string | category | 模型原生摘要展开（含输入与过程诊断） | apsim | 12422 | 12422 | 0 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_HI0 | 名义参考收获指数，估计/参考值而非实测常数 | double | fraction | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_actual_sowing_date | 引擎实际播种日期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_cache_key | 原引擎缓存标识；缓存未随包分发 | string | identifier | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_configured_harvest_rule | 配置的收获规则，非成熟事件本身 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_crop | 原模型作物名称 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_cultivar_id | 原模型摘要的品种标识 | string | identifier | 模型原生摘要展开（含输入与过程诊断） | aquacrop,dssat | 24832 | 0 | 12410 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_day_before_planting_soil_water_mm | 播种前一天模拟土壤水量 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12376 | 0 | 12376 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_effective_HI0 | 实际引擎使用的有效收获指数 | double | dimensionless | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_effective_max_root_depth_m | 引擎实际采用的最大根深 | double | m | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_elapsed_seconds | 原模型运行耗时 | double | second | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_et0_model_input_min_mm_day | 进入引擎的 ET0 日值最小值 | double | mm/day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_et0_unclipped_min_mm_day | 裁剪前 ET0 日值最小值 | double | mm/day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_flowering_proxy_date | 模型特定物候代理日期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_flowering_proxy_note | 物候代理定义和不等于独立散粉/吐丝的说明 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_forced_maturity_rejected | 强制成熟相关输出是否被拒绝 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_initial_available_water_pct | 参考初始可利用水百分比 | double | % | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_initial_soil_water_mm | 模拟初始土壤水总量 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_irrigation_assumption | 原生摘要的灌溉证据分类 | string | category | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_irrigation_method | 原生灌溉方式编码 | string | model-native code | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_last_simulated_date | 引擎最后模拟日 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_leap_day_harvest_rule_adjusted | 是否进行了闰日收获规则修正 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_max_simulated_root_depth_m | 模拟达到的最大根深 | double | m | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_model_version | 原生摘要中的版本 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_maturity_reached | 原生终态是否达到成熟条件 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_maturity_rejection_reason | 原生成熟结果被拒绝的原因 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 303 | 0 | 303 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_yield_form_date | 原生籽粒形成事件日期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_nitrogen_stress_modeled | 模型是否模拟氮胁迫，AquaCrop 当前为假 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_parameter_set_id | 原生参数集身份 | string | identifier | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_parameterization | 原生参数化方法 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_phenology_parameterization | 物候耦合参数化方法 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_plant_population_ha | 引擎种植密度输入 | double | plants/ha | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_population_evidence_source | 密度输入证据来源 | string | text | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_population_verified | 密度是否来自验证证据 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop,dssat | 24832 | 0 | 12410 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_preplant_days_simulated | 播前模拟日数 | double | day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_preplant_soil_water_range_mm | 播前模拟土壤水变化幅度 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_requested_sowing_date | 请求播种日期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_root_depth_clipped_by_profile | 根深是否因剖面深度被裁剪 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_seasonal_et_mm | 季节累计蒸散量；统计窗口为模型定义 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_seasonal_evaporation_mm | 季节累计蒸发量；统计窗口为模型定义 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_seasonal_irrigation_mm | 季节累计灌溉量；不是实测灌溉记录 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_seasonal_precipitation_mm | 模型统计窗口内的输入降水累计 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_seasonal_transpiration_mm | 季节累计蒸腾量；统计窗口为模型定义 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_simulation_end_date | 原生摘要的请求终点 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_simulation_start_date | 原生摘要的请求起点 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_soil_compartment_m | 模型土壤计算分室深度结构 | double | m (array) | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_soil_profile_depth_m | 输入土壤剖面深度 | double | m | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_soil_type | AquaCrop 参考土壤类型 | string | category | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_soil_water_bounds_ok | 土壤含水量边界检查是否通过 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_termination_date | 模型作物/模拟终止日期 | string | ISO date | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_termination_reason | 模型终止原因 | string | category | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_water_balance_max_abs_mm_day | 日水量平衡残差最大绝对值 | double | mm/day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_water_balance_total_residual_mm | 总水量平衡残差 | double | mm | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_yield_at_15p5_mg_ha | 按 15.5% 含水率折算的模型产量，非干重 | double | Mg/ha | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.CanopyDevEnd | AquaCrop 耦合参数化派生的冠层发育结束时序 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.CanopyDevEndCD | AquaCrop 耦合参数化派生的冠层发育结束时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.FloweringCD | AquaCrop 耦合参数化派生的开花代理阶段持续时间时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.HIstartCD | AquaCrop 耦合参数化派生的收获指数启动时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.MaturityCD | AquaCrop 耦合参数化派生的成熟时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.MaxCanopy | AquaCrop 耦合参数化派生的最大冠层时序 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.MaxCanopyCD | AquaCrop 耦合参数化派生的最大冠层时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.MaxRootingCD | AquaCrop 耦合参数化派生的最大根系时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.SenescenceCD | AquaCrop 耦合参数化派生的衰老时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_derived_canopy_calendar.YldFormCD | AquaCrop 耦合参数化派生的籽粒形成阶段持续时间时序 | double | day after planting / duration | 校准估计/参考先验/耦合参数化或管理假设 | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.crop_dead | 原生终态作物死亡 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.crop_mature | 原生终态作物成熟 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.delayed_cds | 原生萌发/发育延迟日数 | double | day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.delayed_gdds | 原生萌发/发育延迟积温 | double | degC day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.development_gdd | 终态用于发育判断的积温 | double | degC day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.germination | 原生终态萌发标识 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.raw_gdd_cum | 终态原始累计积温 | double | degC day | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_terminal_state.yield_form | 原生终态籽粒形成标识 | bool | boolean | 模型原生摘要展开（含输入与过程诊断） | aquacrop | 12410 | 0 | 12410 | 0 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_G2 | DSSAT 潜在籽粒数参数，估计/参考值而非实测常数 | double | kernels/plant | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_G3 | DSSAT 籽粒生长速率参数，估计/参考值而非实测常数 | double | mg/day | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_P1 | DSSAT 幼年阶段积温参数，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_P2 | DSSAT 光周期响应参数，估计/参考值而非实测常数 | double | day/hour | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_P5 | DSSAT 灌浆阶段积温参数，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_PHINT | DSSAT 叶片出现间隔积温参数，估计/参考值而非实测常数 | double | degC day | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_crop_status_code | DSSAT 作物结局原生代码，解释以该引擎定义为准 | double | model-native code | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_fertilizer_nitrogen_kg_ha | 模型施氮输入总量，含参考假设 | double | kg N/ha | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_flowering_event | DSSAT ADAT=75% 吐丝的事件说明 | string | text | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_mode | DSSAT 输入模式 | string | category | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_irrigation_mm | DSSAT 模拟灌溉累计 | double | mm | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_population_assumption | 密度参考假设的说明 | string | text | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_population_plants_m2 | 种植密度输入 | double | plants/m² | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_reference_cultivar_id | 模型参考品种先验标识，非当前 G2F 杂交种测量 | string | identifier | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_reference_soil_id | 参考土壤档案标识 | string | identifier | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_soil_id | DSSAT 土壤档案标识 | string | identifier | 模型原生摘要展开（含输入与过程诊断） | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.fertilizer_material_placement | 肥料材料和施用位置假设 | string | text | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.fertilizer_schedule | 施肥日程假设 | string | text | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.initial_n_distribution | 初始氮分层分布假设 | string | text | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.irrigation_assumption | 灌溉证据假设 | string | category | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.row_spacing_assumed | 行距是否为假设输入 | bool | boolean | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.row_spacing_m | 行距输入 | double | m | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.soil_root_distribution | 土壤根系分布假设 | string | text | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.soil_surface.SALB | DSSAT 土壤反照率先验 | double | dimensionless | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.soil_surface.SLDR | DSSAT 土壤排水速率因子先验 | double | model-native | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.soil_surface.SLNF | DSSAT 土壤氮矿化因子先验 | double | dimensionless | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.soil_surface.SLPF | DSSAT 土壤肥力因子先验 | double | dimensionless | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.soil_surface.SLRO | DSSAT 土壤径流曲线数先验 | double | dimensionless | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.soil_surface.SLU1 | DSSAT 第一阶段土壤蒸发上限先验 | double | mm | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.sowing_depth_assumed | 播深是否为假设输入 | bool | boolean | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_input_assumptions.sowing_depth_m | 播深输入 | double | m | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_cultivar_prior.ecotype | DSSAT 参考品种的生态型 | string | identifier | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_cultivar_prior.id | DSSAT 参考品种身份 | string | identifier | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_cultivar_prior.name | DSSAT 参考品种名称 | string | text | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_cultivar_prior.role | 参考品种在先验中的角色 | string | text | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_cultivar_prior.source | 参考品种来源文件 | string | path | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_cultivar_prior.source_row | 参考品种来源行文本 | string | text | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| native_summary_native_cultivar_prior.source_sha256 | 参考品种来源摘要 | string | SHA-256 | 校准估计/参考先验/耦合参数化或管理假设 | dssat | 12422 | 0 | 0 | 12422 | 仅有值的模型适用；查状态、统计时点和原生定义；非空不等于科学有效 |
| site_id | 年度环境所对应的站点映射 | string | identifier | G2F 身份元数据/派生环境映射 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| planting_date_dt | planting_date 的日期类型副本 | timestamp[ns] | datetime | 原日期字段的类型转换 | apsim,aquacrop,dssat | 37266 | 12422 | 12422 | 12422 | 身份/输入/运行信息；保留全部状态；缺失不补零 |
| flowering_date_dt | flowering_date 的日期类型副本，事件限制不变 | timestamp[ns] | datetime | 原日期字段的类型转换 | apsim,aquacrop,dssat | 34268 | 12422 | 12410 | 9436 | 日期非空不是有效性证明；结合对应 DAP、status、natural_maturity 与模拟窗口 |
| maturity_date_dt | maturity_date 的日期类型副本，状态限制不变 | timestamp[ns] | datetime | 原日期字段的类型转换 | apsim,aquacrop,dssat | 33149 | 12422 | 11962 | 8765 | 日期非空不是有效性证明；结合对应 DAP、status、natural_maturity 与模拟窗口 |
