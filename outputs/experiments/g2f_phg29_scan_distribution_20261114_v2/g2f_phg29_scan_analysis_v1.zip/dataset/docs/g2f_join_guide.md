# 与 G2F 原始数据关联

## 标识和来源

G2F 原始数据由接收方提供。本包保留来源路径，例如
`Training_data/1_Training_Trait_Data_2014_2023.csv`。
`source_row_number` 是原 CSV 去掉表头后、从 1 开始的数据行号：
可用 `pd.read_csv(path).iloc[source_row_number - 1]` 定位。
如果原文件排序、版本或内容不同，必须先核对文件摘要，不能盲用行号。

`environment_id` 对应年度环境；`site_id` 为站点。
`unit_id`、`management_unit_id`、`physical_management_unit_id` 和
`observation_id` 都是 SnowWindow 派生标识，不是原始 G2F 自带列。
观测是管理单元内同一品种、同一性状的聚合结果，一条观测可以来自多个小区。
`source_rows_json` 保留其所有来源；展开版为 `data/observation_sources.csv`。

来源映射表的一行是一个 observation_id 的一条源行；同一源行用于多个性状
属于正常情况。不能将映射展开后的多行重新当作独立观测样本。

## 从小区记录重建观测

| 原始列 | 本包 variable | 转换与有效范围 |
|---|---|---|
| Yield_Mg_ha | dry_yield_mg_ha | 原单位 Mg/ha，乘 0.845；转换后有限且 ≥0 |
| Pollen_DAP_days | pollen_dap | 原单位日，取有限值，范围 1–200 |
| Silk_DAP_days | silk_dap | 原单位日，取有限值，范围 1–200 |
| Plant_Height_cm | plant_height_m | cm 乘 0.01 转 m，范围 0.01–10 m |
| Ear_Height_cm | ear_height_m | cm 乘 0.01 转 m，范围 0–10 m |
| Stand_Count_plants | stand_count_plants | 原单位 plants，有限且 ≥0；不当作播种密度 |

范围是项目质量检查规则，不是所有玉米的生理极限。原始缺失/无法转成数字的值、
非有限值或越界值置为缺失并记录原因，不补零。

聚合使用“管理单元 × 品种 × 性状”内的独立 physical_plot_id：
同一物理小区重复行的同一性状若一致，只贡献一次；若数值冲突（包括缺失与有值
冲突），该小区该性状不进入均值并记 conflicting_duplicate_plot。
小区资格不合格时不进入聚合。有效独立小区等权求均值，variance 为样本方差
（ddof=1）；只有一个值时方差未知。普通小区观测不足两个有效独立小区时保留记录
但标记不合格。本包扫描单元都是 plot 类型，不是已聚合的环境品种标签。

`data/observation_plot_provenance.parquet` 保留这些小区的物理标识、来源行、
标准化性状及质量/排除标识；pollen_dap 和 silk_dap 在该小区表分别名为
pollen_dap_days、silk_dap_days。`examples/use_results.py` 会重建全部 210 项
观测的均值、样本方差及有效小区数并核对保存值。具体规范化实现归档于
provenance/source_code/src__snowwindow__cultivar_data.py。

## 推荐关联过程

1. 读取 `management_units.parquet` 和 `observations.parquet`，按 `unit_id`
   做 many-to-one 关联，得到 actual planting_date、试验、处理及来源。
2. 由 `scenario_units.csv` 确认该管理单元是否为本模型/环境的代表单元或
   物理等价单元。不要仅凭相同环境就把不同管理情景视为同一个扫描情景。
3. 对产量观测关联 `dry_yield_mg_ha`；APSIM/AquaCrop 对 pollen_dap，
   DSSAT 对 silk_dap。不适用性状不强行关联。
4. 只在 `model + environment_id + actual_planting_date` 与扫描键匹配时比较。
   保留 `unit_id` 和 `observation_id`，同环境的两个物理等价单元可能有不同
   观测，但共享同一预测；统计独立样本时必须说明此结构。
5. 对产量检查自然成熟、非强制成熟和非空；对物候检查事件有效性。
   示例会留下未匹配、空预测及状态信息，不用缺失补零。

`examples/use_results.py` 实现此关联，并可通过 `--g2f-dir` 检查原始性状文件
摘要和一条源行定位。不需要 G2F 就能运行其余读取、筛选和曲线示例。

## 统计与验证口径

`observations.value` 是聚合性状值；`variance` 是重复观测方差，
不是校准参数的不确定性或预测方差。`n_plots`/`n_records` 与
`source_row_count` 描述样本来源，不应把源行数当成环境数。
obs 中可能存在未进入某模型训练目标的性状，训练目标以各模型
`calibration/<model>/targets_and_weights.json` 为准。

35 个管理单元与 34 个扫描环境不能互换。最终校准训练还包含其他输入合格管理
单元，所以其目标环境数也不必等于扫描环境数。独立验证年份是本品种实际可用的
2023 年，而不是当前扫描数据里的年份。

169 项实际播期重放一致是“保存预测 vs 重跑预测”的一致性证据。
预测与真实观测的偏差看 `absolute_error` 或独立验证的 MAE/RMSE/Bias，
不能把 matched=True 理解为 observed_value=predicted_value。

matched 使用 `math.isclose(saved, replayed, abs_tol=1e-6, rel_tol=1e-8)`，
且重放与保存预测的运行状态相同。容差的单位与性状相同，不是田间误差验收阈值。

本品种实际训练观测年份为 2016、2017、2020、2021、2022。
2023 性状观测值没有进入品种参数拟合、候选参数比较或目标尺度/权重确定；
输入资格和年份等元数据可以参与环境筛选。参数冻结后才打开独立性状验证，
验证后不重新调参。2023 天气作为某些 2022 扫描的续年输入，与用 2023
性状观测调参是不同概念。
