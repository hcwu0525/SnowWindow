# 辅助表的键与数值

| 表 | 行粒度/键 | 关键数值和用途 |
|---|---|---|
| environments | environment_id 唯一 | 年份、坐标、灌溉证据、元数据来源与问题注释 |
| management_units | unit_id 唯一 | 实际 planting_date、试验/处理、来源、合格标识、物理管理标识 |
| scenario_units | model + environment_id + unit_id 唯一 | representative 标识源请求的代表单元；其他行为物理等价单元 |
| observations | observation_id 唯一 | value=聚合观测、trait/variable=性状、unit=单位、variance=重复方差 |
| observation_sources | observation_id + source_filename + source_row_number | 观测到原始小区记录的多对多来源，不是独立性状样本 |
| observation_plot_provenance | source_filename + source_row_number 唯一 | physical_plot_id 定义独立重复；标准化性状、资格和质量信息用于重建观测 |
| soil_priors | environment_id + top_depth_m + bottom_depth_m | 分层先验；theta 为体积含水率，ksat 为 mm/day，容重 g/cm³ |
| calibration/training_targets | model + observation_id 唯一 | 各模型真正参与拟合的固定观测集；model/trait 不能混合计数 |
| calibration/training_predictions | model + observation_id | 保存的最终选定参数预测；primary_target 标识是否用于目标函数 |
| calibration/independent_predictions | model + scheme + observation_id 唯一 | final_selected/reference/prior_96 分别是最终/参考/前轮对照方案 |
| calibration/training_metrics、independent_metrics | model + scheme + variable + stratum + stratum_value | n=有效预测数，expected_count=固定目标数，coverage=覆盖率 |
| calibration/actual_planting_replay | model + unit_id + variable | saved/replayed=保存/重跑预测，observed=观测，matched=重放一致 |
| summaries/field_coverage | model + field | 全部记录和各状态下的非空数量；非空不等于科学有效 |

辅助表中的数组/字典列在 Parquet 中保留原类型；CSV 以 JSON 文本编码。
`observed_value`/`value` 是观测聚合值；`predicted_value` 是模型输出。
MAE、RMSE、Bias 的单位与 variable 一致：产量为 Mg/ha，物候为日。
Bias 为预测减观测。`conditional_*` 指标只统计有效子集；固定目标缺失时，
不能用较小的条件误差宣称覆盖完整，需同时报告 coverage/expected_count。

`protocol_split` 是研究训练/独立验证分割；`source_split` 是 G2F 文件来源类别。
即使源文件名包含 Training_data，其 2023 年观测仍可能是本研究独立验证集。
`eligible`、`final_eligible`、`exclusion_reasons` 以及 primary_target 都保留，
用实际模型目标和输入资格来判断用途，不凭年份/文件名推测。
