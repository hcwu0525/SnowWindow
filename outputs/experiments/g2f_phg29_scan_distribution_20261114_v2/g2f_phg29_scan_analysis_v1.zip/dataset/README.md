# PHG29/PHG47 玉米播期扫描分析数据包

本包提供同一玉米杂交种在多个历史环境下的播期响应仿真，用于播种日期研究。
接收方已有 G2F 原始数据；本包不重复分发完整原始数据集。

| 项目 | 内容 |
|---|---|
| 品种 | PHG29/PHG47，parent1=PHG29、parent2=PHG47 |
| 扫描来源 | g2f_phg29_stage1_scan_20261113_v2 |
| 校准来源 | g2f_cultivar_calibration_20261112_final_v1 |
| 扫描环境 | 34 个环境，20 个站点 |
| 播种年份 | 2016、2017、2020、2021、2022 |
| 模型 | APSIM 2026.9.8116.0、AquaCrop 3.1.0、DSSAT 4.8.6.2 |
| 扫描网格 | 各环境所属年 1 月 1 日至 12 月 31 日，逐日扫描 |
| 记录 | 37,266 行；每模型 12,422 行；完整表 174 列 |
| 产量有效记录 | 33,125 行 |

每行是一个“模型 × 环境 × 模拟播种日期”。品种固定，因此行唯一键是
`model + environment_id + planting_date`。环境是特定站点的年度试验背景，
站点可以跨年份重复出现；不是 34 个不同地理地点。

## 从这里开始

1. 阅读 [核心字段](docs/core_fields.md) 和 [仿真设置](docs/simulation_settings.md)。
2. Python/R 分析优先读取 `data/results_complete.parquet`；电子表格浏览可用
   `data/results_core.csv`。两者覆盖相同的全部记录，CSV 只选取核心列。
3. 运行 `python examples/verify_package.py` 核对包内文件。
4. 运行 `python examples/use_results.py`，得到筛选统计和一个环境的播期曲线。
   示例需要 pandas、pyarrow、matplotlib；纯校验脚本仅用 Python 标准库。
5. 与 G2F 比较前阅读 [关联指南](docs/g2f_join_guide.md)。G2F 原始表没有
   SnowWindow 生成的 `unit_id`、`observation_id`，应通过来源文件与数据行号定位。

## 文件导航

| 文件/目录 | 内容 |
|---|---|
| `data/results_complete.parquet` | 与冻结源文件逐字节一致的完整结果 |
| `data/results_core.csv` | 核心分析字段，保留失败记录与空值 |
| `data/environments.*`、`data/management_units.*` | 环境信息和实际播期、管理单元、来源映射 |
| `data/observations.*`、`data/observation_sources.csv` | 扫描环境的观测摘录与一行一条来源映射 |
| `data/observation_plot_provenance.*` | 观测小区的物理身份、标准化性状及质量标识，用于重建均值 |
| `data/scenario_units.csv` | 每模型/环境实际采用的代表管理单元及物理等价单元 |
| `data/soil_priors.*`、`data/assumptions.json` | 实际使用的非实测土壤和参考管理假设 |
| `calibration/` | 仅本品种的参数选择记录、实际目标、预测和误差指标 |
| `summaries/` | 按模型/年份/环境的状态、有效产量和字段非空覆盖 |
| `docs/field_dictionary.*` | 全部 174 列的字典；Markdown 便于阅读，CSV 便于程序使用 |
| `docs/auxiliary_tables.md` | 关联表与校准表的键、值和样本计数口径 |
| `provenance/` | 冻结来源清单、输入指纹、源文件摘要、源代码摘录与路径说明 |
| `manifest.json`、`SHA256SUMS` | 分发版本、文件大小/行数和校验值 |

## 使用边界

扫描产量、物候、成熟和死亡都是模型输出。除实际播期外，扫描日期没有配对的
田间产量观测；本包不能用于宣称所有播期均获得实测验证。

土壤均为 `texture_prior_not_measured`；管理包含人口密度、初始水氮和施氮量
等参考假设。`assumed_rainfed` 与 `rainfed_confirmed` 必须区分。
G2F 产量转干重采用 15.5% 标准含水率假设，也不是每条观测的实测水分值。

保留成熟 33,149、死亡 4,040、未成熟 65、执行失败 12 条记录。
成熟中有 24 条 APSIM 记录没有可用干产量，因此成熟数不等于有效产量数。
缺失不能补成零；真实的有效零产量不能删除。

本包不包含天气事件验证、逐日模型输出、完整运行缓存或模型可执行程序。
可以复现包内分析与校验；不是从原始数据重新运行三个引擎的完整复现包。
致谢及来源使用说明见 [来源与限制](docs/provenance_and_limits.md)。
